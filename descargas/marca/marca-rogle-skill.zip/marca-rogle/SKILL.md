---
name: marca-rogle
description: Aplica la marca del grupo de investigación ROGLE (UPV) a cualquier documento, presentación, web, vídeo, póster o carta. Úsalo siempre que el trabajo sea de ROGLE, del Departamento de Organización de Empresas de la UPV, o pida logotipo, colores, tipografía o plantillas del grupo.
---

# Marca ROGLE

ROGLE es un grupo de investigación del Departamento de Organización de Empresas de la Universitat Politècnica de València (fundado en 2006). Esta skill hace que todo lo que generes lleve su marca.

## Antes de producir nada

1. Lee `references/BRAND.md`: contiene el significado de la marca, los colores, la tipografía, las reglas de uso, los usos incorrectos y el estilo de escritura.
2. Para colores y tipografía de Quarto, usa `references/brand.yml`.
3. Usa **siempre los archivos de `assets/`** para el logotipo. No compongas el logotipo con texto, no lo redibujes y no lo deformes.

## Resumen rápido

- Marca vigente: **alternativa C** (nombre ROGLE en Palatino negrita), adoptada el 6 de octubre de 2026. No uses las alternativas A ni B.
- Colores: `oxford-blue` #002147, `indigo` #3F4AA8, `indigo-medio` #5B67C7, `indigo-claro` #A9B0E0, `ambar` #F5B000 (solo sobre `oxford-blue`), `gris-upv-431` #5B6770, `tinte-claro` #F3F4FA.
- Tipografía: Palatino para todo el texto (títulos en negrita; pies, etiquetas y leyendas en el mismo Palatino, con cursiva si hace falta contraste). En la web: Poppins Bold e Inter.
- Escribe en español, frases cortas. El nombre va siempre «ROGLE». El departamento, siempre «Departamento de Organización de Empresas».
- Logotipo por defecto: `assets/rogle-logo-color.svg`. Sobre fondo oscuro: `assets/rogle-logo-reverse.svg`. Impresión a una tinta: `assets/rogle-logo-black.svg`.
- Si no puedes cumplir una regla (por ejemplo no hay Palatino disponible), dilo y propón la alternativa libre (TeX Gyre Pagella) en lugar de inventar otra tipografía.

## Plantillas y manual

Las plantillas de Word, PowerPoint, Quarto, LaTeX y Typst, el manual con imágenes y todas las variantes del logotipo están en https://rogle.webs.upv.es/es/recursos/marca.html y en el repositorio `allabur/rogle`. La guía pública para asistentes está en https://rogle.webs.upv.es/descargas/marca/BRAND.md.

## Al terminar

Comprueba contra la lista de usos incorrectos de `references/BRAND.md`: sin deformar, sin efectos, `ambar` solo sobre `oxford-blue`, contraste mínimo 4,5:1 en texto.
