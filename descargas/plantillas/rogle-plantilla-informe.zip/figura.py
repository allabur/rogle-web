"""Generate figura-coste.png, the example figure of template.qmd."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# BRAND.md: Palatino is the only text font, also in figure labels.
plt.rcParams["font.family"] = ["Palatino", "Palatino Linotype", "TeX Gyre Pagella"]

nombres = ["Voraz", "Búsqueda local", "Exacta"]
costes = [104.2, 98.7, 96.5]
fig, ax = plt.subplots(figsize=(5, 2.6))
ax.bar(nombres, costes, color=["#A9B0E0", "#5B67C7", "#3F4AA8"])
ax.set_ylim(90, 106)
ax.set_yticks([90, 95, 100, 105])
ax.set_ylabel("Coste medio", color="#000000")
ax.tick_params(colors="#000000")
for lado in ("top", "right"):
    ax.spines[lado].set_visible(False)
fig.tight_layout()
fig.savefig("figura-coste.png", dpi=200)
