"""Generate figura-coste.png, the example figure of template.qmd."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

nombres = ["Voraz", "Búsqueda local", "Exacta"]
costes = [104.2, 98.7, 96.5]
fig, ax = plt.subplots(figsize=(5, 2.6))
ax.bar(nombres, costes, color=["#A9B0E0", "#5B67C7", "#3F4AA8"])
ax.set_ylim(90, 106)
ax.set_ylabel("Coste medio", color="#002147")
ax.tick_params(colors="#002147")
for lado in ("top", "right"):
    ax.spines[lado].set_visible(False)
fig.tight_layout()
fig.savefig("figura-coste.png", dpi=200)
