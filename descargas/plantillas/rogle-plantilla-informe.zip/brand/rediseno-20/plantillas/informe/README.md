# Plantilla de informe técnico y artículo

Formato Quarto a PDF (LaTeX con LuaLaTeX) con la propuesta de marca del 20 aniversario, alternativa A. Incluye portada con logotipo, resumen, índice, títulos y texto en Palatino (los títulos en negrita), Gill Sans para lo secundario, fórmulas en Pagella, tablas y figuras con pies numerados, citas con bibliografía, y cabecera y pie con logotipo y paginación.

## Uso

Copia la carpeta, edita `template.qmd` y renderiza:

```bash
export PATH="/Library/TeX/texbin:$PATH"
quarto render brand/rediseno-20/plantillas/informe/template.qmd
```

Requisitos: Quarto 1.4 o superior y LuaLaTeX. No hace falta Jupyter: la figura de ejemplo es un PNG (`figura.py` lo regenera).

## Contenido

- `template.qmd`: ejemplo con portada, resumen, tres secciones, tabla, figura, fórmula, código y bibliografía.
- `header.tex`: preámbulo (colores, fuentes, cabecera, pie, pies de figura).
- `title.tex`: portada. Lee título, subtítulo, autores, afiliaciones y fecha del YAML.
- `refs.bib`: bibliografía ficticia.
- `logos/`: logotipos de A en PDF vectorial.
- `muestra/`: PDF de muestra y PNG de sus páginas.

## Notas

- Los colores vienen de `brand/latex/rogle-colors.sty`, por ruta relativa. Si mueves la carpeta, ajusta la ruta en `header.tex`.
- Las fuentes siguen el sistema de `brand/latex/rogle20-fonts.sty`: Palatino y Gill Sans del sistema, con TeX Gyre Pagella y Gillius ADF como respaldo. Las fórmulas usan TeX Gyre Pagella Math. Esa variante evita el choque de `newpxmath` con `unicode-math`, que la plantilla de Quarto carga con LuaLaTeX.
- El ámbar no se usa: solo corresponde al «20» sobre Oxford Blue.
