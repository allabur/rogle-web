# Plantilla de apuntes, informe técnico y artículo

Formato Quarto a PDF (LaTeX con LuaLaTeX) con la marca vigente de ROGLE. Incluye portada con logotipo, resumen, índice, títulos y texto en Palatino (los títulos en negrita; lo secundario, en el mismo Palatino), fórmulas en Pagella, tablas y figuras con pies numerados, citas con bibliografía, y cabecera y pie con logotipo y paginación.

El diseño está en la extensión `rogle-notes` (`_extensions/rogle-notes/`), con el formato `rogle-notes-pdf`. Esta carpeta solo tiene el ejemplo.

## Uso

En este repositorio, desde la raíz:

```bash
quarto render plantillas/informe/template.qmd
```

En una asignatura o cualquier proyecto Quarto, instala las extensiones una vez. El repositorio es privado: `quarto add allabur/rogle` no funciona. Desde una copia local de este repositorio:

```bash
quarto add ~/Developer/rogle
```

Sin copia local, mira la alternativa con `gh` en el [README principal](../../README.md#plantillas).

y usa el formato en cada documento:

```yaml
---
title: "Planificación maestra de la producción"
subtitle: "Apuntes del tema 4"
abstract: |
  Resumen de los apuntes.
format: rogle-notes-pdf
---
```

Requisitos: Quarto 1.5 o superior y LuaLaTeX. No hace falta Jupyter: la figura de ejemplo es un PNG (`figura.py` lo regenera).

## Contenido

En `_extensions/rogle-notes/`:

- `_extension.yml`: el formato `rogle-notes-pdf` (A4, 11 pt, índice, secciones numeradas, pies de tabla arriba y de figura abajo).
- `rogle-notes.lua`: carga `header.tex` con la ruta de `resources/`. Así funciona en cualquier carpeta y en cualquier proyecto.
- `header.tex`: preámbulo (colores, fuentes, cabecera, pie, pies de figura).
- `partials/title.tex`: portada. Lee título, subtítulo, autores, afiliaciones y fecha del YAML.
- `resources/`: logotipo de la marca vigente en PDF y `rogle-colors.sty`, copias de `brand/`.

En esta carpeta:

- `template.qmd`: ejemplo con portada, resumen, tres secciones, tabla, figura, fórmula, código y bibliografía.
- `refs.bib`: bibliografía ficticia.
- `muestra/`: PDF de muestra y PNG de sus páginas.

## Notas

- `brand/adoptar.sh` actualiza el logotipo de la extensión. `web/tests/test_extensiones.py` comprueba que las copias coinciden con `brand/`.
- Las fuentes siguen el sistema de `brand/latex/rogle20-fonts.sty`: Palatino del sistema, con TeX Gyre Pagella de TeX Live como respaldo. Las fórmulas usan TeX Gyre Pagella Math. Esa variante evita el choque de `newpxmath` con `unicode-math`, que la plantilla de Quarto carga con LuaLaTeX.
- El ámbar no se usa: solo corresponde al «20» sobre Oxford Blue.
