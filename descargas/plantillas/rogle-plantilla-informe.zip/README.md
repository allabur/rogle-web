# Plantilla de Informe (transferencia)

Formato Quarto a PDF (LuaLaTeX) con la marca vigente de ROGLE para el Informe: el documento que el grupo entrega a una entidad fuera de la universidad. Es el único tipo del ámbito «transferencia». Lleva portada con el logotipo, resumen, índice, títulos y texto en Palatino (los títulos en negrita), fórmulas en Pagella, tablas y figuras con pies numerados, citas con bibliografía y cabeceras de texto en las páginas interiores.

El diseño está en la extensión `rogle-article` (`_extensions/rogle-article/`), con el formato `rogle-article-pdf`. Esta carpeta solo tiene el ejemplo. Las opciones completas, comunes a todos los tipos de obra, están en [`plantillas/articulo/README.md`](../articulo/README.md).

## Uso

En este repositorio, desde la raíz:

```bash
quarto render plantillas/informe/template.qmd
```

En otro proyecto Quarto, instala las extensiones una vez. El repositorio es privado: `quarto add allabur/rogle` no funciona. Desde una copia local de este repositorio:

```bash
quarto add ~/Developer/rogle
```

Sin copia local, mira la alternativa con `gh` en el [README principal](../../README.md#plantillas).

Y usa el formato en cada documento:

```yaml
---
title: "Planificación maestra de la producción"
subtitle: "Informe para la entidad"
rogle:
  tipo: informe
  destinatario: Nombre de la entidad
  proyecto: Referencia del contrato o del proyecto
report-number: "2026-01"
abstract: |
  Resumen del informe.
format: rogle-article-pdf
---
```

Requisitos: Quarto 1.5 o superior y LuaLaTeX. No hace falta Jupyter: la figura de ejemplo es un PNG (`figura.py` lo regenera).

## Claves propias del Informe

| Clave | Qué hace |
|---|---|
| `rogle.tipo: informe` | Fija el ámbito «transferencia», la portada completa (`rogle-mode: cover`) y el índice |
| `rogle.destinatario` | Entidad a la que se entrega el informe |
| `rogle.proyecto` | Referencia del contrato o del proyecto |
| `report-number` | Número del informe |
| `license` | Por defecto, «Todos los derechos reservados». Cualquier texto vale; los nombres de Creative Commons llevan icono y enlace |
| `toc: false` | Quita el índice |

`rogle-mode` cambia la primera página (`preprint`, `workingpaper`, `widemargin` o `cover`). `paper` elige el papel (`a4`, `letter` o `17x24`).

## Contenido

En esta carpeta:

- `template.qmd`: ejemplo con portada, resumen, tres secciones, tabla, figura, fórmula, código y bibliografía.
- `refs.bib`: bibliografía ficticia.
- `figura.py` y `figura-coste.png`: la figura de ejemplo y su generador.
- `muestra/`: PDF de muestra y PNG de sus páginas.

## Notas

- `brand/adoptar.sh` actualiza el logotipo de la extensión. `web/tests/test_extensiones.py` comprueba que las copias coinciden con `brand/`.
- Las fuentes siguen el sistema de `brand/latex/rogle20-fonts.sty`: Palatino del sistema, con TeX Gyre Pagella de TeX Live como respaldo. Las fórmulas usan TeX Gyre Pagella Math. Esa variante evita el choque de `newpxmath` con `unicode-math`, que la plantilla de Quarto carga con LuaLaTeX.
- El ámbar no se usa: solo corresponde al «20» sobre Oxford Blue.
