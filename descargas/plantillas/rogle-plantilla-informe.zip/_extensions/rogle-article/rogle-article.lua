-- rogle-article.lua: short documents of the ROGLE group (formats rogle-article-pdf and -html):
-- teaching (Nota Técnica, Caso Docente, Práctica), research (artículo, preprint, documento de
-- trabajo) and transfer (Informe). See plantillas/ESPECIFICACION.md.
-- Port of lacort-article.lua (Alberto Lacort's personal brand), PDF part only: reads the front
-- matter once and feeds rogle-article.cls (mode, paper, authors, metadata, citation, end matter).

-- Creative Commons licences: the ccicons command and the path of the deed.
local CC = {
  ["CC BY"] = { "\\ccby", "by" }, ["CC BY-SA"] = { "\\ccbysa", "by-sa" },
  ["CC BY-ND"] = { "\\ccbynd", "by-nd" }, ["CC BY-NC"] = { "\\ccbync", "by-nc" },
  ["CC BY-NC-SA"] = { "\\ccbyncsa", "by-nc-sa" }, ["CC BY-NC-ND"] = { "\\ccbyncnd", "by-nc-nd" },
  ["CC0"] = { "\\cczero", "zero" },
}
local CC_VERSION = "4.0"
local DEFAULT_LICENSE = {
  docencia = "CC BY-NC-SA 4.0",
  transferencia = { es = "Todos los derechos reservados", en = "All rights reserved" },
}
-- Work types: scope, label, and the first page and table of contents they have by default
-- (those of the retired formats rogle-notes, rogle-lab and rogle-lab-case).
local TYPES = {
  ["nota-tecnica"] = { scope = "docencia", es = "Nota Técnica", en = "Technical Note", mode = "cover", toc = true },
  ["caso-docente"] = { scope = "docencia", es = "Caso Docente", en = "Teaching Case", mode = "preprint", toc = false },
  ["practica"] = { scope = "docencia", es = "Práctica", en = "Lab Assignment", mode = "preprint", toc = true },
  ["articulo"] = { scope = "investigacion", es = "Artículo", en = "Article", mode = "preprint", toc = false },
  ["preprint"] = { scope = "investigacion", es = "Preprint", en = "Preprint", mode = "preprint", toc = false },
  ["documento-trabajo"] = { scope = "investigacion", es = "Documento de trabajo", en = "Working Paper", mode = "workingpaper", toc = false },
  ["informe"] = { scope = "transferencia", es = "Informe", en = "Report", mode = "cover", toc = true },
}
-- With rogle.ambito alone: research is a preprint and transfer a report. A teaching document
-- that is none of the three types (an exam, a problem set) carries no type label.
local DEFAULT_TYPE = { investigacion = "preprint", transferencia = "informe" }
local TEACHING = { scope = "docencia", mode = "preprint", toc = true }
-- Same default as \rogleart@publisher in rogle-article.cls.
local DEFAULT_PUBLISHER = "Grupo ROGLE, Universitat Politècnica de València"
local MODES = { preprint = true, workingpaper = true, widemargin = true, cover = true }
local PAPERS = { a4 = "a4paper", letter = "letterpaper", ["17x24"] = "trim1724" }

local LABELS = {
  es = {
    abstract = "Resumen", other_abstract = "Abstract",
    keywords = "Palabras clave", other_keywords = "Keywords",
    cite = "Cómo citar", highlights = "Puntos clave", correspondence = "Correspondencia",
    version = "Versión", published = "Publicado", licensed = "Distribuido bajo licencia",
    backmatter = "Información adicional", funding = "Financiación",
    credit = "Contribución de los autores (CRediT)", conflicts = "Conflicto de intereses",
    data = "Disponibilidad de datos", code = "Disponibilidad de código",
    ai = "Uso de inteligencia artificial", conjunction = " y ",
    course_year = "Curso", in_container = "En", version_lower = "versión", updated = "actualizada",
  },
  en = {
    abstract = "Abstract", other_abstract = "Resumen",
    keywords = "Keywords", other_keywords = "Palabras clave",
    cite = "How to cite", highlights = "Highlights", correspondence = "Correspondence",
    version = "Version", published = "Published", licensed = "Licensed under",
    backmatter = "Additional information", funding = "Funding",
    credit = "Author contributions (CRediT)", conflicts = "Conflicts of interest",
    data = "Data availability", code = "Code availability",
    ai = "Use of artificial intelligence", conjunction = ", & ",
    course_year = "Academic year", in_container = "In", version_lower = "version", updated = "updated",
  },
}
-- ACIF acknowledgement (spec 7.5): `funding: acif` writes it in the document language.
local ACIF = {
  es = "Este trabajo ha sido realizado con el apoyo de una subvención de la Generalitat Valenciana para la contratación de personal investigador predoctoral (CIACIF/2022/248), cofinanciada por el Fondo Social Europeo Plus (FSE+).",
  en = "This work was supported by the Generalitat Valenciana through a predoctoral research contract grant (CIACIF/2022/248), co-funded by the European Social Fund Plus (ESF+).",
}
local BACKMATTER = {
  { "funding", "funding" }, { "credit", "credit" }, { "conflicts", "conflicts" },
  { "data-availability", "data" }, { "code-availability", "code" }, { "ai-use", "ai" },
}
local CLASS_FIELDS = {
  { "funding", "funding" }, { "credit", "credit" }, { "conflicts", "conflicts" },
  { "data-availability", "dataavailability" }, { "code-availability", "codeavailability" },
  { "ai-use", "aiuse" },
}

local function is_pdf()
  return quarto.doc.is_format("latex")
end

-- A wrong or missing mandatory field stops the render.
local function fail(message)
  io.stderr:write("ERROR (rogle-article): " .. message .. "\n")
  os.exit(1)
end

local function str(value)
  return value and pandoc.utils.stringify(value) or ""
end

-- Any metadata value to Blocks, then to the target format.
local function blocks(value)
  local kind = pandoc.utils.type(value)
  if kind == "Blocks" then
    return value
  elseif kind == "Inlines" then
    return pandoc.Blocks({ pandoc.Plain(value) })
  end
  return pandoc.Blocks({ pandoc.Plain(pandoc.Inlines(str(value))) })
end

local function render(value, format)
  if value == nil then
    return ""
  end
  local text = pandoc.write(pandoc.Pandoc(blocks(value)), format)
  return (text:gsub("%s+$", ""))
end

local function list(value)
  if value == nil then
    return {}
  end
  if pandoc.utils.type(value) == "List" then
    local items = {}
    for _, item in ipairs(value) do
      table.insert(items, str(item))
    end
    return items
  end
  return { str(value) }
end

-- Each item of a list rendered in the target format, joined.
local function joined(value, format, separator)
  if value == nil then
    return ""
  end
  local items = pandoc.utils.type(value) == "List" and value or { value }
  local out = {}
  for _, item in ipairs(items) do
    table.insert(out, render(item, format))
  end
  return table.concat(out, separator)
end

local function escape_attr(text)
  return (text:gsub("&", "&amp;"):gsub('"', "&quot;"):gsub("<", "&lt;"))
end

-- Keys of the retired rogle-citym1724 format, accepted as synonyms. The rogle-article key wins.
local SYNONYMS = {
  { "title-en", "title-translated" }, { "title-running", "shorttitle" },
  { "funding-statement", "funding" }, { "recibido", "received" }, { "aceptado", "accepted" },
}

local function field(value, key)
  if pandoc.utils.type(value) == "table" then
    return value[key]
  end
  return nil
end

-- Scope and work type, from rogle.ambito and rogle.tipo. One is enough: the type fixes the scope.
local function work(meta)
  local kind = str(field(meta.rogle, "tipo"))
  local scope = str(field(meta.rogle, "ambito"))
  if kind == "" and scope == "" then
    fail("falta rogle.tipo (nota-tecnica, caso-docente, practica, articulo, preprint, documento-trabajo, informe) o rogle.ambito (docencia, investigacion, transferencia).")
  end
  if kind == "" and scope == "docencia" then
    return "", TEACHING
  end
  if kind == "" then
    kind = DEFAULT_TYPE[scope] or fail("rogle.ambito no válido: «" .. scope .. "». Valores: docencia, investigacion, transferencia.")
  end
  local entry = TYPES[kind] or fail("rogle.tipo no válido: «" .. kind .. "».")
  if scope ~= "" and scope ~= entry.scope then
    fail("rogle.tipo «" .. kind .. "» es del ámbito " .. entry.scope .. ", no de " .. scope .. ".")
  end
  return kind, entry
end

-- Licence: `license` as text or as name and url. Teaching: CC BY-NC-SA 4.0 by default.
-- Transfer: all rights reserved by default. Research: mandatory, no default.
local function license(meta, entry, key)
  -- Quarto turns `license: text` into a table with text, type and url.
  local value = meta.license
  if pandoc.utils.type(value) == "List" then
    value = value[1]
  end
  local name = str(field(value, "name") or field(value, "text")
    or (pandoc.utils.type(value) ~= "table" and value or nil))
  local url = str(field(value, "url"))
  if name == "" then
    local default = DEFAULT_LICENSE[entry.scope]
    if default == nil then
      fail("un documento de investigación necesita licencia: añade `license: CC BY 4.0`, la que pida la revista o el congreso, o «Todos los derechos reservados».")
    end
    name = type(default) == "table" and default[key] or default
  end
  local base, version = name:match("^(CC[%u%-% ]-[%u0])%s*([%d%.]*)$")
  local known = base and CC[base]
  if not known then
    return { icon = "", name = name, url = url }
  end
  if url == "" then
    url = base == "CC0" and "https://creativecommons.org/publicdomain/zero/1.0/"
      or ("https://creativecommons.org/licenses/" .. known[2] .. "/" .. (version ~= "" and version or CC_VERSION) .. "/")
  end
  return { icon = known[1], name = name, url = url }
end

local function synonyms(meta)
  -- Keys of the retired rogle-lab and rogle-lab-case: subject and the copyright block.
  if meta.subject ~= nil and pandoc.utils.type(meta.course) ~= "table" then
    meta.course = { subject = meta.subject }
  elseif meta.subject ~= nil and meta.course.subject == nil then
    meta.course.subject = meta.subject
  end
  meta["rights-holder"] = meta["rights-holder"] or field(meta.copyright, "holder")
  meta["citation-year"] = meta["citation-year"] or field(meta.copyright, "year")
  for _, pair in ipairs(SYNONYMS) do
    if meta[pair[2]] == nil then
      meta[pair[2]] = meta[pair[1]]
    end
  end
  -- CITYM: abstract and keywords in English, resumen and palabras-clave in Spanish.
  -- rogle-article: abstract and keywords in the language of lang, the -translated keys in the other.
  if meta.resumen == nil and meta["palabras-clave"] == nil then
    return
  end
  if str(meta.lang):sub(1, 2) == "en" then
    meta["abstract-translated"] = meta["abstract-translated"] or meta.resumen
    meta["keywords-translated"] = meta["keywords-translated"] or meta["palabras-clave"]
  else
    meta["abstract-translated"] = meta["abstract-translated"] or meta.abstract
    meta["keywords-translated"] = meta["keywords-translated"] or meta.keywords
    meta.abstract = meta.resumen or meta.abstract
    meta.keywords = meta["palabras-clave"] or meta.keywords
  end
end

-- Authors ------------------------------------------------------------------
local function authors(meta)
  local result = {}
  for _, author in ipairs(meta["by-author"] or {}) do
    local numbers = {}
    for _, affiliation in ipairs(author.affiliations or {}) do
      table.insert(numbers, str(affiliation.number))
    end
    local corresponding = author.attributes and author.attributes.corresponding
    table.insert(result, {
      literal = str(author.name and author.name.literal),
      given = str(author.name and author.name.given),
      family = str(author.name and author.name.family),
      orcid = str(author.orcid),
      email = str(author.email),
      corresponding = corresponding == true or str(corresponding) == "true",
      affiliations = numbers,
    })
  end
  -- A page of a course without authors: the teachers of the course block sign it.
  if #result == 0 then
    for _, teacher in ipairs(field(meta.course, "teachers") or {}) do
      local name = str(field(teacher, "name") or teacher)
      table.insert(result, { literal = name, given = "", family = "", orcid = "", email = "",
        corresponding = false, affiliations = {} })
    end
  end
  -- Without a corresponding flag, the first author with an email corresponds.
  local any = false
  for _, author in ipairs(result) do
    any = any or author.corresponding
  end
  if not any then
    for _, author in ipairs(result) do
      if author.email ~= "" then
        author.corresponding = true
        break
      end
    end
  end
  return result
end

local function initials(given)
  local parts = {}
  for word in given:gmatch("[^%s]+") do
    local pieces = {}
    for piece in word:gmatch("[^-]+") do
      table.insert(pieces, utf8.char(utf8.codepoint(piece, 1)) .. ".")
    end
    table.insert(parts, table.concat(pieces, "-"))
  end
  return table.concat(parts, " ")
end

-- APA 7 author list: "Family, G." joined with commas and the last conjunction.
local function apa_authors(people, labels)
  local names = {}
  for _, person in ipairs(people) do
    if person.family ~= "" then
      table.insert(names, person.family .. ", " .. initials(person.given))
    else
      table.insert(names, person.literal)
    end
  end
  if #names <= 1 then
    return names[1] or ""
  end
  local conjunction = labels.conjunction
  if #names == 2 and conjunction == " y " then
    return names[1] .. conjunction .. names[2]
  end
  return table.concat(names, ", ", 1, #names - 1) .. conjunction .. names[#names]
end

local function running_authors(people, labels)
  local families = {}
  for _, person in ipairs(people) do
    table.insert(families, person.family ~= "" and person.family or person.literal)
  end
  if #families > 2 then
    return families[1] .. " et al."
  end
  return table.concat(families, labels.conjunction == " y " and " y " or " and ")
end

-- Shared values --------------------------------------------------------------
local function values(meta)
  local lang = str(meta.lang)
  local key = lang:sub(1, 2) == "en" and "en" or "es"
  local kind, entry = work(meta)
  local labels = LABELS[key]
  local people = authors(meta)
  local date = str(meta.date)
  local identifier = str(meta["persistent-id"])
  local doi = str(meta.doi)
  if doi ~= "" then
    identifier = "https://doi.org/" .. doi
  end
  local mode = str(meta["rogle-mode"])
  if mode == "" then
    mode = entry.mode
  elseif not MODES[mode] then
    fail("rogle-mode no válido: «" .. mode .. "». Valores: preprint, workingpaper, widemargin, cover.")
  end
  local paper = PAPERS[str(meta.paper)] or "a4paper"
  return {
    key = key,
    kind = kind,
    entry = entry,
    license = license(meta, entry, key),
    labels = labels,
    people = people,
    date = date,
    -- The date may come formatted (date-format: long): the year is its four-digit number.
    year = date:match("%d%d%d%d") or str(meta["citation-year"]),
    updated = str(meta["last-updated"]),
    isbn = str(meta.isbn),
    issn = str(meta.issn),
    identifier = identifier,
    doi = doi,
    mode = mode,
    paper = paper,
    title = str(meta.title),
    series = str(meta.series),
    version = str(meta["document-version"]),
    status = str(meta["document-status"]),
    publisher = meta.publisher and str(meta.publisher) or DEFAULT_PUBLISHER,
    keywords = table.concat(list(meta.keywords), ", "),
    keywords_translated = table.concat(list(meta["keywords-translated"]), ", "),
    running = meta["authors-running"] and str(meta["authors-running"]) or running_authors(people, labels),
  }
end

-- "Cómo citar" in APA 7, unless the document gives how-to-cite.
local function citation(meta, v, format)
  if meta["how-to-cite"] then
    return render(meta["how-to-cite"], format)
  end
  local latex = format == "latex"
  local function emph(text)
    return latex and ("\\emph{" .. text .. "}") or ("<em>" .. text .. "</em>")
  end
  local names = meta["authors-citation"] and str(meta["authors-citation"]) or apa_authors(v.people, v.labels)
  if latex then
    names = names:gsub("\\?&", "\\&")
  end
  local container = render(meta["publication-container"], format)
  -- A chapter or paper: plain title and the container in italics, with the pages (APA 7).
  local text = names .. " (" .. v.year .. "). " .. (container ~= "" and v.title or emph(v.title))
  if v.updated ~= "" then
    local note = v.labels.updated .. " " .. v.updated
    if v.version ~= "" then
      note = v.labels.version_lower .. " " .. v.version .. ", " .. note
    end
    text = text .. " (" .. note .. ")"
  end
  if container ~= "" then
    text = text .. ". " .. v.labels.in_container .. " " .. emph(container)
    if latex then
      text = text .. " (\\roglepagerange)"
    end
  elseif v.series ~= "" then
    text = text .. " (" .. v.series .. ")"
  end
  text = text .. "."
  if v.publisher ~= "" then
    text = text .. " " .. v.publisher .. "."
  end
  if v.isbn ~= "" then
    text = text .. " ISBN: " .. v.isbn .. "."
  end
  if v.issn ~= "" then
    text = text .. " ISSN: " .. v.issn .. "."
  end
  if v.identifier ~= "" then
    text = text .. (format == "latex" and (" \\url{" .. v.identifier .. "}")
      or (' <a href="' .. v.identifier .. '">' .. v.identifier .. "</a>"))
  end
  return text
end

-- Teaching block: one line per datum, the name of the programme in bold.
local function course(meta, labels)
  local data = meta.course
  if pandoc.utils.type(data) ~= "table" then
    return ""
  end
  local lines = {}
  local function line(value, bold)
    local text = render(value, "latex")
    if text ~= "" then
      table.insert(lines, (bold and ("\\textbf{" .. text .. "}") or text) .. "\\par ")
    end
  end
  local function coded(value, code)
    local text = render(value, "latex")
    local number = render(code, "latex")
    if text ~= "" and number ~= "" then
      text = text .. " (" .. number .. ")"
    end
    if text ~= "" then
      table.insert(lines, text .. "\\par ")
    end
  end
  line(data.name, true)
  coded(data.subject, data.code)
  coded(data.degree, data["degree-code"])
  line(data.centre)
  line(data.institution)
  local year = render(data["academic-year"], "latex")
  local semester = render(data.semester, "latex")
  if year ~= "" then
    table.insert(lines, labels.course_year .. " " .. year .. (semester ~= "" and (", " .. semester) or "") .. "\\par ")
  elseif semester ~= "" then
    table.insert(lines, semester .. "\\par ")
  end
  line(data.dates)
  return table.concat(lines, "")
end

-- PDF: commands for rogle-article.cls -----------------------------------------
local function latex_preamble(meta, v)
  local lines = { "\\logopath{logos/}" }
  local function add(command, value)
    if value ~= nil and value ~= "" then
      table.insert(lines, "\\" .. command .. "{" .. value .. "}")
    end
  end
  -- Work type, with the lesson in teaching. Research says it with the series and the status.
  if v.entry.scope ~= "investigacion" then
    local label = v.entry[v.key] or ""
    local lesson = render(field(meta.rogle, "leccion"), "latex")
    add("worktype", (label ~= "" and lesson ~= "") and (label .. ", " .. lesson) or (label .. lesson))
  end
  table.insert(lines, string.format("\\license{%s}{%s}{%s}", v.license.icon, v.license.name, v.license.url))
  add("adaptation", render(field(meta.rogle, "adaptacion"), "latex"))
  add("reportnumber", render(meta["report-number"], "latex"))
  add("recipient", render(field(meta.rogle, "destinatario"), "latex"))
  add("project", render(field(meta.rogle, "proyecto"), "latex"))
  add("issn", v.issn)
  add("translatedtitle", render(meta["title-translated"], "latex"))
  add("shorttitle", render(meta.shorttitle or meta.title, "latex"))
  add("runningauthors", v.running)
  for _, affiliation in ipairs(meta["by-affiliation"] or {}) do
    add("affiliation", render(affiliation.name, "latex"))
  end
  for _, person in ipairs(v.people) do
    table.insert(lines, string.format("\\addauthor{%s}{%s}{%s}{%s}", person.literal, person.orcid,
      table.concat(person.affiliations, ","), person.corresponding and person.email or ""))
  end
  add("series", render(meta.series, "latex"))
  add("version", render(meta["document-version"], "latex"))
  add("pubdate", v.date)
  add("status", render(meta["document-status"], "latex"))
  add("pubyear", v.year)
  add("lastupdated", render(meta["last-updated"], "latex"))
  add("received", render(meta.received, "latex"))
  add("accepted", render(meta.accepted, "latex"))
  add("isbn", v.isbn)
  add("firstpage", str(meta.firstpage))
  add("copyrightholder", render(meta["rights-holder"], "latex"))
  add("courseinfo", course(meta, v.labels))
  add("publisher", render(meta.publisher, "latex"))
  if v.doi ~= "" then
    add("doi", v.doi)
  else
    add("identifier", v.identifier)
  end
  add("howtocite", citation(meta, v, "latex"))
  add("keywords", joined(meta.keywords, "latex", ", "))
  add("translatedkeywords", joined(meta["keywords-translated"], "latex", ", "))
  add("abstracttext", render(meta.abstract, "latex"))
  add("translatedabstract", render(meta["abstract-translated"], "latex"))
  if meta.highlights then
    add("highlights", "\\item " .. joined(meta.highlights, "latex", " \\item "))
  end
  for _, pair in ipairs(CLASS_FIELDS) do
    add(pair[2], render(meta[pair[1]], "latex"))
  end
  return table.concat(lines, "\n")
end

local function append_header(meta, text)
  local includes = meta["header-includes"]
  if includes == nil then
    includes = pandoc.MetaList({})
  elseif pandoc.utils.type(includes) ~= "List" then
    includes = pandoc.MetaList({ includes })
  end
  includes:insert(pandoc.MetaBlocks({ pandoc.RawBlock("latex", text) }))
  meta["header-includes"] = includes
end

-- Filter ---------------------------------------------------------------------
local has_backmatter = false

function Meta(meta)
  synonyms(meta)
  local v = values(meta)
  -- Teaching has no funding (plantillas/ESPECIFICACION.md).
  if v.entry.scope == "docencia" and meta.funding ~= nil then
    io.stderr:write("WARNING (rogle-article): una obra de docencia no lleva financiación; se omite `funding`.\n")
    meta.funding = nil
  end
  -- The types that had a table of contents in the retired formats keep it, unless toc says no.
  if meta.toc == nil and v.entry.toc then
    meta.toc = true
  end
  if not is_pdf() then
    return meta
  end
  if str(meta.funding) == "acif" then
    meta.funding = pandoc.MetaString(ACIF[v.key])
  end
  for _, pair in ipairs(BACKMATTER) do
    has_backmatter = has_backmatter or meta[pair[1]] ~= nil
  end
  local options = pandoc.MetaList({ pandoc.MetaString(v.mode), pandoc.MetaString(v.paper) })
  if v.key == "en" then
    options:insert(pandoc.MetaString("english"))
  end
  meta.classoption = options
  append_header(meta, latex_preamble(meta, v))
  return meta
end

-- Brand: table headers in bold (brand/BRAND.md, typography).
local BOLD = {
  Plain = function(el) return pandoc.Plain({ pandoc.Strong(el.content) }) end,
  Para = function(el) return pandoc.Para({ pandoc.Strong(el.content) }) end,
}

function Table(tbl)
  if not is_pdf() then
    return nil
  end
  for _, row in ipairs(tbl.head.rows) do
    for _, cell in ipairs(row.cells) do
      cell.contents = cell.contents:walk(BOLD)
    end
  end
  return tbl
end

function Pandoc(doc)
  if not is_pdf() or not has_backmatter then
    return nil
  end
  -- The end matter goes before the reference list (a Div with id refs and its heading), or last.
  local position = #doc.blocks + 1
  for index, block in ipairs(doc.blocks) do
    if block.t == "Div" and block.identifier == "refs" then
      position = index
      if index > 1 and doc.blocks[index - 1].t == "Header" then
        position = index - 1
      end
      break
    end
  end
  doc.blocks:insert(position, pandoc.RawBlock("latex", "\\makebackmatter"))
  return doc
end

return {
  { Meta = Meta, Table = Table },
  { Pandoc = Pandoc },
}
