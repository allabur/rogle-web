% rogle-article.cls -- article and preprint class of the ROGLE group (UPV).
% Port of lacort-article.cls (Alberto Lacort's personal brand, spec 8.7) to the ROGLE brand:
% colours of rogle-colors.sty, fonts of rogle20-fonts.sty, ROGLE logos. Adds the paper options.
%
% Usage:  \documentclass{rogle-article}                     % preprint mode, A4, Spanish
%         \documentclass[workingpaper]{rogle-article}       % cover page with the UPV lockup
%         \documentclass[widemargin,english]{rogle-article}
%         \documentclass[cover]{rogle-article}              % full cover page, as the former rogle-notes
%         \documentclass[letterpaper]{rogle-article}        % paper: a4paper (default), letterpaper, trim1724
% Engines: LuaLaTeX (system brand fonts) and pdfLaTeX. Logos: call \logopath{<dir>/} (the
% rogle-article Quarto filter does it) or put logos/ on TEXINPUTS.
% Metadata commands (preamble): see the "Metadata" section below. They feed the
% first page, the running heads, the citation box and the PDF Info and XMP.
\NeedsTeXFormat{LaTeX2e}[2022/06/01]
\ProvidesClass{rogle-article}[2026/11/18 v2.0.0 ROGLE short document: teaching, research and transfer]

% ---------------------------------------------------------------------------
% Options
% ---------------------------------------------------------------------------
\def\rogleart@mode{preprint}
\def\rogleart@preprint{preprint}
\def\rogleart@workingpaper{workingpaper}
\def\rogleart@widemargin{widemargin}
\def\rogleart@cover{cover}
\newif\ifrogleart@english
\newif\ifrogleart@acif
\DeclareOption{preprint}{\let\rogleart@mode\rogleart@preprint}
\DeclareOption{workingpaper}{\let\rogleart@mode\rogleart@workingpaper}
\DeclareOption{widemargin}{\let\rogleart@mode\rogleart@widemargin}
\DeclareOption{cover}{\let\rogleart@mode\rogleart@cover}
\DeclareOption{english}{\rogleart@englishtrue}
\DeclareOption{spanish}{\rogleart@englishfalse}
\DeclareOption{acif}{\rogleart@aciftrue}
% Paper: A4 by default; US letter and the 17 x 24 cm trim of the CITYM books (Editorial UPV).
\def\rogleart@paper{a4paper}
\def\rogleart@trimname{trim1724}
\DeclareOption{a4paper}{\def\rogleart@paper{a4paper}}
\DeclareOption{letterpaper}{\def\rogleart@paper{letterpaper}}
\DeclareOption{trim1724}{\def\rogleart@paper{trim1724}}
\DeclareOption*{\ClassWarning{rogle-article}{Unknown option `\CurrentOption'}}
\ProcessOptions\relax
\newcommand{\rogleart@ifmode}[1]{%
  \expandafter\ifx\csname rogleart@#1\endcsname\rogleart@mode
    \expandafter\@firstoftwo\else\expandafter\@secondoftwo\fi}

\rogleart@ifmode{widemargin}
  {\LoadClass[11pt]{article}}
  {\LoadClass[11pt,twoside]{article}}

\ifrogleart@english
  \RequirePackage[spanish,english]{babel}
\else
  \RequirePackage[english,spanish,es-tabla]{babel}
\fi
\RequirePackage{iftex}
\RequirePackage[table]{xcolor}
\RequirePackage{amsmath}
\RequirePackage{rogle-colors}
\RequirePackage{rogle20-fonts}
% tinte-claro of brand/BRAND.md: backgrounds of the citation and highlights boxes.
\definecolor{rogleTinteClaro}{HTML}{F3F4FA}
\RequirePackage[most]{tcolorbox}
\tcbset{rogle/base/.style={enhanced, sharp corners, boxrule=0pt, leftrule=2.5pt, colframe=#1,
  left=4mm, right=4mm, top=2mm, bottom=2mm, before skip=6pt, after skip=6pt}}

% ---------------------------------------------------------------------------
% Page (spec 8.7)
% ---------------------------------------------------------------------------
\RequirePackage{geometry}
\ifx\rogleart@paper\rogleart@trimname
  % 17 x 24 cm: the proportions of the A4 layout on the smaller page.
  \rogleart@ifmode{widemargin}
    {\geometry{paperwidth=170mm, paperheight=240mm, left=16mm, textwidth=98mm, marginparsep=6mm,
       marginparwidth=42mm, top=22mm, bottom=20mm, headsep=8mm, footskip=11mm, headheight=14pt}}
    {\geometry{paperwidth=170mm, paperheight=240mm, inner=20mm, outer=20mm, top=22mm, bottom=20mm,
       headsep=8mm, footskip=11mm, headheight=14pt}}
\else
  \rogleart@ifmode{widemargin}
    {\geometry{\rogleart@paper, left=22mm, textwidth=118mm, marginparsep=8mm,
       marginparwidth=52mm, top=30mm, bottom=28mm, headsep=10mm, footskip=14mm, headheight=14pt}}
    {\geometry{\rogleart@paper, inner=27mm, outer=27mm, top=30mm, bottom=28mm,
       headsep=10mm, footskip=14mm, headheight=14pt}}
\fi

\RequirePackage{fancyhdr}
\RequirePackage{graphicx}
\RequirePackage{booktabs}
\RequirePackage{caption}
% Section titles stay in oxford-blue; the body text is black.
\RequirePackage{sectsty}
\allsectionsfont{\color{rogleOxfordBlue}}
\RequirePackage{lastpage}
\RequirePackage{qrcode}
\RequirePackage{orcidlink}
\RequirePackage{ccicons}
\RequirePackage{hyperxmp}
\RequirePackage{hyperref}
\urlstyle{same}
% Brand colours: body text in black, titles in oxford-blue, links in indigo. After the preamble, so the link colours
% that Quarto's template sets do not win.
\AtBeginDocument{%
  \hypersetup{colorlinks=true, linkcolor=rogleIndigo, citecolor=rogleIndigo,
    urlcolor=rogleIndigo, filecolor=rogleIndigo}%
  \color{rogleNegro}}
\rogleart@ifmode{widemargin}{\RequirePackage{marginnote}}{}

% Logos: logos/ next to this class. Under LuaLaTeX, find them from this file's location;
% otherwise set \logopath{<dir>/}.
\ifdefined\directlua
  \edef\rogleart@logodir{\directlua{
    local path = kpse.find_file("rogle-article.cls", "tex") or ""
    tex.sprint((path:gsub("[^/]*$", "")) .. "logos/")}}
\else
  \def\rogleart@logodir{}
\fi
\newcommand{\logopath}[1]{\def\rogleart@logodir{#1}}
\newcommand{\rogleart@logo}[2]{\includegraphics[height=#1]{\rogleart@logodir#2}}
\newcommand{\rogleart@widelogo}[2]{\includegraphics[width=#1]{\rogleart@logodir#2}}

% ---------------------------------------------------------------------------
% Labels
% ---------------------------------------------------------------------------
\ifrogleart@english
  \def\rogleart@lang{en}
  \def\rogleart@abstractname{Abstract}
  \def\rogleart@otherabstractname{Resumen}
  \def\rogleart@keywordsname{Keywords}
  \def\rogleart@otherkeywordsname{Palabras clave}
  \def\rogleart@howtocitename{How to cite}
  \def\rogleart@highlightsname{Highlights}
  \def\rogleart@correspondencename{Correspondence}
  \def\rogleart@versionname{Version}
  \def\rogleart@publishedname{Published}
  \def\rogleart@updatedname{Updated}
  \def\rogleart@receivedname{Received}
  \def\rogleart@acceptedname{Accepted}
  \def\rogleart@reportname{Report no.}
  \def\rogleart@recipientname{Recipient}
  \def\rogleart@projectname{Project}
  \def\rogleart@licensedname{Licensed under}
  \def\rogleart@backmattername{Additional information}
  \def\rogleart@fundingname{Funding}
  \def\rogleart@creditname{Author contributions (CRediT)}
  \def\rogleart@conflictsname{Conflicts of interest}
  \def\rogleart@dataname{Data availability}
  \def\rogleart@codename{Code availability}
  \def\rogleart@ainame{Use of artificial intelligence}
\else
  \def\rogleart@lang{es-ES}
  \def\rogleart@abstractname{Resumen}
  \def\rogleart@otherabstractname{Abstract}
  \def\rogleart@keywordsname{Palabras clave}
  \def\rogleart@otherkeywordsname{Keywords}
  \def\rogleart@howtocitename{Cómo citar}
  \def\rogleart@highlightsname{Puntos clave}
  \def\rogleart@correspondencename{Correspondencia}
  \def\rogleart@versionname{Versión}
  \def\rogleart@publishedname{Publicado}
  \def\rogleart@updatedname{Actualizado}
  \def\rogleart@receivedname{Recibido}
  \def\rogleart@acceptedname{Aceptado}
  \def\rogleart@reportname{Informe n.º}
  \def\rogleart@recipientname{Destinatario}
  \def\rogleart@projectname{Proyecto}
  \def\rogleart@licensedname{Distribuido bajo licencia}
  \def\rogleart@backmattername{Información adicional}
  \def\rogleart@fundingname{Financiación}
  \def\rogleart@creditname{Contribución de los autores (CRediT)}
  \def\rogleart@conflictsname{Conflicto de intereses}
  \def\rogleart@dataname{Disponibilidad de datos}
  \def\rogleart@codename{Disponibilidad de código}
  \def\rogleart@ainame{Uso de inteligencia artificial}
\fi

% ---------------------------------------------------------------------------
% Metadata
% ---------------------------------------------------------------------------
\newcommand{\rogleart@field}[1]{%
  \expandafter\def\csname rogleart@#1\endcsname{}%
  \expandafter\newcommand\csname #1\endcsname[1]{%
    \expandafter\def\csname rogleart@#1\endcsname{##1}}}
\@for\rogleart@name:={translatedtitle,shorttitle,runningauthors,series,version,%
  pubdate,status,publisher,identifier,howtocite,keywords,translatedkeywords,%
  abstracttext,translatedabstract,highlights,funding,credit,conflicts,%
  dataavailability,codeavailability,aiuse,copyrightholder,%
  courseinfo,lastupdated,received,accepted,isbn,pubyear,%
  subtitle,worktype,issn,reportnumber,recipient,project,adaptation}\do{%
  \expandafter\rogleart@field\expandafter{\rogleart@name}}

% ACIF acknowledgement (spec 7.5): option acif fills \funding in the document language.
\ifrogleart@acif
  \ifrogleart@english
    \def\rogleart@funding{This work was supported by the Generalitat Valenciana through a predoctoral research contract grant (CIACIF/2022/248), co-funded by the European Social Fund Plus (ESF+).}
  \else
    \def\rogleart@funding{Este trabajo ha sido realizado con el apoyo de una subvención de la Generalitat Valenciana para la contratación de personal investigador predoctoral (CIACIF/2022/248), cofinanciada por el Fondo Social Europeo Plus (FSE+).}
  \fi
\fi

% DOI: sets the identifier and the PRISM DOI.
\def\rogleart@doi{}
\newcommand{\doi}[1]{\def\rogleart@doi{#1}\def\rogleart@identifier{https://doi.org/#1}}

% Licence: \license{icon}{name}{URL}. Without icon and URL the name is printed as it is
% (for example «Todos los derechos reservados»). Default: CC BY-NC-SA 4.0.
\newcommand{\license}[3]{\def\rogleart@licenseicon{#1}\def\rogleart@licensename{#2}%
  \def\rogleart@licenseurl{#3}}
\license{\ccbyncsa}{CC BY-NC-SA 4.0}{https://creativecommons.org/licenses/by-nc-sa/4.0/}
% Publisher by default: the group.
\def\rogleart@publisher{Grupo ROGLE, Universitat Polit\`ecnica de Val\`encia}

% Affiliations, numbered in order of declaration.
\newcounter{rogleart@affil}
\def\rogleart@affils{}
\newcommand{\affiliation}[1]{\stepcounter{rogleart@affil}%
  \edef\rogleart@tmp{\noexpand\textsuperscript{\arabic{rogleart@affil}}}%
  \expandafter\g@addto@macro\expandafter\rogleart@affils\expandafter{\rogleart@tmp#1\par}}

% Authors: \addauthor{Name}{ORCID or empty}{affiliation numbers}{email or empty}.
% An email marks the corresponding author.
\def\rogleart@authors{}
\def\rogleart@authornames{}
\def\rogleart@contact{}
\def\rogleart@correspondence{}
\newcommand{\addauthor}[4]{%
  \ifx\rogleart@authors\@empty\else\g@addto@macro\rogleart@authors{, }\fi
  \ifx\rogleart@authornames\@empty\def\rogleart@authornames{#1}%
  \else\g@addto@macro\rogleart@authornames{, #1}\fi
  \g@addto@macro\rogleart@authors{#1}%
  \if\relax\detokenize{#2}\relax\else\g@addto@macro\rogleart@authors{\,\orcidlink{#2}}\fi
  \if\relax\detokenize{#4}\relax
    \g@addto@macro\rogleart@authors{\textsuperscript{#3}}%
  \else
    \g@addto@macro\rogleart@authors{\textsuperscript{#3,*}}%
    \ifx\rogleart@contact\@empty\def\rogleart@contact{#4}\fi
    \g@addto@macro\rogleart@correspondence{\href{mailto:#4}{#4} }%
  \fi}

\def\rogleart@splitdate#1-#2\relax{#1}
% Year of the citation and the copyright: \pubyear, or the year of \pubdate.
\newcommand{\rogleart@year}{\ifx\rogleart@pubyear\@empty
  \expandafter\rogleart@splitdate\rogleart@pubdate-\relax\else\rogleart@pubyear\fi}
% Chapters and papers: \firstpage{n} numbers the first page; \roglepagerange gives the pages
% of the text for the citation, from the current page to the last one.
\newcommand{\firstpage}[1]{\AtBeginDocument{\setcounter{page}{#1}}}
\newcommand{\roglepagerange}{\ifcsname r@LastPage\endcsname
    \ifnum\value{page}=\getpagerefnumber{LastPage}\relax p.~\thepage
    \else pp.~\thepage--\pageref*{LastPage}\fi
  \else p.~\thepage\fi}

% ---------------------------------------------------------------------------
% PDF metadata: Info dictionary and XMP (spec 8.7)
% ---------------------------------------------------------------------------
\AtBeginDocument{%
  \ifx\rogleart@copyrightholder\@empty\let\rogleart@copyrightholder\rogleart@authornames\fi
  \hypersetup{
    pdftitle={\@title},
    pdfauthor={\rogleart@authornames},
    pdfsubject={\rogleart@abstracttext},
    pdfkeywords={\rogleart@keywords},
    pdflang={\rogleart@lang},
    pdfpublisher={\rogleart@publisher},
    pdfpublication={\rogleart@series},
    pdfidentifier={\rogleart@identifier},
    pdfurl={\rogleart@identifier},
    pdfdoi={\rogleart@doi},
    pdfisbn={\rogleart@isbn},
    pdfissn={\rogleart@issn},
    pdfcopyright={\textcopyright\ \rogleart@year\ \rogleart@copyrightholder. \rogleart@licensename.},
    pdflicenseurl={\rogleart@licenseurl},
    pdfversionid={\rogleart@version},
    pdfcontactemail={\rogleart@contact},
  }%
  % A document with a citation year only has no date for the metadata.
  \ifx\rogleart@pubdate\@empty\else\hypersetup{pdfdate={\rogleart@pubdate}}\fi}
% hyperxmp keeps Author and Keywords in XMP only; write them to the Info
% dictionary too, which most PDF readers and repositories show.
\AtEndDocument{%
  \pdfstringdef\rogleart@infoauthor{\rogleart@authornames}%
  \pdfstringdef\rogleart@infokeywords{\rogleart@keywords}%
  \ifLuaTeX
    \pdfextension info{/Author (\rogleart@infoauthor) /Keywords (\rogleart@infokeywords)}%
  \else
    \pdfinfo{/Author (\rogleart@infoauthor) /Keywords (\rogleart@infokeywords)}%
  \fi}

% ---------------------------------------------------------------------------
% Typography
% ---------------------------------------------------------------------------
% Title, authors and dates: centred, as in the CITYM papers. Left in the narrow column of
% widemargin and on the cover page.
\newcommand{\rogleart@align}{\centering}
\rogleart@ifmode{widemargin}{\renewcommand{\rogleart@align}{\raggedright}}{}
\rogleart@ifmode{cover}{\renewcommand{\rogleart@align}{\raggedright}}{}
\newcommand{\rogleart@titlefont}{\rogleart@align\hyphenpenalty=10000\rmfamily\bfseries
  \fontsize{18}{22}\selectfont\color{rogleOxfordBlue}}
\newcommand{\rogleart@subtitlefont}{\rogleart@align\hyphenpenalty=10000\rmfamily
  \fontsize{13}{16}\selectfont\color{rogleIndigo}}
\newcommand{\rogleart@translatedtitlefont}{\rogleart@align\hyphenpenalty=10000\rmfamily
  \itshape\fontsize{14}{17}\selectfont\color{rogleGrisUPV431}}
\newcommand{\rogleart@notefont}{\fontsize{9}{11}\selectfont}
\newcommand{\rogleart@labelfont}{\rmfamily\bfseries}
\newcommand{\rogleart@metafont}{\rogleart@notefont\rmfamily\color{rogleGrisUPV431}}
\newcommand{\rogleart@headfont}{\rogleart@notefont\rmfamily\itshape\color{rogleGrisUPV431}}
% Code blocks on tinte-claro, callouts and table rules in brand colours (from rogle-notes).
\RequirePackage{framed}
\colorlet{shadecolor}{rogleTinteClaro}
\AtBeginDocument{%
  \colorlet{quarto-callout-note-color}{rogleIndigoMedio}\colorlet{quarto-callout-note-color-frame}{rogleIndigoMedio}%
  \colorlet{quarto-callout-important-color}{rogleIndigo}\colorlet{quarto-callout-important-color-frame}{rogleIndigo}%
  \colorlet{quarto-callout-tip-color}{rogleGreen}\colorlet{quarto-callout-tip-color-frame}{rogleGreen}%
  \colorlet{quarto-callout-caution-color}{rogleRed}\colorlet{quarto-callout-caution-color-frame}{rogleRed}%
  \colorlet{quarto-callout-warning-color}{rogleGrisUPV431}\colorlet{quarto-callout-warning-color-frame}{rogleGrisUPV431}}
\DeclareCaptionFont{roglenine}{\fontsize{9}{11}\selectfont}
\captionsetup{font=roglenine, labelfont=bf, labelsep=period,
  justification=raggedright, singlelinecheck=false}
% widemargin: captions of figures and tables go in the margin.
\NewDocumentCommand{\rogleart@sidecaption}{om}{%
  \marginnote{\IfNoValueTF{#1}{\rogleart@caption{#2}}{\rogleart@caption[#1]{#2}}}}
\rogleart@ifmode{widemargin}{%
  \AddToHook{env/figure/begin}{\let\rogleart@caption\caption\let\caption\rogleart@sidecaption}%
  \AddToHook{env/table/begin}{\let\rogleart@caption\caption\let\caption\rogleart@sidecaption}}{}

% ---------------------------------------------------------------------------
% First-page components
% ---------------------------------------------------------------------------
\newcommand{\rogleart@grayrule}{{\color{rogleSeparador}\hrule height 0.4pt}}
\newcommand{\rogleart@qr}[1]{\ifx\rogleart@identifier\@empty\else
  \qrcode[height=#1]{\rogleart@identifier}\fi}
\newcommand{\rogleart@titles}{%
  {\rogleart@titlefont\@title\par}%
  \ifx\rogleart@subtitle\@empty\else
    \vspace{2.5mm}{\rogleart@subtitlefont\rogleart@subtitle\par}\fi
  \ifx\rogleart@translatedtitle\@empty\else
    \vspace{2mm}{\rogleart@translatedtitlefont\rogleart@translatedtitle\par}\fi}
\newcommand{\rogleart@authorsblock}{%
  {\rogleart@align\rogleart@authors\par}\vspace{2mm}%
  {\rogleart@notefont\color{rogleGrisUPV431}\rogleart@align\rogleart@affils
   \ifx\rogleart@correspondence\@empty\else
     \textsuperscript{*}\rogleart@correspondencename: \rogleart@correspondence\par\fi}}
\newcommand{\rogleart@dateline}{{\rogleart@metafont\rogleart@align
  \ifx\rogleart@received\@empty\else\rogleart@receivedname: \rogleart@received. \fi
  \ifx\rogleart@accepted\@empty\else\rogleart@acceptedname: \rogleart@accepted. \fi
  \ifx\rogleart@version\@empty\else\rogleart@versionname\ \rogleart@version. \fi
  \ifx\rogleart@lastupdated\@empty\else\rogleart@updatedname: \rogleart@lastupdated. \fi
  \ifx\rogleart@pubdate\@empty\else\rogleart@publishedname: \rogleart@pubdate. \fi
  \ifx\rogleart@status\@empty\else\rogleart@status.\fi\par}}
\newcommand{\rogleart@citebox}{\ifx\rogleart@howtocite\@empty\else
  \noindent\colorbox{rogleTinteClaro}{\parbox{\dimexpr\linewidth-2\fboxsep}{%
    \rogleart@notefont\raggedright{\rogleart@labelfont\rogleart@howtocitename:} \rogleart@howtocite}}\par\fi}
\newcommand{\rogleart@highlightsbox}{\ifx\rogleart@highlights\@empty\else
  \begin{tcolorbox}[rogle/base=rogleIndigoMedio, colback=rogleTinteClaro]
    {\rogleart@labelfont\rogleart@highlightsname}\par\smallskip
    \rogleart@notefont\begin{itemize}\setlength{\itemsep}{0pt}\rogleart@highlights\end{itemize}
  \end{tcolorbox}\fi}
% Abstracts: English first, as in the CITYM papers; the one in the other language in italics.
\newcommand{\rogleart@mainabstract}{%
  \ifx\rogleart@abstracttext\@empty\else
    \noindent{\rogleart@labelfont\rogleart@abstractname}\par\smallskip
    \noindent\rogleart@abstracttext\par\smallskip
    \ifx\rogleart@keywords\@empty\else
      \noindent{\rogleart@labelfont\rogleart@keywordsname:} \rogleart@keywords.\par\fi
    \medskip
  \fi}
\newcommand{\rogleart@otherabstract}{%
  \ifx\rogleart@translatedabstract\@empty\else
    \noindent{\rogleart@labelfont\rogleart@otherabstractname}\par\smallskip
    \noindent{\itshape\rogleart@translatedabstract}\par\smallskip
    \ifx\rogleart@translatedkeywords\@empty\else
      \noindent{\rogleart@labelfont\rogleart@otherkeywordsname:} {\itshape\rogleart@translatedkeywords}.\par\fi
    \medskip
  \fi}
\newcommand{\rogleart@abstracts}{%
  \ifrogleart@english\rogleart@mainabstract\rogleart@otherabstract
  \else\rogleart@otherabstract\rogleart@mainabstract\fi}
% Rule that closes the front matter, only when there is something above it.
\newcommand{\rogleart@frontrule}{%
  \ifx\rogleart@abstracttext\@empty\ifx\rogleart@translatedabstract\@empty\else
    \vspace{2mm}\rogleart@grayrule\vspace{2mm}\fi\else\vspace{2mm}\rogleart@grayrule\vspace{2mm}\fi}
% Work type, teaching block and transfer data: the lines that open the metadata.
\newcommand{\rogleart@metalines}{%
  \ifx\rogleart@worktype\@empty\else{\bfseries\rogleart@worktype}\par\fi
  \rogleart@courseinfo
  \ifx\rogleart@reportnumber\@empty\else\rogleart@reportname\ \rogleart@reportnumber\par\fi
  \ifx\rogleart@recipient\@empty\else\rogleart@recipientname: \rogleart@recipient\par\fi
  \ifx\rogleart@project\@empty\else\rogleart@projectname: \rogleart@project\par\fi}
\newcommand{\rogleart@infoblock}{{\rogleart@metafont\raggedleft
  \rogleart@metalines
  \ifx\rogleart@series\@empty\else\rogleart@series\par\fi
  \ifx\rogleart@version\@empty
    \ifx\rogleart@pubdate\@empty\else\rogleart@pubdate\par\fi
  \else
    \rogleart@versionname\ \rogleart@version\ifx\rogleart@pubdate\@empty\else, \rogleart@pubdate\fi\par
  \fi
  \ifx\rogleart@lastupdated\@empty\else\rogleart@updatedname: \rogleart@lastupdated\par\fi
  \ifx\rogleart@status\@empty\else\rogleart@status\par\fi
  \ifx\rogleart@isbn\@empty\else ISBN \rogleart@isbn\par\fi
  \ifx\rogleart@issn\@empty\else ISSN \rogleart@issn\par\fi
  \ifx\rogleart@identifier\@empty\else\url{\rogleart@identifier}\par\fi}}
% Licence: two lines on the left, as in the CITYM papers. The adaptation sentence of a derived
% work replaces the licence sentence.
\newcommand{\rogleart@licenseline}{\parbox[t]{\textwidth}{\rogleart@notefont
  \color{rogleGrisUPV431}\raggedright
  \ifx\rogleart@licenseicon\@empty\else\rogleart@licenseicon\ \fi
  \textcopyright\ \rogleart@year\ \rogleart@copyrightholder.\par
  \ifx\rogleart@adaptation\@empty
    \ifx\rogleart@licenseurl\@empty\rogleart@licensename.
    \else\rogleart@licensedname\ \href{\rogleart@licenseurl}{\rogleart@licensename}.\fi
  \else\rogleart@adaptation\fi}}

% ---------------------------------------------------------------------------
% Running heads (spec 8.7)
% ---------------------------------------------------------------------------
\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0.4pt}
\renewcommand{\headrule}{{\color{rogleSeparador}\hrule height\headrulewidth width\headwidth}}
\fancypagestyle{roglefirst}{\fancyhf{}\renewcommand{\headrulewidth}{0pt}%
  \fancyfoot[L]{\rogleart@licenseline}}
\rogleart@ifmode{widemargin}{%
  \fancyhfoffset[R]{\dimexpr\marginparsep+\marginparwidth}%
  \fancyhead[L]{\rogleart@headfont\rogleart@shorttitle}%
  \fancyhead[R]{\rogleart@metafont\thepage}%
}{%
  \fancyhead[CE]{\rogleart@headfont\rogleart@shorttitle}%
  \fancyhead[CO]{\rogleart@headfont\rogleart@runningauthors}%
  \rogleart@ifmode{preprint}
    {\fancyfoot[C]{\rogleart@metafont\thepage}}
    {\fancyfoot[C]{\rogleart@metafont\thepage\ / \pageref*{LastPage}}}%
}

% ---------------------------------------------------------------------------
% \maketitle per mode
% ---------------------------------------------------------------------------
\newcommand{\rogleart@maketitle@preprint}{%
  \noindent\begin{minipage}[c]{60mm}\rogleart@widelogo{60mm}{rogle-logo-color}\end{minipage}%
  \hfill\ifx\rogleart@identifier\@empty
    \begin{minipage}[c]{\dimexpr\linewidth-66mm}\rogleart@infoblock\end{minipage}%
  \else
    \begin{minipage}[c]{\dimexpr\linewidth-85mm}\rogleart@infoblock\end{minipage}%
    \hspace{4mm}\begin{minipage}[c]{15mm}\rogleart@qr{15mm}\end{minipage}%
  \fi
  \par\vspace{3mm}\rogleart@grayrule\vspace{10mm}
  \rogleart@titles\vspace{6mm}
  \rogleart@authorsblock\vspace{4mm}
  \rogleart@dateline\vspace{3mm}
  \rogleart@citebox\vspace{5mm}
  \rogleart@highlightsbox
  \rogleart@abstracts\rogleart@frontrule}

\newcommand{\rogleart@maketitle@workingpaper}{%
  \noindent\rogleart@logo{9mm}{upv-rogle-positivo}\par\vspace{22mm}
  \ifx\rogleart@series\@empty\else
    \noindent{\rogleart@metafont\MakeUppercase{\rogleart@series}}\par\vspace{2mm}\fi
  {\rogleart@metafont\raggedright\rogleart@metalines}\vspace{2mm}
  {\color{rogleAmbar}\rule{30mm}{1.2mm}}\par\vspace{6mm}
  \rogleart@titles\vspace{8mm}
  \rogleart@authorsblock\vspace{6mm}
  \rogleart@dateline
  \vfill
  \noindent\begin{minipage}[b]{\dimexpr\linewidth-22mm}\rogleart@citebox\end{minipage}\hfill
  \begin{minipage}[b]{18mm}\rogleart@qr{18mm}\end{minipage}\par\vspace{2mm}
  \newpage
  \rogleart@highlightsbox
  \rogleart@abstracts\rogleart@frontrule}

% Cover page of the former rogle-notes: logo with descriptor, rule, title and authors on the
% left, the metadata and the group line at the foot. The front matter starts on the next page.
\newcommand{\rogleart@maketitle@cover}{%
  \noindent\rogleart@widelogo{0.62\textwidth}{rogle-logo-color}\par\vfill
  \noindent{\color{rogleIndigo}\rule{32mm}{2.5pt}}\par\vspace{10mm}
  {\raggedright\hyphenpenalty=10000\rmfamily\bfseries\fontsize{30}{36}\selectfont
   \color{rogleOxfordBlue}\@title\par}%
  \ifx\rogleart@subtitle\@empty\else\vspace{4mm}
    {\raggedright\rmfamily\fontsize{15}{20}\selectfont\color{rogleIndigo}\rogleart@subtitle\par}\fi
  \ifx\rogleart@translatedtitle\@empty\else\vspace{3mm}
    {\rogleart@translatedtitlefont\rogleart@translatedtitle\par}\fi
  \vspace{12mm}\rogleart@authorsblock\vspace{8mm}
  {\rogleart@metafont\raggedright\rogleart@metalines
   \ifx\rogleart@series\@empty\else\rogleart@series\par\fi}%
  \rogleart@dateline
  \vfill\rogleart@grayrule\vspace{2mm}
  {\rogleart@metafont\raggedright ROGLE: Reengineering Operations GroupWork Logistics Excellence.
   Universitat Polit\`ecnica de Val\`encia.\par}
  \newpage
  \rogleart@citebox\vspace{5mm}
  \rogleart@highlightsbox
  \rogleart@abstracts\rogleart@frontrule}

\newcommand{\rogleart@maketitle@widemargin}{%
  \marginpar{\raggedright\rogleart@logo{12mm}{rogle-symbol-color}\par\vspace{6mm}
    {\rogleart@metafont
     \rogleart@metalines\medskip
     \ifx\rogleart@series\@empty\else\rogleart@series\par\medskip\fi
     \ifx\rogleart@version\@empty\else\rogleart@versionname\ \rogleart@version\par\fi
     \ifx\rogleart@pubdate\@empty\else\rogleart@publishedname: \rogleart@pubdate\par\fi
     \ifx\rogleart@lastupdated\@empty\else\rogleart@updatedname: \rogleart@lastupdated\par\fi
     \ifx\rogleart@received\@empty\else\rogleart@receivedname: \rogleart@received\par\fi
     \ifx\rogleart@accepted\@empty\else\rogleart@acceptedname: \rogleart@accepted\par\fi
     \ifx\rogleart@status\@empty\else\rogleart@status\par\fi
     \ifx\rogleart@isbn\@empty\else ISBN \rogleart@isbn\par\fi
     \ifx\rogleart@issn\@empty\else ISSN \rogleart@issn\par\fi\medskip}
    \ifx\rogleart@identifier\@empty\else
      \rogleart@qr{20mm}\par\smallskip{\rogleart@notefont\url{\rogleart@identifier}}\par\vspace{6mm}\fi
    \ifx\rogleart@howtocite\@empty\else
      {\rogleart@notefont\raggedright{\rogleart@labelfont\rogleart@howtocitename:} \rogleart@howtocite\par}\fi}%
  \rogleart@titles\vspace{6mm}
  \rogleart@authorsblock\vspace{6mm}
  \rogleart@highlightsbox
  \noindent{\color{rogleOxfordBlue}\rule{\linewidth}{0.8pt}}\par\vspace{2mm}
  \rogleart@abstracts\vspace{2mm}
  \noindent{\color{rogleOxfordBlue}\rule{\linewidth}{0.8pt}}\par\vspace{4mm}}

\renewcommand{\maketitle}{%
  \thispagestyle{roglefirst}%
  \csname rogleart@maketitle@\rogleart@mode\endcsname}

% ---------------------------------------------------------------------------
% End matter (spec 8.7)
% ---------------------------------------------------------------------------
\newcommand{\rogleart@runin}[2]{\ifx#2\@empty\else
  \noindent{\rogleart@labelfont #1.}\ #2\par\smallskip\fi}
\newcommand{\makebackmatter}{%
  \section*{\rogleart@backmattername}
  {\rogleart@notefont
   \rogleart@runin{\rogleart@fundingname}{\rogleart@funding}%
   \rogleart@runin{\rogleart@creditname}{\rogleart@credit}%
   \rogleart@runin{\rogleart@conflictsname}{\rogleart@conflicts}%
   \rogleart@runin{\rogleart@dataname}{\rogleart@dataavailability}%
   \rogleart@runin{\rogleart@codename}{\rogleart@codeavailability}%
   \rogleart@runin{\rogleart@ainame}{\rogleart@aiuse}}}

\endinput
