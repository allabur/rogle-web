-- ROGLE notes and reports (format rogle-notes-pdf).
--
-- Reads header.tex into the preamble and replaces {{ROGLE}} with the absolute path of this
-- extension's resources/ folder (logo and colours). So the header works wherever Quarto installed
-- the extension (_extensions/rogle-notes/ here, _extensions/allabur/rogle-notes/ after `quarto add`)
-- and whatever folder the document is in. quarto.utils.resolve_path resolves relative to this file.
--
-- The path goes out as raw LaTeX inside \detokenize, as in rogle-lab.lua: Pandoc would escape a
-- plain string (`_` -> `\_`, `~` -> `\textasciitilde{}`). TeX reads `#`, `%` and braces before
-- \detokenize sees them, so those go out as the expl3 string constants.
local STR_CONSTANTS = {
  ["#"] = "c_hash_str",
  ["%"] = "c_percent_str",
  ["{"] = "c_left_brace_str",
  ["}"] = "c_right_brace_str",
}

local function latex_path(path)
  local body = path:gsub("[#%%{}]", function(char)
    return "}\\csname " .. STR_CONSTANTS[char] .. "\\endcsname\\detokenize{"
  end)
  return "\\detokenize{" .. body .. "}"
end

function Meta(meta)
  if not quarto.doc.is_format("latex") then return nil end
  local file = assert(io.open(quarto.utils.resolve_path("header.tex"), "r"))
  local header = file:read("a")
  file:close()
  local dir = latex_path(quarto.utils.resolve_path("resources") .. "/")
  header = header:gsub("{{ROGLE}}", function() return dir end)
  quarto.doc.include_text("in-header", header)
  return meta
end
