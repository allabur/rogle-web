# Carta con membrete

Carta A4 de una página con la propuesta de marca 20 aniversario (alternativa A). Issue [#30](https://github.com/allabur/rogle/issues/30), parte del epic [#26](https://github.com/allabur/rogle/issues/26).

![Carta de muestra](muestra/carta.png)

## Compilar

```bash
export PATH="/Library/TeX/texbin:$PATH"
cd plantillas/carta
SOURCE_DATE_EPOCH=0 lualatex -interaction=nonstopmode -halt-on-error carta.tex
```

Resultado: `carta.pdf`. Se usa LaTeX directo con LuaLaTeX, sin Quarto: una carta no necesita más. Hace falta Palatino y Gill Sans en el sistema. Sin ellas, `rogle20-fonts.sty` usa las fuentes libres de respaldo.

## Cómo se usa

Edite el bloque «DATOS DE LA CARTA» de `carta.tex`: lugar, fecha, asunto, saludo, firmante, cargo, contacto y destinatario. Escriba el cuerpo bajo `% ---- Cuerpo`. El texto de ejemplo es ficticio.

## Decisiones

- **Membrete: firma institucional UPV.** La carta es un documento oficial del grupo. `BRAND_SPEC.md` pide la firma institucional (`comunes/upv-rogle-firma-institucional`, marca UPV en negro) para documentos oficiales. El logotipo horizontal de A queda para piezas propias. Además, la firma no depende de la aprobación pendiente de A por la UPV.
- **Posición:** arriba a la izquierda, recortada a su tinta, 72 mm de ancho y 11,5 mm de alto. Empieza a 14 mm del borde. El aire libre a su alrededor supera 0,25 veces la altura de la marca, como exige `BRAND_SPEC.md`.
- **Tipografía:** cuerpo en Palatino 11 pt, color `oxford-blue`. Remitente y pie en Gill Sans. El asunto va en Palatino negrita, en `indigo` (7,62:1 sobre blanco). Remitente y pie van en `gris-upv-431` (5,80:1).
- **Márgenes:** 25 mm a los lados y 32 mm abajo, para el pie de tres líneas.
- **Pie:** dirección del grupo y enlace a `https://rogle.webs.upv.es/` en `indigo`. Se repite en todas las páginas.

## Capacidad

La muestra tiene unas 260 palabras de cuerpo. Una página completa admite unas 330 palabras de cuerpo (comprobado). Con 350 pasa a dos páginas: acorte el cuerpo o acepte la segunda. Si la carta pasa de una página, el texto sigue con un encabezado corto («ROGLE · asunto», «Página 2»). El pie no cambia.

## Archivos

- `carta.tex`: fuente de ejemplo.
- `carta.pdf`: PDF de muestra.
- `muestra/carta.png`: vista previa.
