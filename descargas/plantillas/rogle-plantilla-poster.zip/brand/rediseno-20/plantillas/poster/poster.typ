// Plantilla de póster de congreso A0 vertical con la marca ROGLE (alternativa A).
// Compilar desde esta carpeta:
//   typst compile --root ../.. --font-path ../../../fonts poster.typ poster.pdf
// La raíz (--root) es brand/rediseno-20, de donde salen los logotipos.

#let oxford = rgb("#002147")
#let indigo = rgb("#3F4AA8")
#let indigo-claro = rgb("#A9B0E0")
#let indigo-palido = rgb("#EEF0FA")
#let ambar = rgb("#F5B000")
#let gris = rgb("#5B6770")
#let separador = rgb("#CFCFCF")

// Titles in bold Palatino; Gill Sans only for secondary text (authors and affiliations).
#let etiquetas = ("Gill Sans", "Gillius ADF")
#let texto = ("Palatino", "TeX Gyre Pagella")

#set page(width: 841mm, height: 1189mm, margin: (x: 30mm, top: 0mm, bottom: 0mm))
#set text(font: texto, size: 40pt, fill: oxford, lang: "es")
#set text(hyphenate: false)
#set par(justify: false, leading: 0.8em, spacing: 1.1em)

// Bloque de contenido con título de sección.
#let bloque(titulo, cuerpo) = block(width: 100%, breakable: true)[
  #block(sticky: true, below: 0.7em)[
    #text(font: texto, weight: "bold", size: 64pt, fill: indigo, titulo)
    #v(-0.45em)
    #line(length: 100%, stroke: 3pt + indigo-claro)
  ]
  #cuerpo
  #v(1.2em)
]

#show figure.caption: set text(size: 36pt, fill: gris)
#show figure: set block(above: 1.2em, below: 1.2em)

// Figura de ejemplo dibujada con primitivas: sustituir por una imagen propia.
#let grafico-ejemplo = {
  let datos = (("Base", 42), ("Método A", 61), ("Método B", 78), ("ROGLE", 93))
  box(width: 100%, inset: 20pt, stroke: 2pt + separador, radius: 6pt)[
    #grid(
      columns: (70mm, 1fr),
      column-gutter: 14pt,
      row-gutter: 22pt,
      ..datos.map(d => (
        align(right + horizon, text(size: 36pt, d.at(0))),
        rect(
          width: d.at(1) * 1%,
          height: 56pt,
          inset: (right: 10pt),
          fill: if d.at(0) == "ROGLE" { indigo } else { indigo-claro },
          align(right + horizon, text(size: 34pt, weight: "bold", fill: if d.at(0) == "ROGLE" { white } else { oxford }, [#d.at(1) %])),
        ),
      )).flatten(),
    )
  ]
}

// Marcador de posición para una imagen real.
#let marcador(alto, etiqueta) = rect(
  width: 100%,
  height: alto,
  fill: indigo-palido,
  stroke: 2pt + indigo-claro,
  align(center + horizon, text(size: 34pt, fill: indigo, etiqueta)),
)

// ---------------------------------------------------------------- Cabecera
#move(dx: -30mm)[
#block(width: 841mm, height: 300mm, fill: oxford, inset: (x: 30mm, y: 0mm), breakable: false)[
  #align(horizon)[#grid(
    columns: (1fr, auto),
    column-gutter: 30mm,
    align: horizon,
    stack(
      spacing: 14mm,
      text(font: texto, weight: "bold", size: 100pt, fill: white)[Optimización de rutas de picking con aprendizaje por refuerzo],
      text(font: etiquetas, size: 44pt, fill: indigo-claro)[Ana Ejemplo#super[1], Luis Ficticio#super[1], Marta Muestra#super[2] · #super[1]Grupo ROGLE, Universitat Politècnica de València · #super[2]Universidad de Ejemplo],
    ),
    image("/alternativa-A/rogle-A-horizontal-negativo.svg", height: 100mm),
  )]
]
#rect(width: 841mm, height: 8mm, fill: ambar, stroke: none)
]

#v(24mm)

// ---------------------------------------------------------------- Contenido
#box(height: 640mm)[
#grid(columns: (1fr, 1fr, 1fr), column-gutter: 26mm)[
  #bloque("Introducción")[
    La preparación de pedidos concentra más de la mitad del coste operativo de un almacén.
    Este póster presenta un método que reduce la distancia recorrida por los operarios.
    El contenido es ficticio y sirve para comprobar la maqueta.

    Las rutas actuales siguen reglas fijas. No reaccionan a la congestión de pasillos ni a los cambios de stock.

    *Objetivo.* Reducir un 20 % la distancia media por pedido sin ampliar la plantilla.
  ]

  #bloque("Método")[
    Modelamos el almacén como un grafo de 1 200 nodos. Un agente aprende a ordenar las paradas de cada lote.

    + Generamos pedidos con datos sintéticos.
    + Entrenamos el agente 200 000 episodios.
    + Comparamos con dos reglas de referencia.

  ]

  ][

  #bloque("Resultados")[
    El agente reduce la distancia en todos los escenarios. La mejora crece con el tamaño del lote.

    #figure(
      grafico-ejemplo,
      caption: [Mejora de eficiencia respecto a la referencia (datos ficticios).],
      supplement: [Figura],
    )

    #figure(
      table(
        columns: (1.6fr, 1fr, 1fr),
        align: (left, right, right),
        stroke: (x: none, y: 1.5pt + separador),
        inset: 20pt,
        fill: (_, y) => if y == 0 { oxford } else if calc.odd(y) { indigo-palido } else { none },
        table.header(
          text(fill: white, weight: "bold")[Método],
          text(fill: white, weight: "bold")[Distancia (m)],
          text(fill: white, weight: "bold")[Tiempo (s)],
        ),
        [Serpentina], [412], [1,8],
        [Mayor salto], [378], [2,1],
        [Agente ROGLE], [*301*], [*0,9*],
      ),
      caption: [Distancia media por pedido y tiempo de cálculo.],
      supplement: [Tabla],
      kind: table,
    )
  ]

  ][

  #bloque("Conclusiones")[
    - La distancia media baja un 27 % frente a la mejor regla.
    - El cálculo es inmediato y cabe en un terminal de mano.
    - Falta validar con pedidos reales de dos almacenes.

    #figure(
      marcador(170mm)[Foto o figura adicional],
      caption: [Espacio libre para una imagen del caso de estudio.],
      supplement: [Figura],
    )
  ]

  #bloque("Referencias")[
    #set par(justify: false, leading: 0.6em, spacing: 0.9em)
    [1] Autor, A. (2024). _Título del artículo de ejemplo_. Revista Ficticia, 12(3), 45–67.

    [2] Otro, B. y Tercero, C. (2023). _Libro de ejemplo_. Editorial Muestra.

    [3] Grupo ROGLE (2025). _Propuesta de marca del 20 aniversario_. Universitat Politècnica de València.
  ]
]
]

// ---------------------------------------------------------------- Pie
#place(bottom + left, dx: -30mm)[
  #block(width: 841mm, height: 130mm, fill: white, inset: (x: 30mm), stroke: (top: 4mm + oxford))[
    #grid(
      columns: (auto, 1fr),
      column-gutter: 30mm,
      align: horizon + left,
      image("/comunes/upv-rogle-firma-institucional.svg", height: 70mm),
      align(right, text(size: 34pt, fill: gris)[
        #text(weight: "bold", fill: oxford)[Contacto:] ana.ejemplo\@upv.es · rogle.upv.es \
        Congreso Ficticio de Logística 2026 · Valencia
      ]),
    )
  ]
]
