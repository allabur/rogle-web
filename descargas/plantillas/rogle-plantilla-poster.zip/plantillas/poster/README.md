# Plantilla de póster A0

Póster de congreso A0 vertical (841 × 1189 mm) con la marca vigente del grupo (alternativa C, Palatino negrita). Está hecho en Typst.

## Compilar

```bash
cd plantillas/poster
typst compile --root ../.. --font-path ../../brand/fonts poster.typ poster.pdf
```

`--root` apunta a la raíz del repositorio, de donde salen los logotipos y el icono de la licencia. `--font-path` añade Pagella como respaldo de Palatino.

## Estructura

- Cabecera Oxford Blue con el título de 100 pt, los autores, las afiliaciones numeradas y el logotipo en negativo (`brand/logos/logo/rogle-logo-notagline-reverse.svg`). La franja ámbar va pegada al azul.
- Tres columnas: introducción y método, resultados (figura y tabla), conclusiones y referencias.
- Pie con la firma institucional UPV, el contacto, el congreso, la financiación y la licencia (CC BY-NC-SA 4.0 por defecto, con el icono oficial de `assets/license/`).
- Todo el texto va en Palatino, con los títulos en negrita. Texto de 40 pt, leyendas de 36 pt. Se lee a 1-2 m.

## Personalizar

Sustituye el texto ficticio de `poster.typ`. Cambia los marcadores (`marcador`) por `image("figura.png")`. El gráfico de barras es un ejemplo dibujado con Typst.

Para otra licencia, cambia `licencia`, `licencia-url` y `licencia-icono` al principio de `poster.typ`. Si el trabajo no tiene financiación, borra esa línea del pie. Separa los elementos de una línea con comas, nunca con puntos medios.

No reduzcas el logotipo por debajo de 60 mm de ancho ni pongas texto a menos de 0,25 veces la altura del isotipo.

`muestra/poster.png` es una vista reducida del PDF de muestra `poster.pdf`. Se regenera con:

```bash
pdftoppm -png -r 12 -singlefile poster.pdf muestra/poster
```
