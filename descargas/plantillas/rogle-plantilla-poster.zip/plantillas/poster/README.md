# Plantilla de póster A0

Póster de congreso A0 vertical (841 × 1189 mm) con la propuesta de marca del 20 aniversario (alternativa C). Está hecho en Typst.

## Compilar

```bash
cd plantillas/poster
typst compile --root ../.. --font-path ../../brand/fonts poster.typ poster.pdf
```

`--root` apunta a la raíz del repositorio, de donde salen los logotipos. `--font-path` añade Pagella y Gillius como respaldo de Palatino y Gill Sans.

## Estructura

- Cabecera Oxford Blue con título de 100 pt, autores y logotipo negativo de A.
- Tres columnas: introducción y método, resultados (figura y tabla), conclusiones y referencias.
- Pie con la firma institucional UPV y el contacto.
- Texto de 40 pt, leyendas de 36 pt. Se lee a 1-2 m.

## Personalizar

Sustituye el texto ficticio de `poster.typ`. Cambia los marcadores (`marcador`) por `image("figura.png")`. El gráfico de barras es un ejemplo dibujado con Typst.

`muestra/poster.png` es una vista reducida del PDF de muestra `poster.pdf`.
