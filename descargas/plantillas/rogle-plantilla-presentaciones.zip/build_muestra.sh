#!/bin/bash
# Regenera muestra/: capturas de template.qmd en Beamer y en Reveal.js.
# Uso: ./build_muestra.sh   (desde esta carpeta)
# Necesita quarto, lualatex, pdftoppm, ImageMagick (magick) y Google Chrome (capturas de Reveal.js).
set -euo pipefail
cd "$(dirname "$0")"
chrome="${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"; rm -f muestra-*.pdf muestra-*.html muestra-*.tex muestra-*.qmd' EXIT

# Variante de investigación: una copia de template.qmd con la portada y el cierre de un congreso.
# Las opciones de la cabecera del documento ganan a -M, así que se cambian en la copia.
sed -e 's/^portada: docencia/portada: investigacion/' \
  -e 's/^subtitle: .*/subtitle: "Planificación de rutas con ventanas horarias"/' \
  -e 's/^  etiqueta: .*/  etiqueta: "XX Congreso de Ingeniería de Organización, València, 8-10 de julio de 2026"/' \
  -e 's/^  logos: .*/  logos: [gva, ue]\
  financiacion: "Contrato predoctoral CIACIF\/0000\/000 financiado por la Generalitat Valenciana y cofinanciado por la Unión Europea (Fondo Social Europeo Plus, FSE+)."/' \
  -e 's/\[Diapositivas\]\. Dirección de Operaciones (33804), Máster Universitario en Ingeniería Industrial (2241), Universitat Politècnica de València\./[Presentación en congreso]. XX Congreso de Ingeniería de Organización, València./' \
  template.qmd > muestra-investigacion.qmd

# render <formato> <nombre> <documento> [opciones de quarto]
# Beamer deja $tmp/beamer-<nombre>.pdf. Reveal.js deja muestra-<nombre>.html, que se captura después.
render() {
  local format=$1 name=$2 source=$3
  shift 3
  if [ "$format" = beamer ]; then
    quarto render "$source" --to rogle-slides-beamer -o "muestra-$name.pdf" "$@" >/dev/null 2>&1
    mv "muestra-$name.pdf" "$tmp/beamer-$name.pdf"
  else
    quarto render "$source" --to rogle-slides-revealjs -o "muestra-$name.html" "$@" >/dev/null 2>&1
  fi
}

# page <formato> <nombre> <página> <salida.png>: una diapositiva a PNG de 1280 x 720 px.
# Beamer sale del PDF. Reveal.js se captura en Chrome por el identificador de la diapositiva:
# imprimir ?print-pdf sin interfaz falla por rachas.
page() {
  local format=$1 name=$2 number=$3 out=$4
  if [ "$format" = beamer ]; then
    pdftoppm -r 96 -png -f "$number" -l "$number" -singlefile "$tmp/beamer-$name.pdf" "${out%.png}"
  else
    local id
    id=$(grep -o '<section id="[^"]*"[^>]*class="[^"]*\(slide\|quarto-title-block\)' "muestra-$name.html" |
      sed -n "${number}p" | sed -E 's/<section id="([^"]*)".*/\1/')
    "$chrome" --headless=new --disable-gpu --hide-scrollbars --window-size=1280,720 \
      --virtual-time-budget=10000 --screenshot="$out" "file://$PWD/muestra-$name.html#/$id" >/dev/null 2>&1
  fi
}

mkdir -p muestra
for format in beamer reveal; do
  rm -f muestra/"$format"-*.png
  render "$format" base template.qmd
  for tracker in superior inferior pasos; do render "$format" "$tracker" template.qmd -M "tracker:$tracker"; done
  render "$format" investigacion muestra-investigacion.qmd
  page "$format" base 1 "muestra/$format-01-portada.png"
  page "$format" base 2 "muestra/$format-02-indice.png"
  page "$format" base 3 "muestra/$format-03-resumen-lateral.png"
  page "$format" base 5 "muestra/$format-04-separador.png"
  page "$format" superior 4 "muestra/$format-05-tracker-superior.png"
  page "$format" inferior 4 "muestra/$format-06-tracker-inferior.png"
  page "$format" pasos 4 "muestra/$format-07-tracker-pasos.png"
  page "$format" base 10 "muestra/$format-08-tabla.png"
  page "$format" base 13 "muestra/$format-09-cierre.png"
  page "$format" investigacion 1 "muestra/$format-10-portada-investigacion.png"
  page "$format" investigacion 13 "muestra/$format-11-cierre-investigacion.png"
  for number in 1 2 3 4 5 6 7 8 9 10 11 12 13; do
    page "$format" base "$number" "$tmp/$format-c-$(printf '%02d' "$number").png"
  done
  magick montage "$tmp/$format"-c-*.png -tile 4x -resize 480x -geometry +8+8 -background '#F4F4FA' \
    "muestra/$format-contactos.png"
done
echo "Muestra regenerada en muestra/"
