# Plantilla de presentaciones (estilo consultora)

Plantilla Quarto de diapositivas con la marca vigente de ROGLE. Un solo `template.qmd` se compila a Reveal.js (HTML) y a Beamer (PDF) con el mismo aspecto. Es el mismo diseño que la plantilla de PowerPoint de `brand/office/`. Issue [#27](https://github.com/allabur/rogle/issues/27).

El diseño es el de una presentación de consultoría estratégica. Fondo blanco, un título de acción de una frase, un menú de seguimiento de las secciones, una barra con el mensaje clave, una línea de fuente y un pie con el número. La portada, la contraportada y los separadores de sección van sobre Oxford Blue.

## Cómo se renderiza

Desde esta carpeta:

```bash
quarto render template.qmd --to revealjs
quarto render template.qmd --to beamer
```

Sin `--to` se renderizan los dos. Reveal.js escribe `template.html`, un único archivo con estilos, imágenes y fuentes dentro. Beamer escribe `template.pdf` con LuaLaTeX.

Para probar otra opción sin tocar el archivo:

```bash
quarto render template.qmd --to revealjs -M tracker:superior -M portada:negativa
quarto render template.qmd --to beamer -M tracker:pasos
```

**Beamer necesita LuaLaTeX.** Con pdfLaTeX no se pueden usar Palatino ni Gill Sans del sistema, y Pandoc carga `unicode-math` solo con LuaLaTeX y XeLaTeX. El motor está fijado en el YAML (`pdf-engine: lualatex`). No se admite pdfLaTeX.

## Ver y exportar Reveal.js

Abre `template.html` con doble clic en un navegador. Funciona sin servidor. También sirve `quarto preview template.qmd` o `python3 -m http.server 8000` y abrir `http://localhost:8000/template.html`.

Para el PDF, abre `template.html?print-pdf` en Chrome, imprime, elige «Guardar como PDF», márgenes «Ninguno» y activa «Gráficos de fondo». El menú, el pie y los números salen bien porque el script los escribe dentro de cada diapositiva. El PDF tiene una página por diapositiva.

Cómo se arregló la vista previa sin estilos: el HTML antiguo enlazaba hojas de estilo y logotipos con rutas relativas. Dentro de un proyecto Quarto, las rutas relativas de HTML escrito a mano se convierten en rutas absolutas del sitio (`/brand/...`), y los visores que muestran el HTML como una instantánea no resuelven ninguna ruta. Además, el motor de marca de Quarto escribía mal la ruta de las fuentes libres, que nunca se cargaban. Ahora `embed-resources: true` deja todo dentro del HTML y `brand: false` desactiva el motor de marca para esta plantilla.

Dos límites que quedan, porque vienen de Reveal.js:

- Un visor que incrusta el HTML como `srcdoc` o `data:` no ejecuta Reveal.js: sus rutas de historial no funcionan y la pantalla queda en blanco. Abre el archivo en el navegador.
- Las fórmulas cargan MathJax 4 y la fuente `mathjax-pagella` desde jsDelivr. Sin red se ven las fórmulas sin tipografía de marca. El resto no necesita red.

## Opciones del YAML

| Opción | Valores | Por defecto | Qué hace |
|---|---|---|---|
| `tracker` | `lateral`, `superior`, `inferior`, `pasos`, `ninguno` | `lateral` | Menú de seguimiento de las secciones |
| `portada` | `positiva`, `negativa` | `positiva` | Diseño de la portada y la contraportada |
| `borrador` | texto corto | vacío | Etiqueta pequeña a la izquierda del número de página, por ejemplo «Datos ilustrativos» |

## Estructura de una presentación

```markdown
## Título de acción de una frase       <- diapositiva

# Sección                              <- sección: separador oscuro + entrada en el menú
# Sección {.sin-separador}             <- sección sin separador (cuenta en el menú)

## {.contraportada}                    <- contraportada
```

La portada sale de `title`, `subtitle`, `author` y `date`. El título de la diapositiva es el título de acción: una frase con la conclusión, de dos líneas como máximo.

Dentro de cada diapositiva se usan estos bloques:

| Bloque | Resultado |
|---|---|
| `::: {.mensaje}` | Barra de mensaje clave, en negrita |
| `::: {.fuente}` | Línea «Fuente: …» en Gill Sans pequeña |
| `::: {.etiqueta}` | Etiqueta pequeña sobre el título («Resumen ejecutivo») |
| `::: {.agenda}` | Lista de las secciones, con la actual resaltada |
| `::: {.bloques}` con tres `::: {.bloque}` | Resumen ejecutivo: tres bloques numerados |
| `::: {.comparacion}` con tres `::: {.opcion}` | Comparación en tres columnas |
| `::: {.cierre}` con `.pasos` y `.decision` | Próximos pasos y decisión que se pide |
| `::: {.formula}` | Fórmula sobre fondo suave con barra índigo |
| `:::: {.columns}` | Dos columnas (sintaxis de Quarto) |
| `: Pie de tabla {.total}` | Tabla con la última fila en negrita |
| `::: {.gracias}` y `::: {.contacto}` | Textos de la contraportada |

Los títulos de nivel 3 (`###`) dentro de `.bloque`, `.opcion` y `.decision` son los encabezados de cada columna.

`template.qmd` es un ejemplo de 13 diapositivas con el mismo hilo que la muestra de PowerPoint (`brand/office/muestra/`): la reorganización de rutas de reparto. Muestra portada, agenda, resumen ejecutivo, contenido, texto y figura, fórmula, código, tabla, comparación, cierre y contraportada, con dos separadores. Los datos son ficticios.

## El menú de seguimiento (tracker)

Se calcula solo a partir de los `# Sección`. No hay que escribir nada a mano. La sección actual va en índigo y las demás en gris. Nunca va en ámbar sobre blanco.

| Valor | Aspecto |
|---|---|
| `lateral` | Panel a la izquierda, con una barra índigo en la sección actual |
| `superior` | Tira arriba a la derecha, con subrayado índigo bajo la sección actual |
| `inferior` | Tira a todo el ancho sobre el pie, con una barra índigo sobre la sección actual |
| `pasos` | Chevrones numerados arriba («1 Contexto › 2 Análisis › …»), el actual relleno de índigo |
| `ninguno` | Solo el título y el pie |

**Cambiarlo en una diapositiva.** Pon `data-tracker` en su título:

```markdown
## Una diapositiva sin menú {data-tracker="ninguno"}
## Otra con tira superior {data-tracker="superior"}
```

En Reveal.js funciona con cualquier valor. En Beamer también, pero el sangrado del contenido solo se ajusta bien con valores que dejan el contenido en el mismo borde que el menú del documento. Si el documento usa `lateral` y una diapositiva usa otro valor (o al revés), los párrafos y las listas se desplazan, pero las columnas y las tablas no. Evita mezclar `lateral` con los demás en Beamer.

**Cómo funciona.** En Reveal.js, `rogle20-reveal.html` lee los `# Sección` (el filtro Lua los lista en una variable) y, al cargar, escribe el menú, el pie y el número dentro de cada diapositiva. Por eso funciona igual en `?print-pdf`. En Beamer, el filtro Lua escribe en el título de cada diapositiva su menú y su sección, y en el preámbulo la lista de secciones. `rogle20-beamer.tex` dibuja el menú con TikZ en la plantilla de fondo. No usa archivos `.aux`: una pasada basta.

## Portada y contraportada

`portada: positiva` es el diseño principal. Un campo Oxford Blue ocupa cuatro quintos de la diapositiva, un filete ámbar marca el corte y una franja blanca lleva los logotipos de la UPV y de ROGLE en positivo, a la misma altura. La contraportada repite el campo con el logotipo de ROGLE en negativo, «Gracias» y los datos de contacto, y, en la franja, los logotipos de la UPV y de ROGLE en positivo, como en la plantilla de PowerPoint.

`portada: negativa` es la alternativa. Todo es Oxford Blue y los logotipos van en blanco, con el filete ámbar encima.

Los logotipos de ROGLE salen de `brand/logos/`, que sigue la alternativa vigente (`brand/marca-activa.txt`). Las marcas de la UPV junto a ROGLE salen de `logos/`, que genera `build_logos.py` a partir de `rogle-<X>-upv-convivencia.svg`:

```bash
python3 build_logos.py
```

Vuelve a ejecutarlo después de `brand/adoptar.sh`. Las versiones en positivo son el logotipo de convivencia recortado, sin cambios. **Las versiones en negativo son provisionales**: se obtienen recoloreando el positivo, hasta que el Área de Comunicación de la UPV entregue el negativo oficial (issue [#22](https://github.com/allabur/rogle/issues/22)). El ámbar solo se usa sobre Oxford Blue.

## Tipografía

Es la regla de las presentaciones. Los títulos van en **Palatino negrita**: portada, contraportada, títulos de acción y separadores. El cuerpo va en **Palatino**. **Gill Sans** solo aparece en lo secundario: menú, etiquetas, línea de fuente, pie, número de página, cabeceras de tabla y leyendas.

| Elemento | Tamaño |
|---|---|
| Título de portada | 40 pt |
| Separador de sección | 36 pt |
| Título de acción | 26 pt |
| Cuerpo y viñetas | 16 a 18 pt |
| Menú de seguimiento | 12 pt |
| Línea de fuente | 10 pt |
| Pie y número | 10 a 12 pt |

Reveal.js usa Palatino y Gill Sans del sistema, con TeX Gyre Pagella y Gillius ADF (de `brand/fonts/`) como respaldo, incrustadas en el HTML. Beamer carga las mismas del sistema con fontspec y, si faltan, los archivos de `brand/fonts/`. Las fórmulas van en Pagella: MathJax 4 con `mathjax-pagella` en Reveal.js y TeX Gyre Pagella Math en Beamer.

## Archivos

| Archivo | Función |
|---|---|
| `template.qmd` | Ejemplo de 13 diapositivas. Opciones en el YAML |
| `rogle-presentacion.lua` | Filtro de Pandoc: lee `tracker`, `portada` y `borrador` y prepara las diapositivas en los dos formatos |
| `rogle20-reveal.scss` | Tema Reveal.js: colores, tipografía, menús, bloques y portadas |
| `rogle20-reveal.html` | Logotipos (en un bloque oculto que Pandoc incrusta) y script que escribe el menú, el pie y los números |
| `rogle20-beamer.tex` | Estilos Beamer: menú, pie, bloques y portadas, con coordenadas en px como en Reveal.js |
| `rogle20.theme` | Colores del código resaltado, para los dos formatos |
| `build_logos.py` | Genera las marcas de la UPV en positivo y negativo (`logos/`) |
| `build_figura.py` | Dibuja la figura de ejemplo (`figura-rutas.svg` y `.pdf`) |
| `muestra/` | Capturas: hoja de contactos y diapositivas sueltas de cada formato |

Si copias la plantilla a otra carpeta, ajusta las rutas relativas a `../../../logos/`, `../../../fonts/` y `../../../latex/` en `rogle20-reveal.html` y `rogle20-beamer.tex`.

## Límites conocidos

- Beamer va solo con LuaLaTeX (ver arriba).
- Los trackers `pasos` y `superior` suponen hasta unas seis secciones con nombres de menos de 16 caracteres. Con más, el menú no cabe en una línea.
- Reveal.js: el HTML pesa unos 5 MB porque lleva dentro las fuentes de respaldo y los logotipos.
- La figura de ejemplo lleva texto en Gill Sans. `build_figura.py` la dibuja con las fuentes de este equipo. Otro equipo puede dibujarla con otra fuente.
- El ámbar solo va sobre Oxford Blue. No lo uses sobre blanco.

## Pregunta abierta

Esta regla (títulos en Palatino negrita, Gill Sans solo para lo secundario) vale para las presentaciones. La regla general de la marca sigue siendo Gill Sans en los títulos de sección de los documentos (`brand/rediseno-20/BRAND_SPEC.md`, sección «Tipografía»). Si el grupo quiere una sola regla para todo, hay que decidirlo y cambiar el informe, la carta y las plantillas de Word.
