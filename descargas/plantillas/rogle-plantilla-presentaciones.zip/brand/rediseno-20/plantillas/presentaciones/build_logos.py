"""Build the UPV marks that the cover and the back cover need.

Both covers have two designs. The main one (``portada: positiva``) is an Oxford Blue
field with a white band below it; the band shows the UPV mark and the ROGLE logo in
their positive colours, side by side at the same height. The alternative
(``portada: negativa``) is all Oxford Blue with the marks in white.

Both come from ``rogle-<X>-upv-convivencia.svg`` of the active alternative
(``brand/marca-activa.txt``). The positive files are that lockup cropped to its ink,
without any change of colour. The negative files recolour it: black and Oxford Blue
become white, the indigo arms and the divider become ``indigo-claro``. The negative is
provisional until the UPV Communication Area supplies the official one (issue #22).
Run this script again after ``brand/adoptar.sh`` switches the alternative.

Output, in ``logos/`` next to this file (SVG and PDF):

- ``upv-rogle-positivo`` and ``upv-rogle-negativo``: UPV mark, divider and ROGLE logo.
- ``upv-positivo`` and ``upv-negativo``: UPV mark alone.

Run with ``python3 build_logos.py``. Needs ``rsvg-convert`` and Pillow.
"""

from __future__ import annotations

import io
import re
import subprocess
from pathlib import Path

from PIL import Image

__all__ = ["main"]

HERE = Path(__file__).resolve().parent
BRAND = HERE.parents[2]
OUT = HERE / "logos"

# Source colours -> negative colours.
RECOLOR = {
    "#000000": "#FFFFFF",
    "#002147": "#FFFFFF",
    "#5B67C7": "#A9B0E0",
    "#CFCFCF": "#A9B0E0",
}
PROBE_WIDTH = 4000


def _active() -> str:
    """Return the letter of the active logo alternative."""
    return (BRAND / "marca-activa.txt").read_text(encoding="utf-8").strip()


def _recolor(svg: str) -> str:
    """Swap the positive colours for their negative counterparts."""
    for old, new in RECOLOR.items():
        svg = re.sub(old, new, svg, flags=re.IGNORECASE)
    return svg


def _viewbox(svg: str) -> tuple[float, float, float, float]:
    """Return the root ``viewBox`` as (x, y, w, h)."""
    match = re.search(r'<svg[^>]*viewBox="([^"]+)"', svg)
    if match is None:
        message = "The SVG has no viewBox"
        raise ValueError(message)
    x, y, w, h = (float(v) for v in match.group(1).split())
    return x, y, w, h


def _ink_box(svg: str) -> tuple[float, float, float, float]:
    """Measure the ink of an SVG in its own units, as (x, y, w, h).

    The SVG is drawn on transparent, so the alpha channel is the ink, whatever the colour.
    """
    x0, y0, w, _ = _viewbox(svg)
    png = subprocess.run(  # noqa: S603
        ["rsvg-convert", "-w", str(PROBE_WIDTH), "-f", "png"],  # noqa: S607
        input=svg.encode(),
        capture_output=True,
        check=True,
    ).stdout
    alpha = Image.open(io.BytesIO(png)).convert("RGBA").getchannel("A")
    left, top, right, bottom = alpha.point(lambda a: 255 if a > 8 else 0).getbbox()
    scale = w / alpha.width
    return x0 + left * scale, y0 + top * scale, (right - left) * scale, (bottom - top) * scale


def _crop(svg: str) -> str:
    """Set the ``viewBox`` and size of the SVG to its ink, plus 1 unit of air."""
    x, y, w, h = _ink_box(svg)
    x, y, w, h = x - 1, y - 1, w + 2, h + 2
    svg = re.sub(r'(<svg[^>]*?)\sviewBox="[^"]+"', rf'\1 viewBox="{x:.2f} {y:.2f} {w:.2f} {h:.2f}"', svg, count=1)
    svg = re.sub(r'(<svg[^>]*?)\swidth="[^"]+"', rf'\1 width="{w:.2f}"', svg, count=1)
    return re.sub(r'(<svg[^>]*?)\sheight="[^"]+"', rf'\1 height="{h:.2f}"', svg, count=1)


def _remove_groups(svg: str, ids: tuple[str, ...]) -> str:
    """Delete top-level ``<g id=...>`` groups (the logo groups do not nest)."""
    for group in ids:
        svg = re.sub(rf'<g id="{group}".*?</g>', "", svg, flags=re.DOTALL)
    return svg


def _write(name: str, svg: str) -> None:
    """Write ``name.svg`` and ``name.pdf`` in ``logos/``."""
    OUT.mkdir(exist_ok=True)
    (OUT / f"{name}.svg").write_text(svg, encoding="utf-8")
    subprocess.run(  # noqa: S603
        ["rsvg-convert", "-f", "pdf", "-o", str(OUT / f"{name}.pdf"), str(OUT / f"{name}.svg")],  # noqa: S607
        check=True,
        env={"SOURCE_DATE_EPOCH": "0", "PATH": "/opt/homebrew/bin:/usr/bin:/bin"},
    )


def main() -> int:
    """Build the negative UPV marks for the active alternative."""
    alt = _active()
    source = BRAND / "rediseno-20" / f"alternativa-{alt}" / f"rogle-{alt}-upv-convivencia.svg"
    positive = source.read_text(encoding="utf-8")
    negative = _recolor(positive)
    only_upv = ("separador", "isotipo", "logotipo")
    _write("upv-rogle-positivo", _crop(positive))
    _write("upv-positivo", _crop(_remove_groups(positive, only_upv)))
    _write("upv-rogle-negativo", _crop(negative))
    _write("upv-negativo", _crop(_remove_groups(negative, only_upv)))
    print(f"UPV marks built from alternative {alt} in {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
