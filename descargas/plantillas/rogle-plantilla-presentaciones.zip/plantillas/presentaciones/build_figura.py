"""Draw the sample figure of the presentation template: delivery routes before and after grouping.

The figure is schematic and the data are invented (same thread as the PowerPoint sample in
``plantillas/office/muestra/``). It writes ``figura-rutas.svg`` for Reveal.js and ``figura-rutas.pdf`` for Beamer.
Run with ``python3 build_figura.py``. Needs ``rsvg-convert``.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

__all__ = ["main"]

HERE = Path(__file__).resolve().parent
OXFORD, INDIGO, INDIGO_MID, GREY, RULE = "#002147", "#3F4AA8", "#5B67C7", "#5B6770", "#CFCFCF"
FONT = "'Gill Sans', 'Gill Sans MT', 'Gillius ADF', Calibri, sans-serif"

PANEL_W, PANEL_H, GAP, LABEL_H = 340, 330, 24, 34
WIDTH = 2 * PANEL_W + GAP
HEIGHT = LABEL_H + PANEL_H

DEPOT = (0.5, 0.92)
POINTS = {
    "L1": (0.14, 0.12),
    "L2": (0.30, 0.42),
    "L3": (0.16, 0.68),
    "R1": (0.86, 0.12),
    "R2": (0.70, 0.42),
    "R3": (0.84, 0.68),
}
ROUTES_BEFORE = ((("L1", "R2", "L3"), GREY), (("R1", "L2", "R3"), INDIGO_MID))
ROUTES_AFTER = ((("L1", "L2", "L3"), INDIGO), (("R1", "R2", "R3"), INDIGO_MID))
PANELS = (("Antes · 412 km", ROUTES_BEFORE), ("Después · 331 km", ROUTES_AFTER))


def _panel(index: int, caption: str, routes: tuple) -> str:
    """Return the SVG of one panel: caption, frame, routes, customers and depot."""
    left = index * (PANEL_W + GAP)
    top = LABEL_H
    inset = 16

    def at(point: tuple[float, float]) -> tuple[float, float]:
        return (left + inset + point[0] * (PANEL_W - 2 * inset), top + inset + point[1] * (PANEL_H - 2 * inset))

    parts = [
        f'<text x="{left}" y="22" font-family="{FONT}" font-size="17" font-weight="700" '
        f'fill="{OXFORD}">{caption}</text>',
        f'<rect x="{left}" y="{top}" width="{PANEL_W}" height="{PANEL_H}" fill="#FFFFFF" '
        f'stroke="{RULE}" stroke-width="1"/>',
    ]
    depot = at(DEPOT)
    for stops, color in routes:
        chain = [depot, *(at(POINTS[s]) for s in stops), depot]
        path = " ".join(f"{x:.1f},{y:.1f}" for x, y in chain)
        parts.append(
            f'<polyline points="{path}" fill="none" stroke="{color}" stroke-width="3" stroke-linejoin="round"/>',
        )
    for point in POINTS.values():
        x, y = at(point)
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="7" fill="{OXFORD}"/>')
    parts.append(f'<rect x="{depot[0] - 9:.1f}" y="{depot[1] - 9:.1f}" width="18" height="18" fill="{INDIGO}"/>')
    return "\n".join(parts)


def main() -> int:
    """Write ``figura-rutas.svg`` and ``figura-rutas.pdf`` next to this file."""
    body = "\n".join(_panel(i, caption, routes) for i, (caption, routes) in enumerate(PANELS))
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}" '
        'role="img" aria-labelledby="t d">\n'
        '<title id="t">Rutas de reparto antes y después de agrupar paradas</title>\n'
        '<desc id="d">Dos esquemas del centro Norte. Antes, las rutas se cruzan y suman 412 km. '
        "Después, cada vehículo atiende una zona y suman 331 km.</desc>\n"
        f"{body}\n</svg>\n"
    )
    svg_path = HERE / "figura-rutas.svg"
    svg_path.write_text(svg, encoding="utf-8")
    subprocess.run(  # noqa: S603
        ["rsvg-convert", "-f", "pdf", "-o", str(HERE / "figura-rutas.pdf"), str(svg_path)],  # noqa: S607
        check=True,
    )
    print(f"Wrote {svg_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
