-- ROGLE presentations: Pandoc/Quarto Lua filter for Reveal.js and Beamer.
--
-- YAML options read from the document:
--   tracker:   lateral | superior | inferior | pasos | ninguno   (default lateral)
--   borrador:  short label for the footer, e.g. "Datos ilustrativos" (optional)
--   portada:   positiva | negativa   (default positiva) cover and back cover:
--              positiva = Oxford Blue field plus white band with the UPV and ROGLE logos in positive;
--              negativa = all Oxford Blue with the logos in white
-- Markup (the same in both formats):
--   # Section                     section: divider slide + entry in the tracker
--   # Section {.sin-separador}    section without divider slide (it still counts in the tracker)
--   ## Title {data-tracker="superior"}   tracker of that slide only (also: ninguno)
--   ## {.contraportada}           back cover
--   ::: {.mensaje} ... :::        key message bar
--   ::: {.fuente} ... :::         source line
--   ::: {.etiqueta} ... :::       small label above the title
--   ::: {.agenda} :::             agenda: the sections, the current one highlighted
--   ::: {.bloques}, ::: {.comparacion}, ::: {.cierre}, ::: {.formula}   layout blocks
--
-- Reveal.js: the filter only passes the options to the script in rogle20-reveal.html and
-- prepares the section slides. Beamer: the filter turns the divs into LaTeX environments of
-- rogle20-beamer.tex and wraps every slide in a frame environment.

local PORTADAS = { positiva = true, negativa = true }
local MODES = { lateral = true, superior = true, inferior = true, pasos = true, ninguno = true }

local function text_of(value)
  if value == nil then return nil end
  return pandoc.utils.stringify(value)
end

local function has_class(el, name)
  for _, c in ipairs(el.classes) do
    if c == name then return true end
  end
  return false
end

local function latex_inlines(inlines)
  local out = pandoc.write(pandoc.Pandoc({ pandoc.Plain(inlines) }), 'latex')
  return (out:gsub('%s+$', ''))
end

local function raw(s) return pandoc.RawBlock('latex', s) end

local function js_string(s)
  return '"' .. s:gsub('\\', '\\\\'):gsub('"', '\\"') .. '"'
end

local function add_header_include(doc, block)
  local includes = doc.meta['header-includes'] or pandoc.MetaList({})
  if includes.t ~= 'MetaList' then includes = pandoc.MetaList({ includes }) end
  includes[#includes + 1] = pandoc.MetaBlocks({ block })
  doc.meta['header-includes'] = includes
end

-- ----------------------------------------------------------------- Reveal.js
-- Background of the cover and the back cover. The positive design is an Oxford Blue field of 80 % of the
-- height, an amber rule of 6 px and a white band; the negative one is all Oxford Blue.
local GRADIENT = 'linear-gradient(to bottom, #002147 0%, #002147 80%, #F5B000 80%, #F5B000 80.84%, ' ..
  '#FFFFFF 80.84%, #FFFFFF 100%)'

local function reveal(doc, tracker, draft, portada)
  -- Sections come from the level-1 headings. Every heading gets its section number (data-sec),
  -- because Reveal.js removes hidden slides from the DOM in print mode (?print-pdf).
  local titles = {}
  local blocks = {}
  for _, b in ipairs(doc.blocks) do
    local keep = true
    if b.t == 'Header' and b.level == 1 then
      titles[#titles + 1] = js_string(pandoc.utils.stringify(b.content))
      -- A section without divider slide leaves no slide at all: it only counts in the tracker.
      if has_class(b, 'sin-separador') then
        keep = false
      else
        b.attributes['data-background-color'] = '#002147'
      end
    end
    if b.t == 'Header' and b.level <= 2 then
      b.attributes['data-sec'] = tostring(#titles)
      if has_class(b, 'contraportada') then
        if portada == 'positiva' then
          b.attributes['data-background-gradient'] = GRADIENT
        else
          b.attributes['data-background-color'] = '#002147'
        end
      end
    end
    if keep then blocks[#blocks + 1] = b end
  end
  -- Pandoc turns a div that holds a heading into a <section>, which Reveal.js would take for a slide.
  -- Inside layout blocks the level-3 headings become plain divs with class rg-h3.
  doc = pandoc.Pandoc(blocks, doc.meta)
  doc = doc:walk({
    Div = function(div)
      if has_class(div, 'bloque') or has_class(div, 'opcion') or has_class(div, 'decision') then
        local content = {}
        for _, b in ipairs(div.content) do
          if b.t == 'Header' then
            content[#content + 1] = pandoc.Div({ pandoc.Plain(b.content) }, pandoc.Attr('', { 'rg-h3' }))
          else
            content[#content + 1] = b
          end
        end
        div.content = content
        return div
      end
    end,
  })
  add_header_include(doc, pandoc.RawBlock('html',
    '<script>window.ROGLE = {tracker: ' .. js_string(tracker) .. ', borrador: ' .. js_string(draft) ..
    ', portada: ' .. js_string(portada) .. ', secciones: [' .. table.concat(titles, ', ') .. ']};</script>'))
  -- Background of the cover (Quarto reads title-slide-attributes after this filter).
  local attrs = pandoc.MetaMap({})
  if portada == 'positiva' then
    attrs['data-background-gradient'] = pandoc.MetaString(GRADIENT)
  else
    attrs['data-background-color'] = pandoc.MetaString('#002147')
  end
  doc.meta['title-slide-attributes'] = attrs
  return doc
end

-- ------------------------------------------------------------------- Beamer
local ENV = {
  mensaje = 'roglemensaje',
  fuente = 'roglefuente',
  etiqueta = 'rogleetiqueta',
  formula = 'rogleformula',
  gracias = 'roglegracias',
  contacto = 'roglecontacto',
}

-- Level-3 headings inside a layout block become a LaTeX macro (no Beamer block).
local function blocks_of(div, head_macro, before, after)
  local out = {}
  if before then out[#out + 1] = raw(before) end
  for _, b in ipairs(div.content) do
    if b.t == 'Header' and b.level == 3 then
      out[#out + 1] = raw('\\' .. head_macro .. '{' .. latex_inlines(b.content) .. '}')
    else
      out[#out + 1] = b
    end
  end
  if after then out[#out + 1] = raw(after) end
  return out
end

-- Turn the child divs of a layout block into the columns of a Beamer `columns` environment.
local function columns_of(div, widths, head_macro, opens, closes)
  local cols = {}
  local i = 0
  for _, child in ipairs(div.content) do
    if child.t == 'Div' then
      i = i + 1
      local blocks = blocks_of(child, head_macro, opens and opens[i], closes and closes[i])
      cols[#cols + 1] = pandoc.Div(blocks, pandoc.Attr('', { 'column' }, { width = widths[i] or widths[#widths] }))
    end
  end
  return pandoc.Div(cols, pandoc.Attr('', { 'columns', 'onlytextwidth' }))
end

local function beamer_div(div)
  if has_class(div, 'columns') and not has_class(div, 'onlytextwidth') then
    div.classes:insert('onlytextwidth')
    return div
  end
  if has_class(div, 'etiqueta') then
    div = div:walk({ Str = function(s) return pandoc.Str(pandoc.text.upper(s.text)) end })
  end
  for class, env in pairs(ENV) do
    if has_class(div, class) then
      return blocks_of(div, 'rogleh', '\\begin{' .. env .. '}', '\\end{' .. env .. '}')
    end
  end
  if has_class(div, 'agenda') then return raw('\\rogleagenda') end
  if has_class(div, 'bloques') then
    local open = '\\roglebloquehead'
    return { raw('\\roglebloquesreset'),
             columns_of(div, { '0.29', '0.29', '0.29' }, 'rogleh', { open, open, open }) }
  end
  if has_class(div, 'comparacion') then
    return columns_of(div, { '0.29', '0.29', '0.29' }, 'roglehopcion')
  end
  if has_class(div, 'cierre') then
    return columns_of(div, { '0.55', '0.38' }, 'roglehdecision',
      { nil, '\\begin{rogledecision}' }, { nil, '\\end{rogledecision}' })
  end
end

local function map_cells(rows, wrap)
  local out = {}
  for _, row in ipairs(rows) do
    local cells = {}
    for _, cell in ipairs(row.cells) do
      local blocks = {}
      for _, block in ipairs(cell.contents) do
        if block.t == 'Plain' or block.t == 'Para' then
          blocks[#blocks + 1] = pandoc.Plain(wrap(block.content))
        else
          blocks[#blocks + 1] = block
        end
      end
      cells[#cells + 1] = pandoc.Cell(blocks, cell.alignment, cell.row_span, cell.col_span, cell.attr)
    end
    out[#out + 1] = pandoc.Row(cells, row.attr)
  end
  return out
end

-- Header cells in Gill Sans bold; tables with class "total" bold in the last row.
local function beamer_table(tbl)
  local head_rows = map_cells(tbl.head.rows, function(inlines)
    local out = { pandoc.RawInline('latex', '\\rogleth{') }
    for _, inline in ipairs(inlines) do out[#out + 1] = inline end
    out[#out + 1] = pandoc.RawInline('latex', '}')
    return out
  end)
  local bodies = {}
  for _, body in ipairs(tbl.bodies) do
    local rows = {}
    for i, row in ipairs(body.body) do rows[i] = row end
    if has_class(tbl, 'total') and #rows > 0 then
      rows[#rows] = map_cells({ rows[#rows] }, function(inlines) return { pandoc.Strong(inlines) } end)[1]
    end
    bodies[#bodies + 1] = { attr = body.attr, row_head_columns = body.row_head_columns,
                            head = body.head, body = rows }
  end
  return pandoc.Table(tbl.caption, tbl.colspecs, pandoc.TableHead(head_rows, tbl.head.attr),
                      bodies, tbl.foot, tbl.attr)
end

local function beamer(doc, tracker, draft, portada)
  -- Beamer draws the background when a frame begins, before its body runs. So the state of each slide
  -- (tracker, kind of page, current section) goes into the frame title with \\roglemode, and the list of
  -- sections goes into the preamble. No .aux file is involved.
  local titles = {}
  for _, b in ipairs(doc.blocks) do
    if b.t == 'Header' and b.level == 1 then titles[#titles + 1] = latex_inlines(b.content) end
  end
  local steps = {}
  for i, title in ipairs(titles) do steps[i] = '\\roglestep{' .. i .. '}{' .. title .. '}' end
  add_header_include(doc, raw('\\makeatletter\\gdef\\rogle@draft{' .. draft .. '}\\gdef\\rogle@total{' ..
    #titles .. '}\\gdef\\rogle@portada{' .. portada .. '}\\gdef\\rogle@baseL{' .. (tracker == 'lateral' and '210' or '72') ..
    '}\\setbeamersize{text margin left=' .. (tracker == 'lateral' and '157.5' or '54') .. 'pt,text margin right=54pt}' ..
    '\\gdef\\roglesecs{' .. table.concat(steps) .. '}\\makeatother'))

  doc = doc:walk({ Div = beamer_div, Table = beamer_table })

  local function mode_inline(mode, section)
    return pandoc.RawInline('latex', '\\roglemode{' .. mode .. '}{' .. section .. '}')
  end

  -- Top level: every slide is wrapped in the frame environment. A section with divider becomes a frame of
  -- its own; a section without divider only counts in the tracker.
  local out = {}
  local open = false
  local section = 0
  local function close()
    if open then
      out[#out + 1] = raw('\\end{rogleframe}')
      open = false
    end
  end
  for _, b in ipairs(doc.blocks) do
    if b.t == 'Header' and b.level == 1 then
      close()
      section = section + 1
      if not has_class(b, 'sin-separador') then
        out[#out + 1] = pandoc.Header(2, { mode_inline('divider', section) }, pandoc.Attr('', { 'plain' }))
        out[#out + 1] = raw('\\begin{rogleframe}{divider}{' .. section .. '}')
        out[#out + 1] = raw('\\rogledivider{' .. titles[section] .. '}')
        open = true
      end
    elseif b.t == 'Header' and b.level == 2 then
      close()
      local mode = b.attributes['data-tracker'] or b.attributes['tracker']
      if mode == nil or not MODES[mode] then mode = tracker end
      if has_class(b, 'contraportada') then
        b.classes:insert('plain')
        mode = 'back'
      end
      local content = { mode_inline(mode, section) }
      for _, inline in ipairs(b.content) do content[#content + 1] = inline end
      b.content = content
      out[#out + 1] = b
      out[#out + 1] = raw('\\begin{rogleframe}{' .. mode .. '}{' .. section .. '}')
      open = true
    else
      out[#out + 1] = b
    end
  end
  close()
  doc.blocks = out
  return doc
end

-- ---------------------------------------------------------------------- main
function Pandoc(doc)
  local tracker = text_of(doc.meta.tracker) or 'lateral'
  if not MODES[tracker] then
    io.stderr:write('rogle-presentacion: unknown tracker "' .. tracker .. '", using lateral\n')
    tracker = 'lateral'
  end
  local draft = text_of(doc.meta.borrador) or ''
  local portada = text_of(doc.meta.portada) or 'positiva'
  if not PORTADAS[portada] then
    io.stderr:write('rogle-presentacion: unknown portada "' .. portada .. '", using positiva\n')
    portada = 'positiva'
  end
  if FORMAT:match('revealjs') then return reveal(doc, tracker, draft, portada) end
  if FORMAT:match('beamer') then return beamer(doc, tracker, draft, portada) end
end
