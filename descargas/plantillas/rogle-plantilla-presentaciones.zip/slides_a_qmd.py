"""Convert a Claude Slides deck into a ``rogle-slides`` Quarto document.

The input is the folder that an Artifact ``read`` of the deck saves: ``project/deck.json`` (order of
the slides) and ``project/slides/<id>.html`` (one ``<section>`` each, inline styles, absolute
positions). The deck must come from one of the two ROGLE master decks (teaching and research), which mirror
``ROGLE.potx``.

The role of each element is inferred from its style and position, not from the id of the slide or
from ``data-`` attributes: a deck is made by copying slides of the master, so ids change, and the
Slides format does not promise to keep unknown attributes.

Usage::

    uv run plantillas/presentaciones/slides_a_qmd.py CARPETA -o charla.qmd [--figuras DIR] [--quitar-corchetes]

The conversion is one-way: the ``.qmd`` is the original from then on.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path

__all__ = ["Result", "convert", "main"]

# Colours of the master deck that identify a role.
_OXFORD = "#002147"
_AMBER = "#f5b000"
_WHITE = "#ffffff"
_SOFT_TINTS = frozenset({"#f3f4fa", "#f4f4fa"})  # key message and side menu
_PANEL_TINT = "#e3e3f1"  # decision panel and citation box
# Positions in px of the 1920 x 1080 slide.
_FOOTER_TOP = 1000.0  # the footer line and everything under it
_MENU_TOP_MAX = 100.0  # the top and steps trackers end above this
_MENU_BOTTOM_MIN = 900.0  # the bottom tracker begins under this
_SIDE_MENU_MAX = 250.0  # width of the side menu
_KEY_MESSAGE_TOP = 800.0  # the key message is under this
_DRAFT_BAND = (940.0, 1005.0)  # the draft label sits on the source line
_MENU_FONT_MAX = 26.0  # the tracker is set at 24 px
_BIG_NUMBER = 56.0  # numbers of the agenda and of the summary blocks, and larger
_DIVIDER_NUMBER = 150.0  # the section number of a divider
_RULE_HEIGHT = 6.0  # hairlines and bars are thinner than this
_INDENT = 30.0  # left padding of a second-level bullet
_COLUMN_TOLERANCE = 4.0  # two elements closer than this share a column

_TRACKERS = {
    "side": "lateral",
    "top": "superior",
    "bottom": "inferior",
    "steps": "pasos",
    "none": "ninguno",
}
_DEFAULT_LICENCE = "CC BY-NC-SA 4.0"
_DEFAULT_ASK = "Gracias. ¿Preguntas?"
_DEFAULT_WEB = "https://rogle.webs.upv.es/"
_SUPERSCRIPTS = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")
_MARKS = re.compile(r"[⁰¹²³⁴⁵⁶⁷⁸⁹,*]+$")
_LEADING_MARK = re.compile(r"^[⁰¹²³⁴⁵⁶⁷⁸⁹]+")
_MENU_ITEM = re.compile(r"^(\d+)\s+(\S.*)$")
_SUBSECTION = re.compile(r"^(\d+)\.(\d+)\s+(\S.*)$")
_ORDINAL = re.compile(r"^\d+\.$")
_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
_URL = re.compile(r"https?://\S+")
_BLOB = re.compile(r"/_blob/([0-9a-f]{32})")
_ESCAPE = re.compile(r"([\\*_\[\]$`<>|~^])")
_MONTHS = (
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
)  # fmt: skip
_SPANISH_DATE = re.compile(r"^(\d{1,2}) de ([a-záéíóú]+) de (\d{4})$", re.I)
_LOGO_NAMES = (
    (re.compile(r"generalitat", re.I), "gva"),
    (re.compile(r"\bUE\b|uni[oó]n europea|european union", re.I), "ue"),
    (re.compile(r"industrial|ETSII", re.I), "etsii"),
)
_FUNDERS = frozenset({"gva", "ue"})
_VOID = frozenset({"img", "br", "hr", "polygon", "path", "rect", "circle", "line", "col"})
_INLINE_MARK = {"b": "**", "strong": "**", "i": "*", "em": "*"}


@dataclass
class _Node:
    """An element of a slide: tag, attributes, inline style and children (nodes or text)."""

    tag: str
    attrs: dict[str, str] = field(default_factory=dict)
    style: dict[str, str] = field(default_factory=dict)
    children: list[_Node | str] = field(default_factory=list)

    def px(self, name: str) -> float | None:
        match = re.match(r"-?\d+(?:\.\d+)?", self.style.get(name, ""))
        return float(match.group()) if match else None

    def colour(self, name: str = "color") -> str:
        return self.style.get(name, "").lower()

    @property
    def bold(self) -> bool:
        return "bold" in self.style.get("font-family", "").lower()

    @property
    def nodes(self) -> list[_Node]:
        return [child for child in self.children if isinstance(child, _Node)]

    def walk(self) -> list[_Node]:
        found = [self]
        for child in self.nodes:
            found.extend(child.walk())
        return found

    def find(self, tag: str) -> list[_Node]:
        return [node for node in self.walk() if node.tag == tag]


class _Parser(HTMLParser):
    """Build the tree of one slide."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _Node("root")
        self._stack = [self.root]

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {key: value or "" for key, value in attrs}
        style = {}
        for part in values.get("style", "").split(";"):
            if ":" in part:
                key, value = part.split(":", 1)
                style[key.strip().lower()] = value.strip()
        node = _Node(tag, values, style)
        self._stack[-1].children.append(node)
        if tag not in _VOID:
            self._stack.append(node)

    def handle_endtag(self, tag: str) -> None:
        for depth in range(len(self._stack) - 1, 0, -1):
            if self._stack[depth].tag == tag:
                del self._stack[depth:]
                return

    def handle_data(self, data: str) -> None:
        self._stack[-1].children.append(data)


def _parse(markup: str) -> _Node:
    parser = _Parser()
    parser.feed(markup)
    sections = parser.root.find("section")
    return sections[0] if sections else parser.root


@dataclass
class Result:
    """Outcome of a conversion.

    Attributes
    ----------
    qmd : str
        The Quarto document.
    warnings : list of str
        What was approximated or dropped, in Spanish, one line each.
    figures : dict of str to str
        Asset id of every figure of the deck and the path the document gives it.
    """

    qmd: str
    warnings: list[str]
    figures: dict[str, str]


class _Converter:
    def __init__(self, figures_dir: Path | None, figures_ref: str, strip_brackets: bool) -> None:
        self.figures_dir = figures_dir
        self.figures_ref = figures_ref
        self.strip_brackets = strip_brackets
        self.warnings: list[str] = []
        self.figures: dict[str, str] = {}

    # ------------------------------------------------------------------ text
    def _clean(self, text: str) -> str:
        return text.replace("[", "").replace("]", "") if self.strip_brackets else text

    def plain(self, node: _Node | str) -> str:
        """Text of a node on one line, without markup."""
        if isinstance(node, str):
            return self._clean(node)
        if node.tag == "br":
            return "\n"
        return "".join(self.plain(child) for child in node.children)

    def text(self, node: _Node) -> str:
        return re.sub(r"[ \t\r\n]+", " ", self.plain(node)).strip()

    def lines(self, node: _Node) -> list[str]:
        return [
            line
            for line in (re.sub(r"\s+", " ", part).strip() for part in self.plain(node).split("\n"))
            if line
        ]

    @staticmethod
    def escape(text: str) -> str:
        """Plain text as Markdown."""
        return _ESCAPE.sub(r"\\\1", text)

    def markdown(self, node: _Node | str) -> str:
        """Inline Markdown of a node: bold, italics, links and line breaks."""
        if isinstance(node, str):
            return _ESCAPE.sub(r"\\\1", re.sub(r"[ \t\r\n]+", " ", self._clean(node)))
        if node.tag == "br":
            return "\\\n"
        inner = "".join(self.markdown(child) for child in node.children)
        mark = _INLINE_MARK.get(node.tag)
        if mark and inner.strip():
            lead = inner[: len(inner) - len(inner.lstrip())]
            trail = inner[len(inner.rstrip()) :]
            return f"{lead}{mark}{inner.strip()}{mark}{trail}"
        if node.tag == "a" and node.attrs.get("href"):
            return f"[{inner}]({node.attrs['href']})"
        return inner

    def paragraph(self, node: _Node) -> str:
        text = self.markdown(node).strip()
        # A line that begins like a list or a heading would change its meaning.
        return re.sub(r"^(\d+)\.(\s)", r"\1\\.\2", re.sub(r"^([#+-])(\s)", r"\\\1\2", text))

    # ------------------------------------------------------------------ kinds
    def kind(self, slide: _Node) -> str:
        if slide.find("h1"):
            return "cover"
        dark = slide.colour("background") == _OXFORD or slide.colour("background-color") == _OXFORD
        sizes = [node.px("font-size") or 0.0 for node in slide.find("p")]
        if dark:
            return "divider" if any(size >= _DIVIDER_NUMBER for size in sizes) else "close"
        if not slide.find("h2"):
            return "blank"
        rows = [
            node
            for node in slide.find("p")
            if node.px("font-size") == _BIG_NUMBER and self.text(node).isdigit()
        ]
        nested = [node for node in rows if node not in slide.nodes]
        return "agenda" if nested else "content"

    # ------------------------------------------------------------------ body
    def figure(self, node: _Node) -> str:
        source = node.attrs.get("src", "")
        alt = self._clean(node.attrs.get("alt", "")).strip()
        match = _BLOB.search(source)
        if not match:
            return f"![{alt}]({source})"
        asset = match.group(1)
        path = f"{self.figures_ref}/{asset}"
        found = (
            sorted(self.figures_dir.glob(f"{asset}.*"))
            if self.figures_dir and self.figures_dir.is_dir()
            else []
        )
        if found:
            path = f"{self.figures_ref}/{found[0].name}"
        else:
            self.warnings.append(
                f"Falta la figura {asset}: léela del mazo y guárdala en {self.figures_ref}/."
            )
        self.figures[asset] = path
        return f"![{alt}]({path})" + (f'{{fig-alt="{alt}"}}' if alt else "")

    def _row_item(self, row: _Node) -> tuple[int, bool, str] | None:
        """A row of a list of the deck: level, whether it is numbered, and its text."""
        parts = row.nodes
        texts = [part for part in parts if part.tag == "p"]
        if not texts:
            return None
        level = 1 if (row.px("padding-left") or 0.0) >= _INDENT else 0
        numbered = len(texts) > 1 and bool(_ORDINAL.match(self.text(texts[0])))
        return level, numbered, self.paragraph(texts[-1])

    def block(self, node: _Node) -> list[str]:
        """Markdown lines of one element of the body."""
        if node.tag == "img":
            return [self.figure(node)]
        if node.tag == "svg":
            self.warnings.append(
                "Un gráfico SVG no se convierte: expórtalo como imagen y añádelo al .qmd."
            )
            return []
        if node.tag == "table":
            return self.table(node)
        if node.tag in {"ul", "ol"}:
            return self.html_list(node, 0)
        if node.tag in {"p", "h3"}:
            text = self.paragraph(node)
            if not text:
                return []
            return [f"**{text}**" if node.bold or node.tag == "h3" else text]
        if node.tag != "div":
            return []
        rows = [self._row_item(child) for child in node.nodes if child.tag == "div"]
        if rows and all(row is not None for row in rows) and len(rows) == len(node.nodes):
            out, number = [], 0
            for level, numbered, text in (row for row in rows if row is not None):
                if numbered:
                    number += 1
                marker = f"{number}." if numbered else "-"
                out.append(f"{'    ' * level}{marker} {text}")
            return out
        out = []
        for child in node.nodes:
            piece = self.block(child)
            if piece and out:
                out.append("")
            out.extend(piece)
        return out

    def html_list(self, node: _Node, level: int) -> list[str]:
        out = []
        for index, item in enumerate((child for child in node.nodes if child.tag == "li"), start=1):
            inline = _Node(
                "span",
                children=[
                    c for c in item.children if not (isinstance(c, _Node) and c.tag in {"ul", "ol"})
                ],
            )
            marker = f"{index}." if node.tag == "ol" else "-"
            out.append(f"{'    ' * level}{marker} {self.paragraph(inline)}")
            for child in item.nodes:
                if child.tag in {"ul", "ol"}:
                    out.extend(self.html_list(child, level + 1))
        return out

    def table(self, node: _Node) -> list[str]:
        rows = [
            [
                self.paragraph(cell).replace("\\\n", " ")
                for cell in row.nodes
                if cell.tag in {"th", "td"}
            ]
            for row in node.find("tr")
        ]
        rows = [row for row in rows if row]
        if not rows:
            return []
        width = max(len(row) for row in rows)
        rows = [row + [""] * (width - len(row)) for row in rows]
        out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * width]
        out.extend("| " + " | ".join(row) + " |" for row in rows[1:])
        return out

    def _columns(self, items: list[_Node]) -> list[list[_Node]]:
        columns: list[tuple[float, list[_Node]]] = []
        for item in sorted(items, key=lambda node: (node.px("left") or 0.0, node.px("top") or 0.0)):
            left = item.px("left") or 0.0
            if columns and abs(columns[-1][0] - left) <= _COLUMN_TOLERANCE:
                columns[-1][1].append(item)
            else:
                columns.append((left, [item]))
        return [sorted(column, key=lambda node: node.px("top") or 0.0) for _, column in columns]

    def _is_number(self, node: _Node) -> bool:
        return (
            node.tag == "p"
            and self.text(node).isdigit()
            and (node.px("font-size") or 0.0) >= _BIG_NUMBER
        )

    def _join(self, column: list[_Node]) -> list[str]:
        out: list[str] = []
        for node in column:
            piece = self.block(node)
            if piece and out:
                out.append("")
            out.extend(piece)
        return out

    def _headed(self, column: list[_Node]) -> tuple[str, list[_Node]] | None:
        rest = [node for node in column if not self._is_number(node)]
        if rest and rest[0].tag == "p" and rest[0].bold:
            return self.paragraph(rest[0]), rest[1:]
        return None

    def body(self, items: list[_Node]) -> list[str]:
        """Markdown of the body of a content slide, with its layout."""
        panels = [
            node for node in items if node.tag == "p" and node.colour("background") == _PANEL_TINT
        ]
        others = [node for node in items if node not in panels]
        columns = self._columns(others)
        if panels:
            out = [
                "::: {.cierre}",
                "::: {.pasos}",
                *self._join([n for column in columns for n in column]),
                ":::",
                "",
            ]
            out += [
                "::: {.decision}",
                *[line for panel in panels for line in self.block(panel)],
                ":::",
                ":::",
            ]
            return out
        if len(columns) <= 1:
            return self._join(columns[0]) if columns else []
        headed = [self._headed(column) for column in columns]
        if all(headed):
            numbered = all(any(self._is_number(node) for node in column) for column in columns)
            outer, inner = ("bloques", "bloque") if numbered else ("comparacion", "opcion")
            out = [f"::: {{.{outer}}}"]
            for heading, rest in (pair for pair in headed if pair):
                out += [f"::: {{.{inner}}}", f"### {heading}", "", *self._join(rest), ":::", ""]
            out[-1] = ":::"
            return out
        total = sum((column[0].px("width") or 1.0) for column in columns)
        out = [":::: {.columns}"]
        for column in columns:
            share = round(100 * (column[0].px("width") or 1.0) / total)
            out += [f'::: {{.column width="{share}%"}}', *self._join(column), ":::", ""]
        out[-1] = "::::"
        return out

    # ------------------------------------------------------------------ content slide
    def content(self, slide: _Node) -> dict[str, object]:
        """Roles of a content slide."""
        info: dict[str, object] = {
            "menu": [],
            "subs": [],
            "body": [],
            "notes": [],
            "tracker": "none",
        }
        menu: list[tuple[int, str, bool, _Node]] = []
        for node in slide.nodes:
            top = node.px("top") or 0.0
            left = node.px("left") or 0.0
            background = node.colour("background")
            text = self.text(node) if node.tag != "img" else ""
            if node.tag == "aside":
                info["notes"] = [self.paragraph(node)] if text else []
            elif node.tag == "h2":
                info["title"] = self.paragraph(node).replace("\\\n", " ")
            elif node.tag == "svg" and top < _MENU_TOP_MAX:
                info["tracker"] = "steps"
            elif node.tag == "p" and _SUBSECTION.match(text) and left < _SIDE_MENU_MAX:
                match = _SUBSECTION.match(text)
                assert match is not None
                info["subs"].append(
                    (int(match.group(2)), self.escape(match.group(3).strip()), node.bold)
                )  # type: ignore[attr-defined]
            elif (
                node.tag == "p"
                and _MENU_ITEM.match(text)
                and (node.px("font-size") or 0.0) <= _MENU_FONT_MAX
                and (
                    left < _SIDE_MENU_MAX
                    or top < _MENU_TOP_MAX
                    or _MENU_BOTTOM_MIN < top < _FOOTER_TOP
                )
            ):
                match = _MENU_ITEM.match(text)
                assert match is not None
                menu.append(
                    (int(match.group(1)), self.escape(match.group(2).strip()), node.bold, node)
                )
            elif top > _FOOTER_TOP:
                if node.tag == "p" and not text.isdigit():
                    info["footer"] = node
            elif node.tag == "p" and text.lower().startswith("fuente"):
                info["source"] = self.paragraph(node)
            elif node.tag == "p" and background in _SOFT_TINTS and top > _KEY_MESSAGE_TOP:
                info["message"] = self.paragraph(node)
            elif (
                node.tag == "p"
                and _DRAFT_BAND[0] < top < _DRAFT_BAND[1]
                and node.style.get("text-align") == "right"
            ):
                info["draft"] = text
            elif (
                node.tag == "div"
                and (not text or (node.px("height") or _RULE_HEIGHT + 1) <= _RULE_HEIGHT)
                and not node.find("img")
            ):
                continue  # panel of the menu, hairlines, bars
            else:
                info["body"].append(node)  # type: ignore[attr-defined]
        if menu:
            first = menu[0][3]
            if info["tracker"] != "steps":
                top = first.px("top") or 0.0
                side = (first.px("left") or 0.0) < _SIDE_MENU_MAX and len(
                    {item[3].px("left") for item in menu}
                ) == 1
                info["tracker"] = "side" if side else "top" if top < _MENU_TOP_MAX else "bottom"
            info["menu"] = [(number, name, current) for number, name, current, _ in menu]
        return info

    # ------------------------------------------------------------------ cover and close
    def _author(self, node: _Node) -> dict[str, object]:
        raw = self.text(node)
        marks = _MARKS.search(raw)
        name = raw[: marks.start()].strip() if marks else raw
        refs = marks.group().translate(_SUPERSCRIPTS) if marks else ""
        return {
            "name": name,
            "refs": [int(ref) for ref in re.findall(r"\d+", refs)],
            "corresponding": "*" in refs,
        }

    def _people(
        self, slide: _Node, name_colour: str
    ) -> tuple[list[dict[str, object]], dict[int, list[str]], str]:
        """Authors, affiliation lines by number, and the e-mail of the corresponding author."""
        authors: list[dict[str, object]] = []
        affiliations: dict[int, list[str]] = {}
        email = ""
        for node in slide.find("p"):
            family = node.style.get("font-family", "").lower()
            lines = self.lines(node)
            if not lines or "academicons" in family:
                continue
            if _LEADING_MARK.match(lines[0]):
                number = 0
                for line in lines:
                    mark = _LEADING_MARK.match(line)
                    if mark:
                        number = int(mark.group().translate(_SUPERSCRIPTS))
                        affiliations.setdefault(number, []).append(line[mark.end() :].strip())
                    elif line.startswith("*"):
                        found = _EMAIL.search(line)
                        email = found.group() if found else email
                    elif number:
                        affiliations[number].append(line)
            elif lines[0].startswith("*"):
                found = _EMAIL.search(lines[0])
                email = found.group() if found else email
            elif (
                node.colour() == name_colour
                and _MARKS.search(lines[0])
                and len(lines) == 1
                and not node.bold
            ):
                authors.append(self._author(node))
        return authors, affiliations, email

    def cover(self, slide: _Node) -> dict[str, object]:
        data: dict[str, object] = {"title": self.text(slide.find("h1")[0])}
        after_title = False
        for node in slide.walk():
            if node.tag == "h1":
                after_title = True
            if node.tag != "p":
                continue
            text = self.text(node)
            if node.colour() == _AMBER and "label" not in data:
                data["label"] = text
            elif (
                after_title
                and "subtitle" not in data
                and (node.px("font-size") or 0.0) >= 40.0
                and node.colour() != _WHITE
            ):
                data["subtitle"] = text
            elif _URL.fullmatch(text):
                data["link"] = text
        authors, affiliations, email = self._people(slide, _WHITE)
        data.update(authors=authors, affiliations=affiliations, email=email)
        candidates = [
            self.text(node)
            for node in slide.find("p")
            if node.colour() not in {_WHITE, _AMBER}
            and re.search(r"\b(?:19|20)\d\d\b", self.text(node))
            and not _LEADING_MARK.match(self.text(node))
            and not _URL.search(self.text(node))
            and self.text(node) != data.get("subtitle")
        ]
        if candidates:
            data["date"] = candidates[-1]
        logos = []
        for image in slide.find("img"):
            if (image.px("left") or 0.0) < 1000.0 and image in slide.nodes:
                continue  # the UPV, DOE and ROGLE block
            alt = image.attrs.get("alt", "")
            name = next((logo for pattern, logo in _LOGO_NAMES if pattern.search(alt)), None)
            if name:
                logos.append(name)
            elif image not in slide.nodes:
                self.warnings.append(
                    f"Logotipo de la portada sin equivalente en la extensión: «{alt}». Añade su archivo a rogle.logos."
                )
        data["logos"] = logos
        data["kind"] = "investigacion" if _FUNDERS & set(logos) else "docencia"
        return data

    def close(self, slide: _Node) -> dict[str, object]:
        data: dict[str, object] = {}
        headings = slide.find("h2")
        data["message"] = self.paragraph(headings[0]).replace("\\\n", " ") if headings else ""
        paragraphs = slide.find("p")
        for index, node in enumerate(paragraphs):
            text = self.text(node)
            following = paragraphs[index + 1] if index + 1 < len(paragraphs) else None
            if node.colour("background") == _PANEL_TINT:
                data["cite"] = self.markdown(node).replace("\\\n", " ").strip()
                if (
                    following is not None
                    and not following.bold
                    and not self.text(following).startswith("©")
                ):
                    data["adaptation"] = self.markdown(following).replace("\\\n", " ").strip()
            elif node.bold and text.lower().startswith("financiaci") and following is not None:
                data["funding"] = self.markdown(following).replace("\\\n", " ").strip()
            elif (
                (node.px("font-size") or 0.0) >= 36.0
                and node.tag == "p"
                and not node.bold
                and "ask" not in data
                and node.colour() != _WHITE
            ):
                data["ask"] = text
        authors, affiliations, email = self._people(slide, _WHITE)
        data.update(authors=authors, affiliations=affiliations, email=email)
        webs = [
            line
            for node in paragraphs
            for line in self.lines(node)
            if _URL.fullmatch(line) and node.colour() != _WHITE
        ]
        contact = [web for web in webs if "handle" not in web and "doi.org" not in web]
        if contact:
            data["web"] = contact[-1]
        return data

    def agenda(self, slide: _Node) -> dict[int, tuple[str, str]]:
        rows: dict[int, tuple[str, str]] = {}
        for node in slide.walk():
            if node.tag != "div":
                continue
            parts = node.nodes
            if (
                len(parts) == 2
                and parts[0].tag == "p"
                and self.text(parts[0]).isdigit()
                and parts[1].tag == "div"
            ):
                texts = [self.text(p) for p in parts[1].find("p")]
                name = self.escape(texts[0]) if texts else ""
                rows[int(self.text(parts[0]))] = (name, texts[1] if len(texts) > 1 else "")
        return rows

    def footer(self, node: _Node) -> dict[str, str]:
        data: dict[str, str] = {}
        italics = node.find("i")
        if italics:
            data["short"] = self.text(italics[0])
        rest = self.plain(
            _Node(
                "span",
                children=[c for c in node.children if not (isinstance(c, _Node) and c.tag == "i")],
            )
        )
        for part in (piece.strip() for piece in re.split(r"[  ]+|\s{2,}", rest)):
            if part.startswith("©"):
                data["copyright"] = part
            elif part.upper().startswith("CC "):
                data["licence"] = part
            elif part:
                data["identifier"] = part
        return data


def _quote(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _iso_date(text: str) -> str | None:
    """ISO form of a date written as «1 de octubre de 2026», or None."""
    text = text.replace("[", "").replace("]", "")
    match = _SPANISH_DATE.match(text.strip())
    if match and match.group(2).lower() in _MONTHS:
        month = _MONTHS.index(match.group(2).lower()) + 1
        return f"{match.group(3)}-{month:02d}-{int(match.group(1)):02d}"
    return text.strip() if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text.strip()) else None


def _yaml(
    cover: dict[str, object],
    close: dict[str, object],
    foot: dict[str, str],
    tracker: str,
    draft: str,
    warnings: list[str],
) -> list[str]:
    """Header of the document from the cover, the closing slide and the footer."""
    lines = ["---", f"title: {_quote(str(cover.get('title', 'Sin título')))}"]
    if cover.get("subtitle"):
        lines.append(f"subtitle: {_quote(str(cover['subtitle']))}")
    if cover.get("date"):
        date = _iso_date(str(cover["date"]))
        if date:
            lines += [f"date: {date}", "date-format: long"]
        else:
            warnings.append(
                f"No se entiende la fecha «{cover['date']}»: escríbela en el .qmd como AAAA-MM-DD."
            )
    lines.append("lang: es")
    authors = list(close.get("authors") or cover.get("authors") or [])  # type: ignore[call-overload]
    affiliations: dict[int, list[str]] = dict(
        close.get("affiliations") or cover.get("affiliations") or {}
    )  # type: ignore[call-overload]
    email = str(close.get("email") or cover.get("email") or "")
    if authors:
        lines.append("author:")
        for author in authors:
            lines.append(f"  - name: {_quote(str(author['name']))}")
            if author["corresponding"]:
                if email:
                    lines.append(f"    email: {email}")
                lines.append("    corresponding: true")
            refs = [ref for ref in author["refs"] if ref in affiliations]
            if refs:
                lines.append("    affiliations:")
                lines.extend(f"      - ref: a{ref}" for ref in refs)
    if affiliations:
        lines.append("affiliations:")
        for number in sorted(affiliations):
            parts = affiliations[number]
            lines.append(f"  - id: a{number}")
            # The extension joins department and name: the last piece of the line is the institution.
            department, _, name = parts[0].rstrip(",").rpartition(", ")
            if department:
                lines.append(f"    department: {_quote(department)}")
            lines.append(f"    name: {_quote(name)}")
            if len(parts) > 1:
                lines.append(f"    address: {_quote(', '.join(parts[1:]))}")
    lines.append(f"tracker: {_TRACKERS[tracker]}")
    lines.append(f"portada: {cover.get('kind', 'docencia')}")
    if draft:
        lines.append(f"borrador: {_quote(draft)}")
    rogle: list[tuple[str, str]] = []
    link = str(cover.get("link", ""))
    for key, value in (
        ("etiqueta", cover.get("label")),
        ("enlace", link),
        ("titulo-corto", foot.get("short")),
        ("copyright", foot.get("copyright")),
    ):
        if value:
            rogle.append((key, _quote(str(value))))
    if foot.get("licence") and foot["licence"] != _DEFAULT_LICENCE:
        rogle.append(("licencia", _quote(foot["licence"])))
    if foot.get("identifier") and foot["identifier"] != re.sub(r"^https?://", "", link):
        rogle.append(("identificador", _quote(foot["identifier"])))
    if cover.get("logos"):
        rogle.append(("logos", "[" + ", ".join(cover["logos"]) + "]"))  # type: ignore[arg-type]
    for key, name in (("cita", "cite"), ("adaptacion", "adaptation"), ("financiacion", "funding")):
        if close.get(name):
            rogle.append((key, _quote(str(close[name]))))
    if close.get("ask") and close["ask"] != _DEFAULT_ASK:
        rogle.append(("pregunta", _quote(str(close["ask"]))))
    if close.get("web") and close["web"] != _DEFAULT_WEB:
        rogle.append(("web", _quote(str(close["web"]))))
    if rogle:
        lines.append("rogle:")
        lines.extend(f"  {key}: {value}" for key, value in rogle)
    lines += [
        "brand: false",
        "format:",
        "  rogle-slides-revealjs: default",
        "  rogle-slides-beamer: default",
        "---",
    ]
    return lines


def convert(
    deck_dir: Path,
    figures_dir: Path | None = None,
    figures_ref: str = "figuras",
    strip_brackets: bool = False,
) -> Result:
    """Convert a saved Claude Slides deck into a ``rogle-slides`` document.

    Parameters
    ----------
    deck_dir : Path
        Folder with ``project/deck.json``, or the ``project`` folder itself.
    figures_dir : Path, optional
        Folder where the figures of the deck are saved, named ``<asset id>.<extension>``.
    figures_ref : str, default "figuras"
        Path of that folder as the document writes it.
    strip_brackets : bool, default False
        Remove the square brackets that mark the sample texts of the master deck.

    Returns
    -------
    Result
        The document, the warnings and the figures it names.

    Raises
    ------
    FileNotFoundError
        If the folder has no ``deck.json``.
    """
    project = deck_dir if (deck_dir / "deck.json").is_file() else deck_dir / "project"
    index_file = project / "deck.json"
    if not index_file.is_file():
        raise FileNotFoundError(f"No hay deck.json en {deck_dir}")
    order = json.loads(index_file.read_text(encoding="utf-8")).get("order", [])
    conv = _Converter(figures_dir, figures_ref, strip_brackets)
    slides: list[tuple[str, _Node]] = []
    for slide_id in order:
        slide_file = project / "slides" / f"{slide_id}.html"
        if not slide_file.is_file():
            conv.warnings.append(f"Falta el archivo de la diapositiva «{slide_id}».")
            continue
        slide = _parse(slide_file.read_text(encoding="utf-8"))
        slides.append((conv.kind(slide), slide))

    cover: dict[str, object] = {}
    close: dict[str, object] = {}
    agenda_rows: dict[int, tuple[str, str]] = {}
    agenda_title = ""
    names: dict[int, str] = {}
    dividers: dict[int, str] = {}
    contents: list[tuple[dict[str, object], int | None]] = []
    pending: int | None = None
    for kind, slide in slides:
        if kind == "cover":
            if cover:
                conv.warnings.append("Hay más de una portada: se usa la primera.")
            else:
                cover = conv.cover(slide)
        elif kind == "close":
            if close:
                conv.warnings.append("Hay más de un cierre: se usa el primero.")
            else:
                close = conv.close(slide)
        elif kind == "agenda":
            if agenda_rows:
                conv.warnings.append(
                    "Hay más de un índice: se usa el primero. La extensión resalta la sección ella sola."
                )
            else:
                agenda_rows = conv.agenda(slide)
                agenda_title = conv.escape(conv.text(slide.find("h2")[0]))
        elif kind == "divider":
            number = next(
                (int(conv.text(p)) for p in slide.find("p") if conv.text(p).isdigit()),
                len(dividers) + 1,
            )
            heading = slide.find("h2")
            dividers[number] = conv.escape(conv.text(heading[0])) if heading else ""
            pending = number
        elif kind == "content":
            info = conv.content(slide)
            for number, name, _ in info["menu"]:  # type: ignore[union-attr]
                names.setdefault(number, name)
            contents.append((info, pending))
            pending = None
        else:
            conv.warnings.append("Una diapositiva en blanco o sin título no se convierte.")

    trackers = Counter(str(info["tracker"]) for info, _ in contents)
    tracker = trackers.most_common(1)[0][0] if trackers else "side"
    foot = next((conv.footer(info["footer"]) for info, _ in contents if "footer" in info), {})  # type: ignore[arg-type]
    draft = next((str(info["draft"]) for info, _ in contents if "draft" in info), "")
    for number, (name, _) in agenda_rows.items():
        names.setdefault(number, name)
    for number, title in dividers.items():
        if number in names and title and title != names[number]:
            conv.warnings.append(
                f"Sección {number}: el separador dice «{title}» y el menú «{names[number]}». Se usa el del menú."
            )
        names.setdefault(number, title)

    out = _yaml(cover, close, foot, tracker, draft, conv.warnings)
    if not cover:
        conv.warnings.append("El mazo no tiene portada: revisa el título y los autores del .qmd.")
    if agenda_rows:
        out += ["", f"## {agenda_title or 'Índice'}", "", "::: {.agenda}", ":::"]

    def open_section(number: int) -> None:
        attrs = [] if number in dividers else [".sin-separador"]
        description = agenda_rows.get(number, ("", ""))[1]
        if description:
            attrs.append(f"descripcion={_quote(description)}")
        out.extend(
            [
                "",
                f"# {names.get(number, f'Sección {number}')}"
                + (f" {{{' '.join(attrs)}}}" if attrs else ""),
            ]
        )

    current = 0
    subsection: str | None = None
    listed: dict[int, set[str]] = {}
    used: dict[int, set[str]] = {}
    for info, divider in contents:
        active = [number for number, _, is_current in info["menu"] if is_current]  # type: ignore[union-attr]
        target = active[0] if active else divider if divider is not None else current
        if target < current:
            conv.warnings.append(
                f"«{info.get('title', '')}» vuelve a la sección {target}: se deja en la sección {current}."
            )
            target = current
        while current < target:
            current += 1
            subsection = None
            open_section(current)
        title = str(info.get("title", "")) or "Sin título"
        subs = sorted(info["subs"])  # type: ignore[call-overload]
        if current:
            listed.setdefault(current, set()).update(name for _, name, _ in subs)
        now = next((name for _, name, is_current in subs if is_current), None)
        attr = (
            ""
            if info["tracker"] == tracker
            else f' {{data-tracker="{_TRACKERS[str(info["tracker"])]}"}}'
        )
        if now and current:
            used.setdefault(current, set()).add(now)
            if now != subsection:
                subsection = now
                if now == title:
                    out += ["", f"## {title}{attr}"]
                else:
                    out += ["", f"## {now}", "", f"### {title}{attr}"]
            else:
                out += ["", f"### {title}{attr}"]
        else:
            subsection = None
            out += ["", f"## {title}{attr}"]
        body = conv.body(info["body"])  # type: ignore[arg-type]
        if body:
            out += ["", *body]
        for key, css in (("message", "mensaje"), ("source", "fuente")):
            if info.get(key):
                out += ["", f"::: {{.{css}}}", str(info[key]), ":::"]
        if info["notes"]:
            out += ["", "::: {.notes}", *info["notes"], ":::"]  # type: ignore[list-item]
    for number in sorted(names):
        if number > current:
            current = number
            open_section(number)
    for number in sorted(listed):
        missing = sorted(listed[number] - used.get(number, set()))
        if missing:
            conv.warnings.append(
                f"Sección {number}: el menú nombra subsecciones sin diapositivas ({', '.join(missing)}). No aparecen en el .qmd."
            )
    if close.get("message"):
        out += ["", f"## {close['message']} {{.conclusion}}"]
    else:
        conv.warnings.append(
            "El mazo no tiene cierre: añade un «## Mensaje {.conclusion}» al final."
        )
    warnings = [warning.replace("\\", "") for warning in conv.warnings]
    return Result("\n".join(out) + "\n", warnings, conv.figures)


def main(argv: Sequence[str] | None = None) -> int:
    """Run the converter from the command line.

    Parameters
    ----------
    argv : sequence of str, optional
        ``CARPETA [-o SALIDA.qmd] [--figuras DIR] [--quitar-corchetes]``.

    Returns
    -------
    int
        Exit status: 0 when the document was written.
    """
    parser = argparse.ArgumentParser(
        description="Convierte un mazo de Claude Slides en un .qmd de rogle-slides."
    )
    parser.add_argument(
        "carpeta",
        type=Path,
        help="carpeta que guarda la lectura del mazo (contiene project/deck.json)",
    )
    parser.add_argument(
        "-o", "--salida", type=Path, default=Path("presentacion.qmd"), help="archivo .qmd de salida"
    )
    parser.add_argument(
        "--figuras", type=Path, help="carpeta de las figuras (por defecto, «figuras» junto al .qmd)"
    )
    parser.add_argument(
        "--quitar-corchetes",
        action="store_true",
        help="quita los corchetes de los textos de ejemplo",
    )
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    figures = args.figuras or args.salida.parent / "figuras"
    try:
        reference = figures.resolve().relative_to(args.salida.parent.resolve()).as_posix()
    except ValueError:
        reference = figures.as_posix()
    try:
        result = convert(args.carpeta, figures, reference, args.quitar_corchetes)
    except FileNotFoundError as error:
        parser.error(str(error))
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    args.salida.write_text(result.qmd, encoding="utf-8")
    print(f"Escrito {args.salida}")
    for warning in result.warnings:
        print(f"aviso: {warning}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
