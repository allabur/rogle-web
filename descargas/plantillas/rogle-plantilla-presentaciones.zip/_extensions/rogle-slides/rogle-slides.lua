-- ROGLE presentations: Pandoc/Quarto Lua filter for Reveal.js and Beamer.
--
-- The design is the PowerPoint template of plantillas/office/ (build_template.py). The Beamer side is
-- the standalone theme resources/beamer/beamerthemeROGLE.sty (a copy of brand/latex/beamer/): this
-- filter loads it and turns the Markdown into its commands. The Reveal.js side is rogle20-reveal.scss
-- and rogle20-reveal.html: this filter hands the script the same data as a JSON object.
--
-- YAML options read from the document:
--   tracker:   lateral | superior | inferior | pasos | ninguno   (default lateral)
--   portada:   docencia | investigacion   (default docencia) cover and closing slide
--   borrador:  short label on the source line, e.g. "Datos ilustrativos" (optional)
--   author, affiliations: the Quarto schema (name, orcid, email, corresponding, affiliations by ref)
--   rogle:     etiqueta, enlace, titulo-corto, copyright, licencia, identificador, logos, cita,
--              licencia-texto, adaptacion, financiacion, pregunta, qr (picture; else drawn from enlace), web
-- Markup (the same in both formats). The title of a slide is a heading of the document:
--   # Section {descripcion="..."}   section: divider slide, entry in the tracker and row of the agenda
--   # Section {.sin-separador}      section without divider slide
--   ## Subsection                   entry under its section in the side menu. It is a slide only when it
--                                   has content of its own before the first ###; then its title is its text
--   ### Slide                       a slide whose title is that heading (one line)
--   ### Title {data-tracker="superior"}   tracker of that slide only (also on ##)
--   ## Key message {.conclusion}    closing slide
--   ::: {.mensaje}, {.fuente}, {.agenda}, {.formula}   ({.etiqueta} no longer does anything)
--   ::: {.bloques} > {.bloque}, ::: {.comparacion} > {.opcion}, ::: {.cierre} > {.pasos} + {.decision}
--
-- Both themes name files of resources/. The filter writes the path of that folder: relative to the
-- document in HTML, absolute in LaTeX. So the format works wherever Quarto installed the extension.

local TRACKERS = { lateral = 'side', superior = 'top', inferior = 'bottom', pasos = 'steps', ninguno = 'none' }
local KINDS = { docencia = 'teaching', investigacion = 'research' }
local LEGACY_PORTADA = { positiva = true, negativa = true }
local BUNDLED_LOGOS = { etsii = true, gva = true, ue = true }
local LICENCE = 'CC BY-NC-SA 4.0'
local LICENCE_NAME = 'Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional'
local LICENCE_URL = 'https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es'
local GROUP_URL = 'https://rogle.webs.upv.es/'

local function warn(message) io.stderr:write('rogle-slides: ' .. message .. '\n') end

local function text_of(value)
  if value == nil then return nil end
  local text = pandoc.utils.stringify(value)
  if text == '' then return nil end
  return text
end

local function has_class(el, name)
  for _, c in ipairs(el.classes) do
    if c == name then return true end
  end
  return false
end

-- A level-2 heading that makes the closing slide: it is not a subsection.
local function is_closing(b) return has_class(b, 'conclusion') or has_class(b, 'contraportada') end

-- Structure of the document. Returns the sections, each with the titles of its subsections (`subs`),
-- and for every top-level heading a note { section, sub, slide }: the section and subsection it
-- belongs to and whether it makes a slide. A `##` makes no slide when a `###` follows it at once
-- (it only names a subsection); a `##` with content of its own does, titled with its text.
-- A `##` before any `#` is a slide but not a subsection. Deeper headings are content.
local function outline(blocks)
  local sections, notes = {}, {}
  local section, sub = 0, 0
  for i, b in ipairs(blocks) do
    if b.t == 'Header' and b.level == 1 then
      section = section + 1
      sub = 0
      sections[section] = {
        title = b.content,
        description = b.attributes.descripcion or b.attributes['data-descripcion'] or '',
        subs = {},
      }
      notes[i] = { section = section, sub = 0, slide = not has_class(b, 'sin-separador') }
    elseif b.t == 'Header' and b.level == 2 then
      if is_closing(b) then
        notes[i] = { section = section, sub = 0, slide = true }
      else
        local following = blocks[i + 1]
        local names_only = following ~= nil and following.t == 'Header' and following.level == 3
        if section > 0 then
          sub = sub + 1
          sections[section].subs[sub] = b.content
        end
        notes[i] = { section = section, sub = sub, slide = not names_only }
      end
    elseif b.t == 'Header' and b.level == 3 then
      notes[i] = { section = section, sub = sub, slide = true }
    end
  end
  return sections, notes
end

-- A metadata value (string, inlines or blocks) as inlines; nil when it is empty.
local function inlines_of(value)
  if value == nil then return nil end
  local kind = pandoc.utils.type(value)
  if kind == 'Inlines' then return value end
  if kind == 'Blocks' then return pandoc.utils.blocks_to_inlines(value) end
  local text = pandoc.utils.stringify(value)
  if text == '' then return nil end
  return pandoc.Inlines({ pandoc.Str(text) })
end

local function plain(text) return pandoc.Inlines({ pandoc.Str(text) }) end

local function write_inlines(inlines, format)
  if inlines == nil then return '' end
  local out = pandoc.write(pandoc.Pandoc({ pandoc.Plain(inlines) }), format)
  return (out:gsub('%s+$', ''))
end

local function latex_inlines(inlines) return write_inlines(inlines, 'latex') end
local function html_inlines(inlines) return write_inlines(inlines, 'html') end

local function raw(s) return pandoc.RawBlock('latex', s) end

local function join_names(names)
  if #names == 0 then return '' end
  if #names == 1 then return names[1] end
  return table.concat(names, ', ', 1, #names - 1) .. ' y ' .. names[#names]
end

local function join_text(parts)
  local out = {}
  for _, part in ipairs(parts) do
    if part ~= nil and part ~= '' then out[#out + 1] = part end
  end
  return table.concat(out, ', ')
end

-- Text of a file of this extension, with {{ROGLE}} replaced by `dir` (the resources/ path).
local function theme_file(name, dir)
  local file = assert(io.open(quarto.utils.resolve_path(name), 'r'))
  local text = file:read('a')
  file:close()
  return (text:gsub('{{ROGLE}}', function() return dir end))
end

-- resources/ as an HTML URL: Pandoc reads it when embed-resources writes the images and fonts into the HTML.
-- The URL is relative to the document. In a website project Quarto takes an absolute path (/Users/...)
-- for a path from the site root and rewrites it with "..", so Pandoc cannot fetch it.
local function resources_url()
  local dir = quarto.utils.resolve_path('resources')
  local base = pandoc.path.directory(quarto.doc.input_file)
  local url = pandoc.path.make_relative(dir, base, true) .. '/'
  return (url:gsub('[ %%#?"]', function(c) return string.format('%%%02X', c:byte()) end))
end

-- A folder of resources/ as raw LaTeX. Pandoc would escape a plain string (`_` -> `\_`, `~` -> `\textasciitilde{}`),
-- so the path goes inside \detokenize. TeX reads `#`, `%` and braces before \detokenize sees them,
-- so those go out as the expl3 string constants. The same function is in rogle-lab.lua.
local STR_CONSTANTS = {
  ['#'] = 'c_hash_str',
  ['%'] = 'c_percent_str',
  ['{'] = 'c_left_brace_str',
  ['}'] = 'c_right_brace_str',
}

local function resources_latex(folder)
  local dir = quarto.utils.resolve_path('resources') .. '/' .. folder .. '/'
  local body = dir:gsub('[#%%{}]', function(c)
    return '}\\csname ' .. STR_CONSTANTS[c] .. '\\endcsname\\detokenize{'
  end)
  return '\\detokenize{' .. body .. '}'
end

local function add_header_include(doc, block)
  local includes = doc.meta['header-includes'] or pandoc.MetaList({})
  if includes.t ~= 'MetaList' then includes = pandoc.MetaList({ includes }) end
  includes[#includes + 1] = pandoc.MetaBlocks({ block })
  doc.meta['header-includes'] = includes
end

-- --------------------------------------------------------------------- data
-- Authors and affiliations from the Quarto schema. Affiliations are numbered in order of first use.
local function people(meta)
  local by_id = {}
  for _, aff in ipairs(meta.affiliations or {}) do
    local id = text_of(aff.id)
    if id then by_id[id] = aff end
  end
  local numbers, used, authors, contact = {}, {}, {}, nil
  for _, author in ipairs(meta.authors or {}) do
    local marks = {}
    for _, item in ipairs(author.affiliations or {}) do
      local aff = by_id[text_of(item.ref) or '']
      -- An affiliation written as a bare name that is the id of another one is a reference to it.
      local alias = aff and by_id[text_of(aff.name) or '']
      if alias and text_of(aff.department) == nil then aff = alias end
      if aff then
        local id = text_of(aff.id)
        if numbers[id] == nil then
          used[#used + 1] = aff
          numbers[id] = #used
        end
        marks[#marks + 1] = tostring(numbers[id])
      end
    end
    local corresponding = author.attributes and text_of(author.attributes.corresponding) == 'true'
    local name = author.name and (author.name.literal or author.name) or author
    authors[#authors + 1] = {
      name = inlines_of(name) or plain(''),
      marks = table.concat(marks, ',') .. (corresponding and '*' or ''),
      orcid = text_of(author.orcid) or '',
    }
    if corresponding and text_of(author.email) then
      contact = '*Autor de correspondencia: ' .. text_of(author.email)
    end
  end
  if #authors == 0 and meta.author then
    for _, name in ipairs(meta.author) do
      authors[#authors + 1] = { name = inlines_of(name) or plain(''), marks = '', orcid = '' }
    end
  end
  local affiliations = {}
  for number, aff in ipairs(used) do
    local first = join_text({ text_of(aff.department), text_of(aff.name) })
    local place = join_text({ text_of(aff['postal-code']), text_of(aff.city) }):gsub(', ', ' ')
    local second = join_text({ text_of(aff.address), place, text_of(aff.region), text_of(aff.country) })
    if second ~= '' then first = first .. ',' end
    affiliations[#affiliations + 1] = { mark = tostring(number), first = first, second = second }
  end
  return authors, affiliations, contact
end

local function list_of(value)
  local out = {}
  if value == nil then return out end
  if pandoc.utils.type(value) == 'List' then
    for _, item in ipairs(value) do out[#out + 1] = pandoc.utils.stringify(item) end
  else
    out[1] = pandoc.utils.stringify(value)
  end
  return out
end

-- Everything the cover, the footer and the closing slide show.
local function collect(doc)
  local meta = doc.meta
  local rogle = meta.rogle or {}
  if pandoc.utils.type(rogle) ~= 'table' then rogle = {} end
  local data = {}

  local portada = text_of(meta.portada) or 'docencia'
  if LEGACY_PORTADA[portada] then
    warn('portada: ' .. portada .. ' no longer exists; using docencia (values: docencia, investigacion)')
    portada = 'docencia'
  elseif not KINDS[portada] then
    warn('unknown portada "' .. portada .. '", using docencia')
    portada = 'docencia'
  end
  data.kind = KINDS[portada]
  data.tracker = text_of(meta.tracker) or 'lateral'
  if not TRACKERS[data.tracker] then
    warn('unknown tracker "' .. data.tracker .. '", using lateral')
    data.tracker = 'lateral'
  end
  data.draft = inlines_of(meta.borrador)

  data.authors, data.affiliations, data.contact = people(meta)
  local names = {}
  for _, author in ipairs(data.authors) do names[#names + 1] = pandoc.utils.stringify(author.name) end
  local year = (text_of(meta.date) or ''):match('%d%d%d%d') or os.date('%Y')
  local link = text_of(rogle.enlace)

  data.label = inlines_of(rogle.etiqueta)
  data.link = link
  data.short = inlines_of(rogle['titulo-corto'])
  data.copyright = inlines_of(rogle.copyright) or plain('© ' .. year .. ' ' .. join_names(names))
  data.licence = inlines_of(rogle.licencia) or plain(LICENCE)
  data.identifier = text_of(rogle.identificador) or (link and link:gsub('^https?://', '')) or nil
  data.logos = list_of(rogle.logos)
  data.web = text_of(rogle.web) or GROUP_URL
  data.cite = inlines_of(rogle.cita)
  if data.cite == nil then
    data.cite = pandoc.Inlines({ pandoc.Str(join_names(names) .. ' (' .. year .. '). ') })
    data.cite:insert(pandoc.Emph(inlines_of(meta.title) or plain('')))
    data.cite:insert(pandoc.Str('.' .. (link and (' ' .. link) or '')))
  end
  data.licence_text = inlines_of(rogle['licencia-texto']) or plain('© ' .. year .. ' ' .. join_names(names) ..
    '. Esta obra está bajo una licencia ' .. LICENCE_NAME .. ': ' .. LICENCE_URL)
  data.adaptation = inlines_of(rogle.adaptacion)
  data.funding = inlines_of(rogle.financiacion)
  data.ask = inlines_of(rogle.pregunta)
  data.qr = text_of(rogle.qr)
  data.close_kind = data.adaptation and 'adapted' or data.kind

  -- Sections and subsections, and the texts that a legacy back cover (.contraportada) gives to the closing slide.
  data.sections, data.notes = outline(doc.blocks)
  local in_back = false
  for _, b in ipairs(doc.blocks) do
    if b.t == 'Header' and b.level <= 2 then
      in_back = is_closing(b)
    elseif b.t == 'Div' and in_back then
      if has_class(b, 'gracias') then data.ask = pandoc.utils.blocks_to_inlines(b.content) end
      if has_class(b, 'contacto') then data.contact_lines = pandoc.utils.blocks_to_inlines(b.content) end
    end
  end
  return data
end

-- Logo of the right block: a bundled name (etsii, gva, ue) or a file of the author.
local function logo_url(name, variant, base)
  if BUNDLED_LOGOS[name] then return base .. 'beamer/logos/' .. name .. '-' .. variant .. '.png' end
  return name
end

-- ----------------------------------------------------------------- Reveal.js
local function reveal(doc, data)
  local base = resources_url()
  local sections = {}
  for i, section in ipairs(data.sections) do
    sections[i] = { t = html_inlines(section.title), d = section.description }
    if #section.subs > 0 then
      sections[i].s = {}
      for k, title in ipairs(section.subs) do sections[i].s[k] = html_inlines(title) end
    end
  end
  -- Every slide heading gets its section and subsection numbers (data-sec, data-sub), because Reveal.js
  -- removes hidden slides from the DOM in print mode (?print-pdf). A section without divider leaves no
  -- slide: it only counts. A subsection heading that only names a subsection leaves no slide either.
  -- A ### is a slide like a ##, so it becomes level 2, the slide level of Quarto.
  local blocks = {}
  for i, b in ipairs(doc.blocks) do
    local keep = true
    local note = data.notes[i]
    if b.t == 'Header' and note then
      if b.level == 1 then
        if has_class(b, 'sin-separador') then
          keep = false
        else
          b.attributes['data-background-color'] = '#002147'
        end
      elseif not note.slide then
        keep = false
      end
      if keep then
        b.attributes['data-sec'] = tostring(note.section)
        b.attributes['data-sub'] = tostring(note.sub)
        if b.level == 3 then b.level = 2 end
        if b.level == 2 and has_class(b, 'contraportada') then
          warn('{.contraportada} no longer exists; drawing the closing slide ({.conclusion})')
          b.classes:insert('conclusion')
        end
        if has_class(b, 'conclusion') then b.attributes['data-background-color'] = '#002147' end
      end
    end
    if keep then blocks[#blocks + 1] = b end
  end
  -- Pandoc turns a div that holds a heading into a <section>, which Reveal.js would take for a slide.
  -- Inside layout blocks the level-3 headings become plain divs with class rg-h3.
  doc = pandoc.Pandoc(blocks, doc.meta)
  doc = doc:walk({
    Div = function(div)
      if has_class(div, 'bloque') or has_class(div, 'opcion') or has_class(div, 'decision') then
        local content = {}
        for _, b in ipairs(div.content) do
          if b.t == 'Header' then
            content[#content + 1] = pandoc.Div({ pandoc.Plain(b.content) }, pandoc.Attr('', { 'rg-h3' }))
          else
            content[#content + 1] = b
          end
        end
        div.content = content
        return div
      end
    end,
  })

  local authors = {}
  for i, author in ipairs(data.authors) do
    authors[i] = { n = html_inlines(author.name), m = author.marks, o = author.orcid }
  end
  local affiliations = {}
  for i, aff in ipairs(data.affiliations) do
    affiliations[i] = { m = aff.mark, a = aff.first, b = aff.second }
  end
  local contact = nil
  if data.contact_lines then
    contact = { a = html_inlines(data.contact_lines), b = '' }
  elseif data.contact then
    contact = { a = data.contact, b = data.web }
  end
  local logos, images = {}, {}
  for i, name in ipairs(data.logos) do
    logos[i] = 'rg-logo-' .. i
    for _, variant in ipairs({ 'positivo', 'negativo' }) do
      images[#images + 1] = '<img id="rg-logo-' .. i .. '-' .. variant .. '" src="' ..
        logo_url(name, variant, base) .. '" alt="">'
    end
  end
  if data.qr then images[#images + 1] = '<img id="rg-qr" src="' .. data.qr .. '" alt="Código QR de la obra">' end

  local config = {
    tracker = data.tracker,
    borrador = html_inlines(data.draft),
    tipo = data.kind,
    cierre = data.close_kind,
    secciones = sections,
    etiqueta = html_inlines(data.label),
    enlace = data.link or '',
    autores = authors,
    afiliaciones = affiliations,
    contacto = contact,
    logos = logos,
    pie = {
      corto = html_inlines(data.short),
      copyright = html_inlines(data.copyright),
      licencia = html_inlines(data.licence),
      id = data.identifier or '',
    },
    cita = html_inlines(data.cite),
    licencia = html_inlines(data.close_kind == 'adapted' and data.adaptation or data.licence_text),
    financiacion = html_inlines(data.funding),
    pregunta = html_inlines(data.ask),
  }
  local json = quarto.json.encode(config):gsub('</', '<\\/')
  add_header_include(doc, pandoc.RawBlock('html', '<script>window.ROGLE = ' .. json .. ';</script>'))
  -- The QR encoder goes first: the theme script calls it for the closing slide.
  quarto.doc.include_text('after-body', '<script>\n' .. theme_file('rogle-qr.js', base) .. '</script>')
  local page = theme_file('rogle20-reveal.html', base)
  page = page:gsub('<!%-%- rg%-extra %-%->', function() return table.concat(images, '\n  ') end)
  quarto.doc.include_text('after-body', page)
  -- The cover is white with an Oxford Blue field that the script draws.
  doc.meta['title-slide-attributes'] = pandoc.MetaMap({ ['data-background-color'] = pandoc.MetaString('#FFFFFF') })
  return doc
end

-- ------------------------------------------------------------------- Beamer
local ENV = {
  mensaje = 'rogletakeaway',
  fuente = 'roglesource',
  formula = 'rogleformula',
}

-- The blocks of a child div, with its level-3 heading taken out as LaTeX.
local function split_heading(div)
  local heading, rest = '', {}
  for _, b in ipairs(div.content) do
    if b.t == 'Header' and heading == '' then
      heading = latex_inlines(b.content)
    else
      rest[#rest + 1] = b
    end
  end
  return heading, rest
end

-- A layout div whose children open with a command of the theme: summary and comparison.
local function columns_of(div, env, child_class, command)
  local out = { raw('\\begin{' .. env .. '}') }
  for _, child in ipairs(div.content) do
    if child.t == 'Div' and has_class(child, child_class) then
      local heading, rest = split_heading(child)
      out[#out + 1] = raw('\\' .. command .. '{' .. heading .. '}')
      for _, b in ipairs(rest) do out[#out + 1] = b end
    end
  end
  out[#out + 1] = raw('\\end{' .. env .. '}')
  return out
end

local function next_steps(div)
  local out = { raw('\\begin{roglenextsteps}') }
  for _, child in ipairs(div.content) do
    if child.t == 'Div' and has_class(child, 'decision') then
      local heading, rest = split_heading(child)
      out[#out + 1] = raw('\\rogledecision' .. (heading ~= '' and ('\\rogledecisionhead{' .. heading .. '}') or ''))
      for _, b in ipairs(rest) do out[#out + 1] = b end
    elseif child.t == 'Div' then
      for _, b in ipairs(child.content) do out[#out + 1] = b end
    end
  end
  out[#out + 1] = raw('\\end{roglenextsteps}')
  return out
end

local function beamer_div(section)
  return function(div)
    if has_class(div, 'columns') and not has_class(div, 'onlytextwidth') then
      div.classes:insert('onlytextwidth')
      return div
    end
    for class, env in pairs(ENV) do
      if has_class(div, class) then
        local out = { raw('\\begin{' .. env .. '}') }
        for _, b in ipairs(div.content) do out[#out + 1] = b end
        out[#out + 1] = raw('\\end{' .. env .. '}')
        return out
      end
    end
    -- The section label above the title no longer exists: .etiqueta is dropped.
    if has_class(div, 'etiqueta') then return {} end
    if has_class(div, 'agenda') then return raw('\\rogleagenda*[' .. section .. ']') end
    if has_class(div, 'bloques') then return columns_of(div, 'roglesummary', 'bloque', 'rogleblock') end
    if has_class(div, 'comparacion') then return columns_of(div, 'roglecompare', 'opcion', 'rogleoption') end
    if has_class(div, 'cierre') then return next_steps(div) end
    if has_class(div, 'gracias') or has_class(div, 'contacto') then return {} end
  end
end

local function map_cells(rows, wrap)
  local out = {}
  for _, row in ipairs(rows) do
    local cells = {}
    for _, cell in ipairs(row.cells) do
      local blocks = {}
      for _, block in ipairs(cell.contents) do
        if block.t == 'Plain' or block.t == 'Para' then
          blocks[#blocks + 1] = pandoc.Plain(wrap(block.content))
        else
          blocks[#blocks + 1] = block
        end
      end
      cells[#cells + 1] = pandoc.Cell(blocks, cell.alignment, cell.row_span, cell.col_span, cell.attr)
    end
    out[#out + 1] = pandoc.Row(cells, row.attr)
  end
  return out
end

-- Header cells in bold; tables with class "total" bold in the last row. Quarto reads the attributes
-- of a caption after this filter, so the class is also looked for in the text of the caption.
local function beamer_table(tbl)
  local total = has_class(tbl, 'total') or
    pandoc.utils.stringify(tbl.caption.long):match('{[^}]*%.total[^}]*}%s*$') ~= nil
  local head_rows = map_cells(tbl.head.rows, function(inlines)
    local out = { pandoc.RawInline('latex', '\\rogleth{') }
    for _, inline in ipairs(inlines) do out[#out + 1] = inline end
    out[#out + 1] = pandoc.RawInline('latex', '}')
    return out
  end)
  local bodies = {}
  for _, body in ipairs(tbl.bodies) do
    local rows = {}
    for i, row in ipairs(body.body) do rows[i] = row end
    if total and #rows > 0 then
      rows[#rows] = map_cells({ rows[#rows] }, function(inlines) return { pandoc.Strong(inlines) } end)[1]
    end
    bodies[#bodies + 1] = { attr = body.attr, row_head_columns = body.row_head_columns,
                            head = body.head, body = rows }
  end
  return pandoc.Table(tbl.caption, tbl.colspecs, pandoc.TableHead(head_rows, tbl.head.attr),
                      bodies, tbl.foot, tbl.attr)
end

-- The preamble: where the theme is, and the data of the document as commands of the theme.
local function beamer_preamble(data, first)
  local function command(name, inlines)
    if inlines == nil then return nil end
    return '\\' .. name .. '{' .. latex_inlines(inlines) .. '}'
  end
  local lines = {
    '\\def\\roglepath{' .. resources_latex('beamer') .. '}',
    '\\makeatletter\\edef\\rogle@dir{\\roglepath}' ..
      '\\ifdefined\\input@path\\edef\\input@path{{\\rogle@dir}\\input@path}\\else\\edef\\input@path{{\\rogle@dir}}\\fi\\makeatother',
    '\\usetheme[tracker=' .. first.mode .. ']{ROGLE}',
    '\\roglesection{' .. first.section .. '}',
    '\\roglesubsection{' .. first.sub .. '}',
    '\\roglekind{' .. data.close_kind .. '}',
  }
  local function add(line) if line then lines[#lines + 1] = line end end
  add(command('roglelabel', data.label))
  add(data.link and ('\\roglelink{' .. data.link .. '}'))
  add(command('rogleshorttitle', data.short))
  add(command('roglecopyright', data.copyright))
  add(command('roglelicence', data.licence))
  add(data.identifier and command('rogleidentifier', plain(data.identifier)))
  add(command('rogledraft', data.draft))
  add(command('roglecite', data.cite))
  add(command('roglelicencetext', data.licence_text))
  add(command('rogleadaptation', data.adaptation))
  add(command('roglefunding', data.funding))
  add(command('rogleask', data.ask))
  add(data.qr and ('\\rogleqr{' .. data.qr .. '}'))
  if #data.logos > 0 then
    local list = table.concat(data.logos, ',')
    add('\\rogleschoollogos{' .. list .. '}')
    add('\\roglefunderlogos{' .. list .. '}')
  end
  for _, author in ipairs(data.authors) do
    add('\\rogleauthor[' .. author.orcid .. ']{' .. latex_inlines(author.name) .. '}{' .. author.marks .. '}')
  end
  for _, aff in ipairs(data.affiliations) do
    add('\\rogleaffiliation{' .. aff.mark .. '}{' .. latex_inlines(plain(aff.first)) .. '}{' ..
      latex_inlines(plain(aff.second)) .. '}')
  end
  if data.contact_lines then
    add('\\roglecontact{' .. latex_inlines(data.contact_lines) .. '}{}')
  elseif data.contact then
    add('\\roglecontact{' .. latex_inlines(plain(data.contact)) .. '}{\\url{' .. data.web .. '}}')
  end
  for i, section in ipairs(data.sections) do
    add('\\rogledefsection{' .. i .. '}{' .. latex_inlines(section.title) .. '}[{' ..
      latex_inlines(plain(section.description)) .. '}]')
    for _, title in ipairs(section.subs) do
      add('\\rogledefsubsection{' .. i .. '}{' .. latex_inlines(title) .. '}')
    end
  end
  return table.concat(lines, '\n')
end

local function beamer(doc, data)
  -- Slides: every ### and every ## that makes a slide (see outline), and every level-1 heading with a
  -- divider. Pandoc cuts frames at level 2, so each slide heading goes out as level 2. Beamer typesets
  -- the body of a frame before its background, so the tracker, the section and the subsection of a
  -- slide cannot be set inside it: each slide ends with \roglenext, which sets them for the next one.
  -- The first slide takes them from the preamble.
  local slides = {}
  for i, b in ipairs(doc.blocks) do
    if b.t == 'Header' and b.level <= 3 then
      local note = data.notes[i]
      if b.level == 1 then
        if note.slide then
          slides[#slides + 1] = {
            header = pandoc.Header(2, {}, pandoc.Attr(b.identifier, { 'plain' })),
            blocks = { raw('\\rogledivider*{' .. note.section .. '}{' .. latex_inlines(b.content) .. '}') },
            mode = data.tracker, section = note.section, sub = 0,
          }
        end
      elseif note.slide then
        local mode = b.attributes['data-tracker'] or b.attributes['tracker']
        if mode == nil or not TRACKERS[mode] then mode = data.tracker end
        local slide = { header = pandoc.Header(2, b.content, b.attr), blocks = {}, mode = mode,
                        section = note.section, sub = note.sub }
        if is_closing(b) then
          if has_class(b, 'contraportada') then
            warn('{.contraportada} no longer exists; drawing the closing slide ({.conclusion})')
          end
          slide.blocks[1] = raw('\\rogleclosing*{' .. latex_inlines(b.content) .. '}')
          slide.header = pandoc.Header(2, {}, pandoc.Attr(b.identifier, { 'plain' }))
        end
        slides[#slides + 1] = slide
      end
    elseif #slides > 0 then
      local slide = slides[#slides]
      slide.blocks[#slide.blocks + 1] = b
    end
  end

  local out = {}
  for i, slide in ipairs(slides) do
    out[#out + 1] = slide.header
    local body = pandoc.Blocks(slide.blocks):walk({ Div = beamer_div(slide.section), Table = beamer_table })
    for _, b in ipairs(body) do out[#out + 1] = b end
    local following = slides[i + 1]
    if following then
      out[#out + 1] = raw('\\roglenext{' .. TRACKERS[following.mode] .. '}{' .. following.section .. '}[' ..
        following.sub .. ']')
    end
  end
  local first = slides[1] or { mode = data.tracker, section = 0, sub = 0 }
  add_header_include(doc, raw(beamer_preamble(data, { mode = TRACKERS[first.mode], section = first.section,
                                                      sub = first.sub })))
  doc.blocks = out
  return doc
end

-- A figure and its percent sign stay on one line in Reveal.js: the space between them becomes a
-- no-break space. Beamer needs nothing: babel-spanish already sets "18 %" with a fixed thin space.
local function percent_spaces(inlines)
  for i = 2, #inlines - 1 do
    local before, after = inlines[i - 1], inlines[i + 1]
    if inlines[i].t == 'Space' and before.t == 'Str' and after.t == 'Str'
        and before.text:match('%d$') and after.text:match('^%%') then
      inlines[i] = pandoc.Str('\u{a0}')
    end
  end
  return inlines
end

-- ---------------------------------------------------------------------- main
function Pandoc(doc)
  local data = collect(doc)
  if FORMAT:match('revealjs') then return reveal(doc:walk({ Inlines = percent_spaces }), data) end
  if FORMAT:match('beamer') then return beamer(doc, data) end
end
