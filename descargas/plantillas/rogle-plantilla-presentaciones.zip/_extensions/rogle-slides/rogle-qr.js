// QR code of a link, for the closing slide of the Reveal.js format (the Beamer theme uses the LaTeX
// package qrcode). Byte mode, error correction level M, versions 1 to 10: up to 213 bytes of UTF-8.
// rogleQR(text) returns the modules as an array of rows of booleans (true is dark), or null when the
// text is empty or too long. rogle-slides.lua writes this file into the page before the theme script.
(function (root) {
  "use strict";
  // Per version (index 0 is version 1): total codewords, error-correction codewords per block,
  // number of blocks and centres of the alignment patterns. Level M of ISO/IEC 18004.
  var TOTAL = [26, 44, 70, 100, 134, 172, 196, 242, 292, 346];
  var EC_PER_BLOCK = [10, 16, 26, 18, 24, 16, 18, 22, 22, 26];
  var BLOCKS = [1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
  var ALIGN = [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];

  function utf8(text) {
    var out = [];
    var encoded = unescape(encodeURIComponent(text));
    for (var i = 0; i < encoded.length; i += 1) { out.push(encoded.charCodeAt(i)); }
    return out;
  }

  // Reed-Solomon over GF(256) with the polynomial x^8 + x^4 + x^3 + x^2 + 1.
  function multiply(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i -= 1) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    return z;
  }
  function divisor(degree) {
    var result = [];
    for (var i = 0; i < degree - 1; i += 1) { result.push(0); }
    result.push(1);
    var rootOfUnity = 1;
    for (var k = 0; k < degree; k += 1) {
      for (var j = 0; j < result.length; j += 1) {
        result[j] = multiply(result[j], rootOfUnity);
        if (j + 1 < result.length) { result[j] ^= result[j + 1]; }
      }
      rootOfUnity = multiply(rootOfUnity, 2);
    }
    return result;
  }
  function remainder(data, div) {
    var result = div.map(function () { return 0; });
    data.forEach(function (byte) {
      var factor = byte ^ result.shift();
      result.push(0);
      div.forEach(function (coefficient, i) { result[i] ^= multiply(coefficient, factor); });
    });
    return result;
  }

  // The data codewords: mode, length, bytes, terminator and padding.
  function codewords(bytes, version) {
    var capacity = TOTAL[version - 1] - EC_PER_BLOCK[version - 1] * BLOCKS[version - 1];
    var bits = [];
    function push(value, length) {
      for (var i = length - 1; i >= 0; i -= 1) { bits.push((value >>> i) & 1); }
    }
    push(4, 4);
    push(bytes.length, version < 10 ? 8 : 16);
    bytes.forEach(function (byte) { push(byte, 8); });
    push(0, Math.min(4, capacity * 8 - bits.length));
    push(0, (8 - bits.length % 8) % 8);
    for (var pad = 0xEC; bits.length < capacity * 8; pad ^= 0xEC ^ 0x11) { push(pad, 8); }
    var out = [];
    for (var k = 0; k < bits.length; k += 8) {
      var byte = 0;
      for (var j = 0; j < 8; j += 1) { byte = (byte << 1) | bits[k + j]; }
      out.push(byte);
    }
    return out;
  }

  // Split into blocks (the long ones last), add the error correction and interleave.
  function interleave(data, version) {
    var count = BLOCKS[version - 1];
    var ecLength = EC_PER_BLOCK[version - 1];
    var shortLength = Math.floor(data.length / count);
    var longBlocks = data.length % count;
    var div = divisor(ecLength);
    var blocks = [];
    var position = 0;
    for (var i = 0; i < count; i += 1) {
      var length = shortLength + (i >= count - longBlocks ? 1 : 0);
      var block = data.slice(position, position + length);
      position += length;
      blocks.push({ data: block, ec: remainder(block, div) });
    }
    var out = [];
    for (var k = 0; k <= shortLength; k += 1) {
      blocks.forEach(function (block) { if (k < block.data.length) { out.push(block.data[k]); } });
    }
    for (var e = 0; e < ecLength; e += 1) {
      blocks.forEach(function (block) { out.push(block.ec[e]); });
    }
    return out;
  }

  var MASKS = [
    function (x, y) { return (x + y) % 2 === 0; },
    function (x, y) { return y % 2 === 0; },
    function (x, y) { return x % 3 === 0; },
    function (x, y) { return (x + y) % 3 === 0; },
    function (x, y) { return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; },
    function (x, y) { return x * y % 2 + x * y % 3 === 0; },
    function (x, y) { return (x * y % 2 + x * y % 3) % 2 === 0; },
    function (x, y) { return ((x + y) % 2 + x * y % 3) % 2 === 0; }
  ];

  function build(stream, version, mask) {
    var size = 17 + 4 * version;
    var modules = [];
    var fixed = [];
    for (var r = 0; r < size; r += 1) {
      modules.push(new Array(size).fill(false));
      fixed.push(new Array(size).fill(false));
    }
    function set(x, y, dark) {
      if (x >= 0 && x < size && y >= 0 && y < size) {
        modules[y][x] = Boolean(dark);
        fixed[y][x] = true;
      }
    }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy += 1) {
        for (var dx = -4; dx <= 4; dx += 1) {
          var distance = Math.max(Math.abs(dx), Math.abs(dy));
          set(cx + dx, cy + dy, distance !== 2 && distance !== 4);
        }
      }
    }
    function format() {
      var data = mask; // level M is 00
      var rem = data;
      for (var i = 0; i < 10; i += 1) { rem = (rem << 1) ^ ((rem >>> 9) * 0x537); }
      var bits = ((data << 10) | rem) ^ 0x5412;
      function bit(k) { return (bits >>> k) & 1; }
      for (var a = 0; a <= 5; a += 1) { set(8, a, bit(a)); }
      set(8, 7, bit(6));
      set(8, 8, bit(7));
      set(7, 8, bit(8));
      for (var b = 9; b < 15; b += 1) { set(14 - b, 8, bit(b)); }
      for (var c = 0; c < 8; c += 1) { set(size - 1 - c, 8, bit(c)); }
      for (var d = 8; d < 15; d += 1) { set(8, size - 15 + d, bit(d)); }
      set(8, size - 8, true);
    }
    // Function patterns: timing, finders, alignment, format and version.
    for (var t = 0; t < size; t += 1) {
      set(6, t, t % 2 === 0);
      set(t, 6, t % 2 === 0);
    }
    finder(3, 3);
    finder(size - 4, 3);
    finder(3, size - 4);
    var centres = ALIGN[version - 1];
    centres.forEach(function (cy, i) {
      centres.forEach(function (cx, j) {
        var last = centres.length - 1;
        if ((i === 0 && j === 0) || (i === 0 && j === last) || (i === last && j === 0)) { return; }
        for (var dy = -2; dy <= 2; dy += 1) {
          for (var dx = -2; dx <= 2; dx += 1) {
            set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
          }
        }
      });
    });
    format();
    if (version >= 7) {
      var rem = version;
      for (var v = 0; v < 12; v += 1) { rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25); }
      var bits = (version << 12) | rem;
      for (var k = 0; k < 18; k += 1) {
        var a = size - 11 + k % 3;
        var b = Math.floor(k / 3);
        set(a, b, (bits >>> k) & 1);
        set(b, a, (bits >>> k) & 1);
      }
    }
    // Data in a zigzag of two-module columns from the right, then the mask.
    var index = 0;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) { right = 5; }
      for (var vert = 0; vert < size; vert += 1) {
        for (var j = 0; j < 2; j += 1) {
          var x = right - j;
          var upward = ((right + 1) & 2) === 0;
          var y = upward ? size - 1 - vert : vert;
          if (!fixed[y][x] && index < stream.length * 8) {
            modules[y][x] = ((stream[index >>> 3] >>> (7 - (index & 7))) & 1) === 1;
            index += 1;
          }
        }
      }
    }
    for (var my = 0; my < size; my += 1) {
      for (var mx = 0; mx < size; mx += 1) {
        if (!fixed[my][mx] && MASKS[mask](mx, my)) { modules[my][mx] = !modules[my][mx]; }
      }
    }
    return modules;
  }

  // Penalty of a masked symbol: runs, blocks, finder-like patterns and balance.
  function penalty(modules) {
    var size = modules.length;
    var score = 0;
    var dark = 0;
    function lines(get) {
      for (var a = 0; a < size; a += 1) {
        var run = 1;
        var row = "";
        for (var b = 0; b < size; b += 1) {
          row += get(a, b) ? "1" : "0";
          if (b > 0 && get(a, b) === get(a, b - 1)) {
            run += 1;
            if (run === 5) { score += 3; } else if (run > 5) { score += 1; }
          } else {
            run = 1;
          }
        }
        for (var p = 0; p + 11 <= size; p += 1) {
          var window = row.substr(p, 11);
          if (window === "10111010000" || window === "00001011101") { score += 40; }
        }
      }
    }
    lines(function (a, b) { return modules[a][b]; });
    lines(function (a, b) { return modules[b][a]; });
    for (var y = 0; y < size; y += 1) {
      for (var x = 0; x < size; x += 1) {
        if (modules[y][x]) { dark += 1; }
        if (x + 1 < size && y + 1 < size && modules[y][x] === modules[y][x + 1] &&
            modules[y][x] === modules[y + 1][x] && modules[y][x] === modules[y + 1][x + 1]) {
          score += 3;
        }
      }
    }
    return score + Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
  }

  root.rogleQR = function (text) {
    var bytes = utf8(text || "");
    if (!bytes.length) { return null; }
    for (var version = 1; version <= 10; version += 1) {
      var capacity = TOTAL[version - 1] - EC_PER_BLOCK[version - 1] * BLOCKS[version - 1];
      if (bytes.length + (version < 10 ? 2 : 3) > capacity) { continue; }
      var stream = interleave(codewords(bytes, version), version);
      var best = null;
      var bestScore = Infinity;
      for (var mask = 0; mask < 8; mask += 1) {
        var candidate = build(stream, version, mask);
        var score = penalty(candidate);
        if (score < bestScore) {
          best = candidate;
          bestScore = score;
        }
      }
      return best;
    }
    return null;
  };
})(typeof window !== "undefined" ? window : globalThis);
