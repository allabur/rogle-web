# Plantilla de presentaciones (estilo consultora)

Plantilla Quarto de diapositivas con la marca vigente de ROGLE. Un solo `template.qmd` se compila a Reveal.js (HTML) y a Beamer (PDF) con el mismo aspecto. El diseño está en la extensión `rogle-slides` (`_extensions/rogle-slides/`), con dos formatos: `rogle-slides-revealjs` y `rogle-slides-beamer`. Esta carpeta solo tiene el ejemplo. Issue [#27](https://github.com/allabur/rogle/issues/27).

Es el diseño de la plantilla de PowerPoint (`plantillas/office/ROGLE.potx`) y de los dos mazos maestros de Claude Slides, uno de docencia y otro de investigación. Fondo blanco, un título de una línea que es el encabezado del documento, un menú de seguimiento de las secciones con las subsecciones de la actual, un bloque con el mensaje clave, una línea de fuente y un pie con los iconos de Creative Commons, la cita corta y el número. La portada tiene un campo Oxford Blue sobre una franja blanca con los logotipos. Los separadores de sección y el cierre son Oxford Blue.

El formato Beamer carga el tema autónomo `beamerthemeROGLE.sty`. Ese tema también compila sin Quarto, desde un `.tex`: ver [`brand/latex/beamer/README.md`](../../brand/latex/beamer/README.md), que incluye la guía para pasar un mazo de Claude Slides a LaTeX.

## Usarla en otro proyecto

En una asignatura o cualquier proyecto Quarto. El repositorio es privado: `quarto add allabur/rogle` no funciona. Desde una copia local de este repositorio:

```bash
quarto add ~/Developer/rogle
```

Sin copia local, mira la alternativa con `gh` en el [README principal](../../README.md#plantillas).

La extensión lleva dentro los logotipos, las fuentes de respaldo y el tema Beamer. Funciona en cualquier carpeta del proyecto. La cabecera mínima de una presentación:

```yaml
---
title: "Título"
author:
  - name: Nombre Apellido
date: 2026-11-11
brand: false
tracker: superior
format:
  rogle-slides-revealjs: default
  rogle-slides-beamer: default
---
```

`brand: false` va siempre en el documento. Desactiva el motor de marca de Quarto, que escribe mal la ruta de las fuentes. Una extensión no puede desactivarlo.

## Cómo se renderiza

Desde esta carpeta:

```bash
quarto render template.qmd --to rogle-slides-revealjs
quarto render template.qmd --to rogle-slides-beamer
```

Sin `--to` se renderizan los dos. Reveal.js escribe `template.html`, un único archivo con estilos, imágenes y fuentes dentro. Beamer escribe `template.pdf` con LuaLaTeX.

Para probar otro menú sin tocar el archivo:

```bash
quarto render template.qmd --to rogle-slides-revealjs -M tracker:superior
quarto render template.qmd --to rogle-slides-beamer -M tracker:pasos
```

`-M` solo sirve para las opciones que el documento no fija en su cabecera.

**Beamer necesita LuaLaTeX.** Con pdfLaTeX no se puede usar Palatino del sistema, y Pandoc carga `unicode-math` solo con LuaLaTeX y XeLaTeX. La extensión fija el motor (`pdf-engine: lualatex`). No se admite pdfLaTeX.

## Ver y exportar Reveal.js

Abre `template.html` con doble clic en un navegador. Funciona sin servidor. También sirve `quarto preview template.qmd` o `python3 -m http.server 8000` y abrir `http://localhost:8000/template.html`.

Para el PDF, abre `template.html?print-pdf` en Chrome, imprime, elige «Guardar como PDF», márgenes «Ninguno» y activa «Gráficos de fondo». El menú, el pie y los números salen bien porque el script los escribe dentro de cada diapositiva. El PDF tiene una página por diapositiva.

Cómo se arregló la vista previa sin estilos: el HTML antiguo enlazaba hojas de estilo y logotipos con rutas relativas. Dentro de un proyecto Quarto, las rutas relativas de HTML escrito a mano se convierten en rutas absolutas del sitio (`/brand/...`), y los visores que muestran el HTML como una instantánea no resuelven ninguna ruta. Además, el motor de marca de Quarto escribía mal la ruta de las fuentes libres, que nunca se cargaban. Ahora `embed-resources: true` deja todo dentro del HTML y `brand: false` desactiva el motor de marca en el documento.

Dos límites que quedan, porque vienen de Reveal.js:

- Un visor que incrusta el HTML como `srcdoc` o `data:` no ejecuta Reveal.js: sus rutas de historial no funcionan y la pantalla queda en blanco. Abre el archivo en el navegador.
- Las fórmulas cargan MathJax 4 y la fuente `mathjax-pagella` desde jsDelivr. Sin red se ven las fórmulas sin tipografía de marca. El resto no necesita red.

## Opciones del YAML

| Opción | Valores | Por defecto | Qué hace |
|---|---|---|---|
| `tracker` | `lateral`, `superior`, `inferior`, `pasos`, `ninguno` | `lateral` | Menú de seguimiento de las secciones |
| `portada` | `docencia`, `investigacion` | `docencia` | Versión de la portada y del cierre |
| `borrador` | texto corto | vacío | Etiqueta pequeña a la derecha de la línea de fuente, por ejemplo «Datos ilustrativos» |
| `author`, `affiliations` | esquema de Quarto | vacío | Autores con ORCID y afiliaciones numeradas |
| `rogle` | bloque de datos | vacío | Datos de la portada, el pie y el cierre |

### Autores y afiliaciones

Usa el esquema de autores de Quarto. El filtro numera las afiliaciones en orden de aparición y marca con un asterisco al autor de correspondencia.

```yaml
author:
  - name: Nombre Apellido
    orcid: 0000-0000-0000-0000
    email: nombre.apellido@upv.es
    corresponding: true
    affiliations:
      - ref: rogle
affiliations:
  - id: rogle
    department: ROGLE, Departamento de Organización de Empresas
    name: Universitat Politècnica de València
    address: Camino de Vera s/n
    postal-code: 46022
    city: València
    country: España
```

La portada escribe cada afiliación en una línea. El cierre la escribe en dos: departamento e institución, y dirección. El correo del autor de correspondencia sale en la portada y en el cierre.

### El bloque `rogle`

Todas las claves son opcionales.

| Clave | Qué fija | Si falta |
|---|---|---|
| `etiqueta` | Etiqueta ámbar de la portada: asignatura y titulación con sus códigos, o congreso | No hay etiqueta |
| `enlace` | Enlace de la portada. El cierre dibuja su código QR | No hay enlace ni QR |
| `titulo-corto` | Título corto del pie, en cursiva | El pie empieza por el copyright |
| `copyright` | Copyright del pie | «© año» y los nombres de los autores |
| `licencia` | Licencia del pie | CC BY-NC-SA 4.0 |
| `identificador` | Identificador del pie y del pie del QR | El enlace sin `https://` |
| `logos` | Logotipos del bloque derecho de la portada y el cierre: `etsii`, `gva`, `ue` o la ruta de un archivo | No hay logotipos |
| `cita` | Cita del cierre («Cómo citar») | Autores, año, título y enlace |
| `licencia-texto` | Línea de copyright y licencia del cierre | La frase de CC BY-NC-SA 4.0 con los nombres de los autores |
| `adaptacion` | Frase de obra adaptada: sustituye a la línea de licencia | Cierre normal |
| `financiacion` | Apartado «Financiación» del cierre, con `portada: investigacion` | No hay apartado |
| `pregunta` | Pregunta del cierre | «Gracias. ¿Preguntas?» |
| `qr` | Imagen del código QR del cierre | Los dos formatos lo generan del enlace |
| `web` | Segunda línea del contacto | https://rogle.webs.upv.es/ |

## Estructura de una presentación

```markdown
# Sección {descripcion="Una línea para el índice"}   <- sección: separador + entrada en el menú
# Sección {.sin-separador}             <- sección sin separador (cuenta en el menú)

## Subsección                          <- entrada «3.1 Subsección» bajo su sección en el menú lateral
### Título de la diapositiva           <- diapositiva: su título es este encabezado

## Subsección con contenido propio     <- si tiene contenido antes del primer ###, también es una diapositiva

## Mensaje clave de la charla {.conclusion}   <- cierre
```

La portada sale de `title`, `subtitle`, `author`, `date` y el bloque `rogle`. El título de la diapositiva es el encabezado del documento: corto, de una línea, sin frase de conclusión. El título de la diapositiva `{.conclusion}` es el mensaje clave del cierre.

El filtro decide así qué es una diapositiva. Un `###` siempre lo es. Un `##` es una diapositiva solo si tiene contenido propio antes del primer `###`, o si no tiene ningún `###` debajo. Un `##` seguido de `###` solo da nombre a la subsección. Los documentos antiguos, con `#` y un `##` por diapositiva, compilan igual: cada `##` es una diapositiva y aparece como subsección en el menú.

Un título que no cabe en una línea no baja a la raya. Reveal.js y Beamer lo encogen de 26 pt hasta 20 pt y, si aún no cabe, lo cortan con puntos suspensivos.

Dentro de cada diapositiva se usan estos bloques:

| Bloque | Resultado |
|---|---|
| `::: {.mensaje}` | Bloque de mensaje clave, como una cita: fondo suave, barra índigo a la izquierda y texto en negrita |
| `::: {.fuente}` | Línea «Fuente: …» en Palatino pequeña |
| `::: {.etiqueta}` | Ya no hace nada: la etiqueta sobre el título se eliminó. Se acepta para no romper documentos antiguos |
| `::: {.agenda}` | Índice: número, nombre y descripción de cada sección, con la actual resaltada |
| `::: {.bloques}` con tres `::: {.bloque}` | Resumen ejecutivo: tres bloques numerados |
| `::: {.comparacion}` con tres `::: {.opcion}` | Comparación en tres columnas |
| `::: {.cierre}` con `.pasos` y `.decision` | Próximos pasos y decisión que se pide |
| `::: {.formula}` | Fórmula sobre fondo suave con barra índigo |
| `:::: {.columns}` | Dos columnas (sintaxis de Quarto) |
| `: Pie de tabla {.total}` | Tabla con la última fila en negrita |

Los títulos de nivel 3 (`###`) dentro de `.bloque`, `.opcion` y `.decision` son los encabezados de cada columna.

No hay etiqueta de sección sobre el título. El menú ya dice la sección. La diapositiva del índice no lleva menú.

`template.qmd` es un ejemplo de 13 diapositivas: la reorganización de rutas de reparto. Muestra portada, índice, resumen ejecutivo, contenido, texto y figura, fórmula, código, tabla, comparación, próximos pasos y cierre, con dos separadores. La sección «Análisis» tiene tres subsecciones, cada una con una diapositiva con título estructural. Los datos son ficticios.

## Qué cambia respecto a la versión anterior

El rediseño de noviembre de 2026 cambió algunas opciones. Los documentos antiguos compilan, pero cambian de aspecto.

| Antes | Ahora |
|---|---|
| `portada: positiva` o `negativa` | `portada: docencia` o `investigacion`. Los valores antiguos dan un aviso y se tratan como `docencia`. No hay portada negativa |
| `## {.contraportada}` | `## Mensaje clave {.conclusion}`. `{.contraportada}` da un aviso y dibuja el cierre nuevo, sin mensaje clave |
| `::: {.gracias}` | Sigue valiendo: es la pregunta del cierre. También `rogle: pregunta:` |
| `::: {.contacto}` | Sigue valiendo: sustituye al contacto del cierre. Mejor `corresponding: true` y `email` en el autor |
| `author: "Nombre, grupo ROGLE, UPV"` | Sigue valiendo, sin ORCID ni afiliaciones. Mejor el esquema de autores de Quarto |
| `borrador` en el pie | La etiqueta va a la derecha de la línea de fuente |
| Pie con el isotipo y «Grupo de Investigación ROGLE» | Pie con los iconos de Creative Commons, cita corta, licencia e identificador |
| `::: {.etiqueta}` obligatoria para ver una etiqueta | No hay etiqueta de sección. `.etiqueta` se acepta y no hace nada |
| Título de acción de dos líneas | Título estructural de una línea, 11,5 mm bajo el borde (18 mm con los menús superior y pasos). La raya queda 13,5 mm bajo el título y el cuerpo empieza 8 mm bajo la raya |
| Menú lateral solo con secciones | Bajo la sección actual van sus subsecciones (los `##`), en 10 pt, una línea cada una, con la actual en índigo negrita. Los demás menús siguen con secciones |
| Barra de mensaje clave de color sólido | Bloque tipo cita: fondo `#F3F4FA` y barra índigo de 1,5 mm a la izquierda |
| `#` sección y un `##` por diapositiva | `#` sección, `##` subsección, `###` diapositiva. Lo antiguo sigue valiendo: cada `##` es una diapositiva y una subsección del menú |
| En Beamer, no mezclar `lateral` con otros menús | Se pueden mezclar: el margen se ajusta en cada diapositiva |

## El menú de seguimiento (tracker)

Se calcula solo a partir de los `# Sección` y los `## Subsección`. No hay que escribir nada a mano. La sección actual va en índigo y las demás en gris. Nunca va en ámbar sobre blanco. Solo el menú `lateral` lista las subsecciones, bajo la sección actual y con la actual en negrita. Los nombres largos se cortan, no pasan a otra línea. Los demás menús muestran secciones.

| Valor | Aspecto |
|---|---|
| `lateral` | Panel a la izquierda, con una barra índigo en la sección actual |
| `superior` | Tira arriba a la derecha, con subrayado índigo bajo la sección actual |
| `inferior` | Tira a todo el ancho sobre el pie, con una barra índigo sobre la sección actual |
| `pasos` | Chevrones numerados arriba («1 Contexto › 2 Análisis › …»), el actual relleno de índigo |
| `ninguno` | Solo el título y el pie |

**Cambiarlo en una diapositiva.** Pon `data-tracker` en su título:

```markdown
## Una diapositiva sin menú {data-tracker="ninguno"}
## Otra con tira superior {data-tracker="superior"}
```

Funciona con cualquier valor en los dos formatos.

**Cómo funciona.** El filtro `rogle-slides.lua` lee los `# Sección` y los datos del YAML. En Reveal.js los pasa al script de `rogle20-reveal.html`, que escribe dentro de cada diapositiva el menú, la raya del título, el pie y el número, y que encoge el título si no cabe en una línea; también dibuja la portada, los separadores y el cierre. Por eso funciona igual en `?print-pdf`. En Beamer, el filtro carga el tema `beamerthemeROGLE.sty` y escribe sus órdenes: las secciones y las subsecciones en el preámbulo y, al final de cada diapositiva, el menú, la sección y la subsección de la siguiente. El tema no usa archivos `.aux`.

## Portada y cierre

La portada tiene un campo Oxford Blue hasta cuatro quintos de la altura, con una franja ámbar al pie. Debajo, una franja blanca con los logotipos UPV, DOE y ROGLE en positivo. Arriba va la etiqueta ámbar; después el título, el subtítulo, los autores con ORCID, las afiliaciones numeradas, la fecha y el enlace. Abajo a la derecha van los logotipos de `rogle: logos:`: el del centro en docencia, los de los financiadores en investigación.

El cierre es todo Oxford Blue. Arriba, la etiqueta «Conclusión», el mensaje clave, la pregunta y el QR. Debajo, cómo citar y la licencia a la izquierda; autoría, afiliación y contacto a la derecha. Al pie, la franja ámbar y los logotipos en blanco. Con `rogle: adaptacion:` la frase de adaptación sustituye a la línea de licencia. Con `portada: investigacion` y `rogle: financiacion:` aparece el apartado «Financiación».

No hay contraportada ni portada negativa. El ámbar solo se usa sobre Oxford Blue.

Los logotipos están en `_extensions/rogle-slides/resources/beamer/logos/`. Son copias de `plantillas/office/assets/`, las mismas imágenes de la plantilla de PowerPoint. El conjunto UPV, DOE y ROGLE en blanco es provisional hasta que la UPV entregue el negativo oficial (issue [#22](https://github.com/allabur/rogle/issues/22)).

## Tipografía

Es la regla de las presentaciones. Los títulos van en **Palatino negrita**: portada, cierre, títulos de diapositiva y separadores. El cuerpo va en **Palatino**. Lo secundario (menú, etiquetas, línea de fuente, pie, número de página, cabeceras de tabla y leyendas) va en el mismo Palatino.

| Elemento | Tamaño |
|---|---|
| Título de portada | 40 pt |
| Separador de sección | 96 pt el número y 36 pt el título |
| Título de la diapositiva y mensaje del cierre | 26 pt (de 26 a 20 pt si el título no cabe en una línea) |
| Índice | 28 pt el número, 24 pt el nombre y 14 pt la descripción |
| Cuerpo y viñetas | 18 pt; segundo nivel y tablas, 16 pt |
| Mensaje clave | 16 pt en negrita |
| Menú de seguimiento | 12 pt; subsecciones, 10 pt |
| Línea de fuente, pie y número | 10 pt |

Reveal.js usa Palatino del sistema, con TeX Gyre Pagella como respaldo, incrustadas en el HTML (copias de `brand/fonts/` en `resources/fonts/`). Beamer carga las mismas del sistema con fontspec y, si faltan, las de TeX Live. Las fórmulas van en Pagella: MathJax 4 con `mathjax-pagella` en Reveal.js y TeX Gyre Pagella Math en Beamer.

## Archivos

En `_extensions/rogle-slides/`:

| Archivo | Función |
|---|---|
| `_extension.yml` | Formatos `rogle-slides-revealjs` y `rogle-slides-beamer` con sus opciones |
| `rogle-slides.lua` | Filtro de Pandoc: lee las opciones y los datos, prepara las diapositivas en los dos formatos y carga los temas con la ruta de `resources/` |
| `rogle20-reveal.scss` | Tema Reveal.js: colores, tipografía, menús, bloques, portada y cierre |
| `rogle20-reveal.html` | Fuentes, imágenes (en un bloque oculto que Pandoc incrusta) y script que dibuja lo que rodea al contenido |
| `rogle-qr.js` | Codificador del código QR del cierre en Reveal.js |
| `rogle20.theme` | Colores del código resaltado, para los dos formatos |
| `mathjax-pagella.html` | Fórmulas de Reveal.js en Pagella (copia de `brand/marca/`) |
| `resources/beamer/` | Tema Beamer y sus imágenes (copia de `brand/latex/beamer/`) |
| `resources/fonts/` | Fuentes de respaldo y Academicons, para Reveal.js |

En esta carpeta:

| Archivo | Función |
|---|---|
| `template.qmd` | Ejemplo de 13 diapositivas. Opciones en el YAML |
| `build_muestra.sh` | Regenera `muestra/` en los dos formatos. Necesita Google Chrome para capturar Reveal.js |
| `build_figura.py` | Dibuja la figura de ejemplo (`figura-rutas.svg` y `.pdf`) |
| `build_logos.py` | Genera las marcas UPV y ROGLE que usa la extensión `rogle-article` |
| `slides_a_qmd.py` | Convierte un mazo de Claude Slides en un `.qmd` de esta plantilla. Véase «De Claude Slides a esta plantilla» |
| `muestra/` | Capturas: hoja de contactos y diapositivas sueltas de cada formato |

`web/tests/test_extensiones.py` comprueba que las copias de `resources/` coinciden con `brand/` y con `plantillas/office/assets/`.

## De Claude Slides a esta plantilla

Una presentación se puede escribir en Claude Slides, con el aspecto de la marca, y pasarla después a esta plantilla. Hay un mazo maestro por ámbito: «Maestro ROGLE: presentación de docencia» (https://claude.ai/artifact/1Nz4W6oPC6FWUx3duHjEhG), para las diapositivas de una lección, y «Maestro ROGLE: presentación de investigación» (https://claude.ai/artifact/EegKDPn9kKS37YAD3XHKEf), para las de un congreso o evento. Cada mazo se hace copiando diapositivas del maestro de su ámbito. `slides_a_qmd.py` lo convierte en un `.qmd`. La conversión va en un solo sentido: desde entonces el original es el `.qmd`, y lo que se cambie en él no vuelve al mazo.

Pasos, en una sesión de Claude con este repositorio abierto:

1. Pide a Claude que lea el mazo con su dirección. La lectura guarda una carpeta con `project/deck.json` y `project/slides/<id>.html`.
2. Ejecuta `uv run plantillas/presentaciones/slides_a_qmd.py CARPETA -o charla/charla.qmd`. El script escribe el `.qmd` y lista los avisos: lo que ha aproximado, lo que ha dejado fuera y las figuras que faltan.
3. Si faltan figuras, pide a Claude que lea cada una del mazo por su identificador y la guarde en `charla/figuras/`. Vuelve a ejecutar el paso 2: el `.qmd` toma el nombre de cada archivo.
4. Revisa el `.qmd`, añade el ORCID de cada autor y renderiza: `quarto render charla/charla.qmd`.

Opciones: `--figuras DIR` cambia la carpeta de las figuras y `--quitar-corchetes` quita los corchetes de los textos de ejemplo de los mazos maestros (también los de la cita, como «[Diapositivas]»).

El script reconoce cada elemento por su estilo y su posición en la diapositiva, no por el identificador de la diapositiva. Así sirve para mazos ya hechos y no depende de que Slides conserve atributos propios. A cambio, solo entiende diapositivas copiadas de los mazos maestros: si cambian sus medidas o sus colores, hay que revisar las constantes del script. `web/tests/test_slides_a_qmd.py` lo comprueba con un mazo pequeño en `web/tests/fixtures/mazo-slides/`.

| Del mazo | Al `.qmd` | Fidelidad |
|---|---|---|
| Portada: etiqueta, título, subtítulo, autores, afiliaciones, fecha, enlace y logotipo del centro o de los financiadores | YAML (`title`, `author`, `affiliations`, `date`, `rogle`) | Fiel. El ORCID no está en el mazo: se añade a mano |
| Índice | `::: {.agenda}` y `descripcion` de cada sección | Fiel. Un segundo índice se deja fuera: la extensión resalta la sección sola |
| Menú de seguimiento | `# Sección`, `tracker` y `data-tracker` en la diapositiva que usa otro | Fiel. El nombre de la sección es el del menú, no el del separador |
| Separador de sección | Sección con separador; sin él, `.sin-separador` | Fiel |
| Subsección actual del menú lateral | `## Subsección` y `### Título` | Aproximado. Una subsección sin diapositivas no aparece, y las siguientes se renumeran |
| Diapositiva sin menú lateral | `## Título` | Aproximado. El título pasa a ser una subsección del menú |
| Viñetas de dos niveles, listas numeradas, párrafos, negrita y cursiva | Markdown | Fiel |
| Resumen, comparación, dos columnas, próximos pasos con decisión | `.bloques`, `.comparacion`, `.columns`, `.cierre` | Fiel |
| Mensaje clave, fuente y etiqueta de borrador | `.mensaje`, `.fuente`, `borrador` | Fiel |
| Imágenes del cuerpo | `![texto alternativo](figuras/…)` | Fiel, tras guardar los archivos. Pierden su tamaño y su posición exactos |
| Tablas | Tabla de Markdown | Aproximado. Sin anchos de columna ni fila de total |
| Notas del orador | `::: {.notes}` | Fiel |
| Cierre: mensaje, cita, financiación, adaptación, pregunta y web | `{.conclusion}` y `rogle` | Fiel. El texto de la licencia y el QR los genera la extensión |
| Gráficos SVG, vídeos, animaciones y transiciones | Nada | Se dejan fuera, con aviso |
| Diapositivas en blanco o sin título, segunda portada y segundo cierre | Nada | Se dejan fuera, con aviso |
| Tamaños, colores y posiciones cambiados a mano | Nada | Se pierden: el `.qmd` usa los de la plantilla |

## Límites conocidos

- Beamer va solo con LuaLaTeX (ver arriba).
- El código QR admite enlaces de hasta 213 bytes. Con uno más largo, Reveal.js no lo dibuja: da su imagen en `rogle: qr:`.
- El menú admite de dos a seis secciones con nombres de hasta 16 caracteres. Con más, no cabe en una línea.
- En el menú lateral, un nombre de subsección de más de unos 20 caracteres se corta con puntos suspensivos. Con muchas subsecciones, el panel puede quedarse sin altura.
- Con más de dos o tres logotipos en `rogle: logos:`, el bloque derecho pisa los logotipos del grupo.
- Reveal.js: el HTML pesa unos 6 MB porque lleva dentro las fuentes de respaldo y los logotipos.
- Reveal.js: la consola del navegador muestra un error de `MathJax.Hub` del complemento de fórmulas de Reveal.js. Es anterior al rediseño y las fórmulas se ven bien.
- La figura de ejemplo lleva texto en Palatino. `build_figura.py` la dibuja con las fuentes de este equipo. Otro equipo puede dibujarla con otra fuente.

## Pregunta abierta

Esta regla vale para toda la marca: Palatino en todo el texto, títulos en negrita (`brand/marca/BRAND_SPEC.md`, sección «Tipografía»).
